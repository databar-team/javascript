/* placeholder for any Dredd hooks */
const hooks = require("hooks");

hooks.beforeEach(function(transaction, done) {
  // dredd is strict about matching content-type - this will work around it
  if (transaction.name.match(/> application\/json$/)) {
    transaction.expected.headers["Content-Type"] =
      "application/json; charset=utf-8";
  }
  done();
});
