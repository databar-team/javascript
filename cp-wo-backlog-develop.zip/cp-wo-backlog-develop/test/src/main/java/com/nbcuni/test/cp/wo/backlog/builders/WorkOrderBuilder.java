package com.nbcuni.test.cp.wo.backlog.builders;

import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.utils.DataGenerator;
import com.nbcuni.test.utils.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class WorkOrderBuilder {

    @Autowired
    DataGenerator dataGenerator;

    private static final Logger logger = new Logger();

    public WorkOrderBacklogInputMessage createKinesisMessage() {

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setWorkOrderId("SQE_AT_" + DataGenerator.randomString());

        logger.info("Sending Work Order Kinesis Message: "+ workOrderBacklogInputMessage.toString());
        return workOrderBacklogInputMessage;
    }

}
