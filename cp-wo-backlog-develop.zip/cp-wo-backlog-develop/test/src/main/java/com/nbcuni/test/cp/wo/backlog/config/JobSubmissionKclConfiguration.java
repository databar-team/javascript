package com.nbcuni.test.cp.wo.backlog.config;

import com.nbcuni.test.amazon.kinesis.kcl.KclProperties;
import com.nbcuni.test.amazon.kinesis.kcl.StateListener;
import com.nbcuni.test.cp.wo.backlog.config.kcl.SchedulerBuilder;
import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisRecordProcessor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatch.CloudWatchAsyncClient;
import software.amazon.awssdk.services.dynamodb.DynamoDbAsyncClient;
import software.amazon.awssdk.services.kinesis.KinesisAsyncClient;
import software.amazon.kinesis.common.ConfigsBuilder;
import software.amazon.kinesis.coordinator.Scheduler;
import software.amazon.kinesis.processor.ShardRecordProcessorFactory;

import java.util.UUID;

@Configuration
@ComponentScan(basePackages = {"com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission"})
public class JobSubmissionKclConfiguration {

    @Bean("jobSubmissionStreamKclProperties")
    @ConfigurationProperties(prefix = "kcl2")
    public KclProperties jobSubmissionStreamKclProperties() {
        return new KclProperties();
    }

    @Bean
    public AwsCredentialsProvider awsCredentialsProvider() {
        return DefaultCredentialsProvider.create();
    }

    @Bean("kinesisAsyncClientJobSubmissionStream")
    public KinesisAsyncClient kinesisAsyncClientJobSubmissionStream(@Qualifier("jobSubmissionStreamKclProperties") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return KinesisAsyncClient.builder()
                .region(Region.of(kclProperties.getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean("kinesisRecordProcessorJobSubmissionStream")
    JobSubmissionKinesisRecordProcessor kinesisRecordProcessorJobSubmissionStream() {
        return new JobSubmissionKinesisRecordProcessor();
    }

    @Bean("shardRecordProcessorFactoryJobSubmissionStream")
    ShardRecordProcessorFactory shardRecordProcessorFactoryJobSubmissionStream() {
        return this::kinesisRecordProcessorJobSubmissionStream;
    }

    @Bean("stateListenerJobSubmissionStream")
    protected StateListener stateListenerJobSubmissionStream() {
        return new StateListener();
    }

    @Bean(name = "dynamoDbAsyncClientJobSubmissionStream")
    public DynamoDbAsyncClient dynamoDbAsyncClientJobSubmissionStream(@Qualifier("jobSubmissionStreamKclProperties") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return DynamoDbAsyncClient.builder()
                .region(Region.of(kclProperties.getDynamoDb().getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean(name = "cloudWatchAsyncClientJobSubmissionStream")
    public CloudWatchAsyncClient cloudWatchAsyncClientJobSubmissionStream(@Qualifier("jobSubmissionStreamKclProperties") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return CloudWatchAsyncClient.builder()
                .region(Region.of(kclProperties.getCloudWatch().getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean(name = "schedulerJobSubmissionStream")
    public Scheduler schedulerJobSubmissionStream(@Qualifier("jobSubmissionStreamKclProperties") KclProperties kclProperties, @Qualifier("configsBuilderJobSubmissionStream") ConfigsBuilder configsBuilder, @Qualifier("stateListenerJobSubmissionStream") StateListener workerStateListener) {
        return SchedulerBuilder.buildScheduler(kclProperties, configsBuilder, workerStateListener);
    }

    @Bean(name = "configsBuilderJobSubmissionStream")
    public ConfigsBuilder configsBuilder2(@Qualifier("jobSubmissionStreamKclProperties") KclProperties kclProperties,
                                          @Qualifier("kinesisAsyncClientJobSubmissionStream") KinesisAsyncClient kinesisAsyncClient,
                                          @Qualifier("dynamoDbAsyncClientJobSubmissionStream") DynamoDbAsyncClient dynamoDbAsyncClient,
                                          @Qualifier("cloudWatchAsyncClientJobSubmissionStream") CloudWatchAsyncClient cloudWatchAsyncClient,
                                          @Qualifier("shardRecordProcessorFactoryJobSubmissionStream") ShardRecordProcessorFactory shardRecordProcessorFactory) {
        return new ConfigsBuilder(kclProperties.getStreamName(),
                kclProperties.getApplicationName(),
                kinesisAsyncClient,
                dynamoDbAsyncClient,
                cloudWatchAsyncClient,
                UUID.randomUUID().toString(),
                shardRecordProcessorFactory);
    }
}
