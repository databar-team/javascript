package com.nbcuni.test.cp.wo.backlog.config;

import com.nbcuni.test.amazon.kinesis.kcl.KclProperties;
import com.nbcuni.test.amazon.kinesis.kcl.StateListener;
import com.nbcuni.test.cp.wo.backlog.config.kcl.SchedulerBuilder;
import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisRecordProcessor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatch.CloudWatchAsyncClient;
import software.amazon.awssdk.services.dynamodb.DynamoDbAsyncClient;
import software.amazon.awssdk.services.kinesis.KinesisAsyncClient;
import software.amazon.kinesis.common.ConfigsBuilder;
import software.amazon.kinesis.coordinator.Scheduler;
import software.amazon.kinesis.processor.ShardRecordProcessorFactory;

import java.util.UUID;

@Configuration
@ComponentScan(basePackages = {"com.nbcuni.test.cp.wo.backlog.config.kcl"})
public class KclConfiguration {


    @Bean("statusEventStream")
    public KclProperties statusStreamProperties() {
        return new KclProperties();
    }

    @Bean
    public AwsCredentialsProvider awsCredentialsProvider() {
        return DefaultCredentialsProvider.create();
    }

    @Bean("kinesisAsyncClientStatusEventStream")
    public KinesisAsyncClient kinesisAsyncClient1(@Qualifier("statusEventStream") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return KinesisAsyncClient.builder()
                .region(Region.of(kclProperties.getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean("kinesisRecordProcessorStatusEventStream")
    StatusEventKinesisRecordProcessor statusEventKinesisRecordProcessor() {
        return new StatusEventKinesisRecordProcessor();
    }

    @Bean("shardRecordProcessorFactoryStatusEventStream")
    ShardRecordProcessorFactory shardRecordProcessorFactory1() {
        return this::statusEventKinesisRecordProcessor;
    }

    @Bean("stateListenerStatusEventStream")
    @Primary
    protected StateListener stateListener1() {
        return new StateListener();
    }

    @Bean(name = "dynamoDbAsyncClientStatusEventStream")
    public DynamoDbAsyncClient dynamoDbAsyncClient1(@Qualifier("statusEventStream") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return DynamoDbAsyncClient.builder()
                .region(Region.of(kclProperties.getDynamoDb().getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean(name = "cloudWatchAsyncClientStatusEventStream")
    public CloudWatchAsyncClient cloudWatchAsyncClient1(@Qualifier("statusEventStream") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return CloudWatchAsyncClient.builder()
                .region(Region.of(kclProperties.getCloudWatch().getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean(name = "schedulerStatusEventStream")
    @Primary
    public Scheduler scheduler1(@Qualifier("statusEventStream") KclProperties kclProperties, @Qualifier("configsBuilderStatusEventStream") ConfigsBuilder configsBuilder, @Qualifier("stateListenerStatusEventStream") StateListener workerStateListener) {
        return SchedulerBuilder.buildScheduler(kclProperties, configsBuilder, workerStateListener);
    }


    @Bean(name = "configsBuilderStatusEventStream")
    public ConfigsBuilder configsBuilder1(@Qualifier("statusEventStream") KclProperties kclProperties,
                                          @Qualifier("kinesisAsyncClientStatusEventStream") KinesisAsyncClient kinesisAsyncClient,
                                          @Qualifier("dynamoDbAsyncClientStatusEventStream") DynamoDbAsyncClient dynamoDbAsyncClient,
                                          @Qualifier("cloudWatchAsyncClientStatusEventStream") CloudWatchAsyncClient cloudWatchAsyncClient,
                                          @Qualifier("shardRecordProcessorFactoryStatusEventStream") ShardRecordProcessorFactory shardRecordProcessorFactory) {
        return new ConfigsBuilder(kclProperties.getStreamName(),
                kclProperties.getApplicationName(),
                kinesisAsyncClient,
                dynamoDbAsyncClient,
                cloudWatchAsyncClient,
                UUID.randomUUID().toString(),
                shardRecordProcessorFactory);
    }

}
