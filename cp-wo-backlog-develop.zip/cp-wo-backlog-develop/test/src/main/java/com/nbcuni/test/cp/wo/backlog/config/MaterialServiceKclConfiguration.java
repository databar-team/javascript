package com.nbcuni.test.cp.wo.backlog.config;

import com.nbcuni.test.amazon.kinesis.kcl.KclProperties;
import com.nbcuni.test.amazon.kinesis.kcl.StateListener;
import com.nbcuni.test.cp.wo.backlog.config.kcl.SchedulerBuilder;
import com.nbcuni.test.cp.wo.backlog.config.kcl.material.MaterialKinesisRecordProcessor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatch.CloudWatchAsyncClient;
import software.amazon.awssdk.services.dynamodb.DynamoDbAsyncClient;
import software.amazon.awssdk.services.kinesis.KinesisAsyncClient;
import software.amazon.kinesis.common.ConfigsBuilder;
import software.amazon.kinesis.coordinator.Scheduler;
import software.amazon.kinesis.processor.ShardRecordProcessorFactory;

import java.util.UUID;

@Configuration
@ComponentScan(basePackages = {"com.nbcuni.test.cp.wo.backlog.config.kcl.material"})
public class MaterialServiceKclConfiguration {

    @Bean("materialServiceStreamKclProperties")
    @ConfigurationProperties(prefix = "kcl3")
    public KclProperties materialServiceStreamKclProperties() {
        return new KclProperties();
    }

    @Bean
    public AwsCredentialsProvider awsCredentialsProvider() {
        return DefaultCredentialsProvider.create();
    }

    @Bean("kinesisAsyncClientMaterialServiceStream")
    public KinesisAsyncClient kinesisAsyncClientMaterialServiceStream(@Qualifier("materialServiceStreamKclProperties") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return KinesisAsyncClient.builder()
                .region(Region.of(kclProperties.getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean("kinesisRecordProcessorMaterialServiceStream")
    MaterialKinesisRecordProcessor kinesisRecordProcessorMaterialServiceStream() {
        return new MaterialKinesisRecordProcessor();
    }

    @Bean("shardRecordProcessorFactoryMaterialServiceStream")
    ShardRecordProcessorFactory shardRecordProcessorFactoryMaterialServiceStream() {
        return this::kinesisRecordProcessorMaterialServiceStream;
    }

    @Bean("materialServiceStateListener")
    protected StateListener materialServiceStateListener() {
        return new StateListener();
    }

    @Bean(name = "dynamoDbAsyncClientMaterialServiceStream")
    public DynamoDbAsyncClient dynamoDbAsyncClientMaterialServiceStream(
            @Qualifier("materialServiceStreamKclProperties") KclProperties kclProperties,
            AwsCredentialsProvider awsCredentialsProvider) {

        return DynamoDbAsyncClient.builder()
                .region(Region.of(kclProperties.getDynamoDb().getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean(name = "cloudWatchAsyncClientMaterialServiceStream")
    public CloudWatchAsyncClient cloudWatchAsyncClientMaterialServiceStream(
            @Qualifier("materialServiceStreamKclProperties") KclProperties kclProperties,
            AwsCredentialsProvider awsCredentialsProvider) {

        return CloudWatchAsyncClient.builder()
                .region(Region.of(kclProperties.getCloudWatch().getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean(name = "materialServiceScheduler")
    public Scheduler materialServiceScheduler(@Qualifier("materialServiceStreamKclProperties") KclProperties kclProperties,
                                              @Qualifier("configsBuilderMaterialServiceStream") ConfigsBuilder configsBuilder,
                                              @Qualifier("materialServiceStateListener") StateListener workerStateListener) {
        return SchedulerBuilder.buildScheduler(kclProperties, configsBuilder, workerStateListener);
    }


    @Bean(name = "configsBuilderMaterialServiceStream")
    public ConfigsBuilder configsBuilder1(@Qualifier("materialServiceStreamKclProperties") KclProperties kclProperties,
                                          @Qualifier("kinesisAsyncClientMaterialServiceStream") KinesisAsyncClient kinesisAsyncClient,
                                          @Qualifier("dynamoDbAsyncClientMaterialServiceStream") DynamoDbAsyncClient dynamoDbAsyncClient,
                                          @Qualifier("cloudWatchAsyncClientMaterialServiceStream") CloudWatchAsyncClient cloudWatchAsyncClient,
                                          @Qualifier("shardRecordProcessorFactoryMaterialServiceStream") ShardRecordProcessorFactory shardRecordProcessorFactory) {
        return new ConfigsBuilder(kclProperties.getStreamName(),
                kclProperties.getApplicationName(),
                kinesisAsyncClient,
                dynamoDbAsyncClient,
                cloudWatchAsyncClient,
                UUID.randomUUID().toString(),
                shardRecordProcessorFactory);
    }
}
