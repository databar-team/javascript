package com.nbcuni.test.cp.wo.backlog.config;

import com.amazonaws.services.s3.model.S3Object;
import com.nbcuni.test.amazon.s3.S3Service;
import com.nbcuni.test.cp.wo.backlog.constants.Constants;
import org.awaitility.core.ConditionTimeoutException;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.await;

@Component
public class S3ServiceUtils {

    private S3Service s3Service;

    public S3ServiceUtils(S3Service s3Service) {
        this.s3Service = s3Service;
    }

    public S3Object getItemFromS3BucketWithWaiting(String key) {
        try {
            await().with().pollDelay(Duration.ofSeconds(5)).atMost(Constants.LONG_TIMEOUT, TimeUnit.SECONDS).until(isItemAvailable(key));
            return s3Service.getObjectByKey(key);
        } catch (ConditionTimeoutException ex) {
            return null;
        }

    }

    public Callable<Boolean> isItemCreatedInS3Bucket(String key) {
        return () -> s3Service.getObjectByKey(key) != null;
    }

    public int getCountOfItems() {
        return s3Service.listObjects().getKeyCount();
    }

    public Callable<Boolean> isItemAvailable(String key) {
        return () -> s3Service.listObjects().getObjectSummaries().stream().filter(item -> item.getKey().contains(key)).count() > 0;
    }
}
