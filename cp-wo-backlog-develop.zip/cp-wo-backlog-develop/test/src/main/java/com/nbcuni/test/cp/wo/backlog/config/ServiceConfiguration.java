package com.nbcuni.test.cp.wo.backlog.config;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagement;
import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagementClientBuilder;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nbcuni.test.amazon.common.AwsCommonProperties;
import com.nbcuni.test.amazon.dynamodb.AmazonDynamoDBConfig;
import com.nbcuni.test.amazon.dynamodb.DynamoDbProperties;
import com.nbcuni.test.amazon.kinesis.kpl.KinesisProducerProperties;
import com.nbcuni.test.amazon.s3.S3Service;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;


@Configuration
@ComponentScan(basePackages = {"com.nbcuni.test.cp.wo.backlog"})
public class ServiceConfiguration {

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return objectMapper;
    }

    @Bean
    public AmazonDynamoDBConfig amazonDynamoDBConfig() {
        return new AmazonDynamoDBConfig();
    }

    @Bean
    public DynamoDbProperties dynamoDbProperties() {
        return new DynamoDbProperties();
    }

    @Bean("statusEventStreamKinesisProducerProperties")
    @ConfigurationProperties(prefix = "aws.kinesis.kpl1")
    public KinesisProducerProperties statusEventStreamKinesisProducerProperties() {
        return new KinesisProducerProperties();
    }

    @Bean
    @Primary
    public KinesisProducerProperties backlogEventsStream() {
        return new KinesisProducerProperties();
    }

    @Bean
    public S3Service s3Service() {
        return new S3Service();
    }

    @Bean
    public AmazonDynamoDB amazonDynamoDB(DynamoDbProperties dynamoDbProperties, AwsCommonProperties awsCommonProperties) {
        return AmazonDynamoDBClientBuilder.standard()
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(dynamoDbProperties.getEndpoint(), awsCommonProperties.getRegion()))
                .build();
    }

    @Bean
    public DynamoDB dynamoDB(AmazonDynamoDB amazonDynamoDB) {
        return new DynamoDB(amazonDynamoDB);
    }

    @Bean
    public AwsCredentialsProvider awsCredentialsProvider() {
        return DefaultCredentialsProvider.create();
    }

    @Bean
    AWSCredentials awsCredentials(AwsCredentialsProvider awsCredentialsProvider) {
        return new BasicAWSCredentials(
                awsCredentialsProvider.resolveCredentials().accessKeyId(),
                awsCredentialsProvider.resolveCredentials().secretAccessKey());
    }

    @Bean
    public AWSSimpleSystemsManagement awsSimpleSystemsManagementClient(AWSCredentials awsCredentials) {
        return AWSSimpleSystemsManagementClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(awsCredentials)).build();
    }
}
