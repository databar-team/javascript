package com.nbcuni.test.cp.wo.backlog.config;

import com.nbcuni.test.amazon.kinesis.kcl.KclProperties;
import com.nbcuni.test.amazon.kinesis.kcl.StateListener;
import com.nbcuni.test.cp.wo.backlog.config.kcl.SchedulerBuilder;
import com.nbcuni.test.cp.wo.backlog.config.kcl.validation.ValidationServiceRecordProcessor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatch.CloudWatchAsyncClient;
import software.amazon.awssdk.services.dynamodb.DynamoDbAsyncClient;
import software.amazon.awssdk.services.kinesis.KinesisAsyncClient;
import software.amazon.kinesis.common.ConfigsBuilder;
import software.amazon.kinesis.coordinator.Scheduler;
import software.amazon.kinesis.processor.ShardRecordProcessorFactory;

import java.util.UUID;

@Configuration
@ComponentScan(basePackages = {"com.nbcuni.test.cp.wo.backlog.config.kcl.validation"})
public class ValidationServiceKclConfiguration {

    @Bean("validationServiceStreamKclProperties")
    @ConfigurationProperties(prefix = "kcl1")
    public KclProperties validationServiceKclProperties() {
        return new KclProperties();
    }

    @Bean
    public AwsCredentialsProvider awsCredentialsProvider() {
        return DefaultCredentialsProvider.create();
    }

    @Bean("validationServiceKinesisAsyncClient")
    public KinesisAsyncClient validationServiceKinesisAsyncClient(@Qualifier("validationServiceStreamKclProperties") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return KinesisAsyncClient.builder()
                .region(Region.of(kclProperties.getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean("validationServiceKinesisRecordProcessor")
    ValidationServiceRecordProcessor validationServiceRecordProcessor() {
        return new ValidationServiceRecordProcessor();
    }

    @Bean("validationServiceShardRecordProcessorFactory")
    ShardRecordProcessorFactory validationServiceShardRecordProcessorFactory() {
        return this::validationServiceRecordProcessor;
    }

    @Bean("validationServiceStateListener")
    protected StateListener validationServiceStateListener() {
        return new StateListener();
    }

    @Bean(name = "validationServiceDynamoDbAsyncClient")
    public DynamoDbAsyncClient validationServiceDynamoDbAsyncClient(@Qualifier("validationServiceStreamKclProperties") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return DynamoDbAsyncClient.builder()
                .region(Region.of(kclProperties.getDynamoDb().getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean(name = "validationServiceCloudWatchAsyncClient")
    public CloudWatchAsyncClient validationServiceCloudWatchAsyncClient(@Qualifier("validationServiceStreamKclProperties") KclProperties kclProperties, AwsCredentialsProvider awsCredentialsProvider) {

        return CloudWatchAsyncClient.builder()
                .region(Region.of(kclProperties.getCloudWatch().getRegion()))
                .credentialsProvider(awsCredentialsProvider)
                .build();
    }

    @Bean(name = "validationServiceScheduler")
    public Scheduler validationServiceScheduler(@Qualifier("validationServiceStreamKclProperties") KclProperties kclProperties,
                                                @Qualifier("validationServiceConfigsBuilder") ConfigsBuilder configsBuilder,
                                                @Qualifier("validationServiceStateListener") StateListener workerStateListener) {
        return SchedulerBuilder.buildScheduler(kclProperties, configsBuilder, workerStateListener);
    }

    @Bean(name = "validationServiceConfigsBuilder")
    public ConfigsBuilder validationServiceConfigsBuilder(@Qualifier("validationServiceStreamKclProperties") KclProperties kclProperties,
                                          @Qualifier("validationServiceKinesisAsyncClient") KinesisAsyncClient kinesisAsyncClient,
                                          @Qualifier("validationServiceDynamoDbAsyncClient") DynamoDbAsyncClient dynamoDbAsyncClient,
                                          @Qualifier("validationServiceCloudWatchAsyncClient") CloudWatchAsyncClient cloudWatchAsyncClient,
                                          @Qualifier("validationServiceShardRecordProcessorFactory") ShardRecordProcessorFactory shardRecordProcessorFactory) {
        return new ConfigsBuilder(kclProperties.getStreamName(),
                kclProperties.getApplicationName(),
                kinesisAsyncClient,
                dynamoDbAsyncClient,
                cloudWatchAsyncClient,
                UUID.randomUUID().toString(),
                shardRecordProcessorFactory);
    }
}
