package com.nbcuni.test.cp.wo.backlog.config.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface MaxRetryCount {
    int value() default 0;
}