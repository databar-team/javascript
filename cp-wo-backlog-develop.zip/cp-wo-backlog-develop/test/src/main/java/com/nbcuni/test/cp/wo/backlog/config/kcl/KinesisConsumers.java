package com.nbcuni.test.cp.wo.backlog.config.kcl;

import com.nbcuni.test.amazon.kinesis.kcl.KinesisConsumer;
import com.nbcuni.test.amazon.kinesis.kcl.StateListener;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import software.amazon.kinesis.coordinator.Scheduler;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Component
public class KinesisConsumers {
    private static final int START_TIMEOUT = 500;
    private static final int ADDED_SLEEP_TIME = 10;

    private Logger logger = LogManager.getLogger();

    public ConcurrentMap<String, KinesisConsumer> getConsumers() {
        return consumers;
    }

    private ConcurrentMap<String, KinesisConsumer> consumers = new ConcurrentHashMap<>();


    public KinesisConsumers(Scheduler scheduler, StateListener workerStateListener) throws InterruptedException {
        addKinesisConsumer(scheduler, workerStateListener);
    }

    public synchronized void addKinesisConsumer(Scheduler scheduler, StateListener workerStateListener) throws InterruptedException {
        if (consumers.get(scheduler.streamName()) == null) {
            KinesisConsumer kinesisConsumer = new KinesisConsumer(scheduler, workerStateListener);
            kinesisConsumer.waitForWorkerToBeStarted(START_TIMEOUT, ADDED_SLEEP_TIME);
            consumers.put(scheduler.streamName(), kinesisConsumer);
        } else {
            logger.warn("Consumer for " + scheduler.streamName() + "already exist");
        }
    }

    public void destroy() {
        consumers.forEach((k, v) -> {
            if (v != null && v.isAlive()) {
                v.destroy();
                consumers.remove(k);
            }
        });
    }

    public void destroy(String consumer) {
        consumers.forEach((k, v) -> {
            if (v != null && v.isAlive()) {
                if (k.contains(consumer)) {
                    v.destroy();
                }
            }
        });
    }
}
