package com.nbcuni.test.cp.wo.backlog.config.kcl;

import com.nbcuni.test.amazon.kinesis.kcl.KclProperties;
import com.nbcuni.test.amazon.kinesis.kcl.StateListener;
import software.amazon.kinesis.common.ConfigsBuilder;
import software.amazon.kinesis.common.InitialPositionInStream;
import software.amazon.kinesis.common.InitialPositionInStreamExtended;
import software.amazon.kinesis.coordinator.CoordinatorConfig;
import software.amazon.kinesis.coordinator.Scheduler;
import software.amazon.kinesis.leases.LeaseManagementConfig;
import software.amazon.kinesis.metrics.MetricsConfig;
import software.amazon.kinesis.retrieval.RetrievalConfig;
import software.amazon.kinesis.retrieval.fanout.FanOutConfig;

public class SchedulerBuilder {
    private SchedulerBuilder() {
    }

    public static synchronized Scheduler buildScheduler(KclProperties kclProperties, ConfigsBuilder configsBuilder, StateListener workerStateListener) {
        KclProperties.Retrieval retrieval = kclProperties.getRetrieval();
        KclProperties.Coordinator coordinator = kclProperties.getCoordinator();
        KclProperties.Metrics metrics = kclProperties.getMetrics();
        KclProperties.LeaseManagement leaseManagement = kclProperties.getLeaseManagement();
        KclProperties.Fanout fanout = kclProperties.getFanout();

        configsBuilder.tableName(kclProperties.getTableName());

        FanOutConfig fanOutConfig = new FanOutConfig(configsBuilder.kinesisClient())
                .streamName(configsBuilder.streamName())
                .applicationName(configsBuilder.applicationName());
        fanOutConfig.maxDescribeStreamConsumerRetries(fanout.getMaxDescribeStreamConsumerRetries());
        fanOutConfig.maxDescribeStreamSummaryRetries(fanout.getMaxDescribeStreamSummaryRetries());
        fanOutConfig.registerStreamConsumerRetries(fanout.getRegisterStreamConsumerRetries());
        fanOutConfig.retryBackoffMillis(fanout.getRetryBackoffMillis());

        RetrievalConfig retrievalConfig = configsBuilder.retrievalConfig();
        retrievalConfig.initialPositionInStreamExtended(InitialPositionInStreamExtended.newInitialPosition(InitialPositionInStream.LATEST));
        retrievalConfig.retrievalSpecificConfig(fanOutConfig);
        retrievalConfig.listShardsBackoffTimeInMillis(retrieval.getListShardsBackoffTimeInMillis());
        retrievalConfig.maxListShardsRetryAttempts(retrieval.getMaxListShardsRetryAttempts());

        CoordinatorConfig coordinatorConfig = configsBuilder.coordinatorConfig();
        coordinatorConfig.skipShardSyncAtWorkerInitializationIfLeasesExist(coordinator.isSkipShardSyncAtWorkerInitializationIfLeasesExist());
        coordinatorConfig.parentShardPollIntervalMillis(coordinator.getParentShardPollIntervalMillis());
        coordinatorConfig.shardConsumerDispatchPollIntervalMillis(coordinator.getShardConsumerDispatchPollIntervalMillis());
        coordinatorConfig.workerStateChangeListener(workerStateListener);

        MetricsConfig metricsConfig = configsBuilder.metricsConfig();
        metricsConfig.metricsBufferTimeMillis(metrics.getMetricsBufferTimeMillis());
        metricsConfig.metricsMaxQueueSize(metrics.getMetricsMaxQueueSize());

        LeaseManagementConfig leaseManagementConfig = configsBuilder.leaseManagementConfig();
        leaseManagementConfig.maxLeaseRenewalThreads(leaseManagement.getMaxLeaseRenewalThreads());
        leaseManagementConfig.maxLeasesToStealAtOneTime(leaseManagement.getMaxLeasesToStealAtOneTime());
        leaseManagementConfig.ignoreUnexpectedChildShards(leaseManagement.isIgnoreUnexpectedChildShards());
        leaseManagementConfig.cleanupLeasesUponShardCompletion(leaseManagement.isCleanupLeasesUponShardCompletion());
        leaseManagementConfig.shardSyncIntervalMillis(leaseManagement.getShardSyncIntervalMillis());
        leaseManagementConfig.failoverTimeMillis(leaseManagement.getFailoverTimeMillis());

        return new Scheduler(
                configsBuilder.checkpointConfig(),
                coordinatorConfig,
                leaseManagementConfig,
                configsBuilder.lifecycleConfig(),
                metricsConfig,
                configsBuilder.processorConfig(),
                retrievalConfig
        );
    }
}
