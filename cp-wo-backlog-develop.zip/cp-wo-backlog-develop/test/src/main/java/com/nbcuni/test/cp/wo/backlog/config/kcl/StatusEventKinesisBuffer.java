package com.nbcuni.test.cp.wo.backlog.config.kcl;

import com.nbcuni.test.cp.wo.backlog.constants.Constants;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.StatusMessageEnum;
import org.awaitility.core.ConditionTimeoutException;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.*;
import java.util.stream.Collectors;

import static org.awaitility.Awaitility.await;

public class StatusEventKinesisBuffer {
    private static StatusEventKinesisBuffer ourInstance = new StatusEventKinesisBuffer();

    private ConcurrentMap<String, List<StatusEvent>> stepStatusKinesisMap;
    private ConcurrentMap<String, List<StatusEvent>> jobStatusKinesisMap;
    private ConcurrentLinkedQueue<String> kinesisErrors;
    private List<StatusEvent> uncategorizedStatusEventList;
    private final List<String> textMessages;

    public static StatusEventKinesisBuffer getInstance() {
        return ourInstance;
    }


    private StatusEventKinesisBuffer() {
        this.stepStatusKinesisMap = new ConcurrentHashMap<>();
        this.jobStatusKinesisMap = new ConcurrentHashMap<>();
        this.kinesisErrors = new ConcurrentLinkedQueue<>();
        this.uncategorizedStatusEventList = new Vector<>();
        this.textMessages = new Vector<>();
    }

    public ConcurrentLinkedQueue<String> errorQueue() {
        return kinesisErrors;
    }

    public List<StatusEvent> getJobStatusWithWaiting(String key) {
        await().atMost(Constants.TIMEOUT, TimeUnit.SECONDS).until(isJobStatusAvailable(key));
        return jobStatusKinesisMap.get(key);
    }

    public List<StatusEvent> getJobStatusWithWaiting(String key, String jobStatus) {
        try {
            await().with().pollDelay(Duration.ofSeconds(5)).atMost(Constants.LONG_TIMEOUT, TimeUnit.SECONDS).until(isJobStatusAvailable(key, jobStatus));
            return jobStatusKinesisMap.get(key).stream()
                    .filter(statusEvent -> statusEvent.getJobStatus().equalsIgnoreCase(jobStatus)).collect(Collectors.toList());
        } catch (ConditionTimeoutException ex) {
            return null;
        }


    }

    public List<StatusEvent> getJobStatusWithStatusMessage(String key, String statusMessage) {
        try {
            await().with().pollDelay(Duration.ofSeconds(Constants.DELAY)).atMost(Constants.TIMEOUT, TimeUnit.SECONDS).until(isStatusWithStatusMessageAvailable(key, statusMessage));
            return jobStatusKinesisMap.get(key).stream()
                    .filter(statusEvent -> statusEvent.getStatusMessage() != null)
                    .filter(statusEvent -> statusEvent.getStatusMessage().contains(statusMessage)).collect(Collectors.toList());
        } catch (ConditionTimeoutException ex) {
            return Collections.emptyList();
        }
    }

    public Callable<Boolean> isStatusWithStatusMessageAvailable(String key, String statusMessage) {
        return () -> {
            if (jobStatusKinesisMap.get(key) != null) {
                return jobStatusKinesisMap.get(key).stream()
                        .filter(statusEvent -> statusEvent.getStatusMessage() != null)
                        .filter(statusEvent -> statusEvent.getStatusMessage().contains(statusMessage)).count() > 0;
            } else {
                return false;
            }
        };
    }

    public Callable<Boolean> isJobStatusAvailable(String key) {
        return () -> jobStatusKinesisMap.get(key) != null;
    }

    public Callable<Boolean> isJobStatusAvailable(String key, String jobStatus) {
        return () -> {
            if (jobStatusKinesisMap.get(key) == null)
                return false;
            else {
                return jobStatusKinesisMap.get(key).stream()
                        .filter(item -> item.getJobStatus().equalsIgnoreCase(jobStatus)).count() > 0;
            }
        };
    }

    public List<String> getTextMessages() {
        return textMessages;
    }

    public List<String> getTextMessagesWithWaiting(String text) {
        try {
            await().atMost(Constants.TIMEOUT, TimeUnit.SECONDS).until(isTextMessageAvailable(text));
            return textMessages.stream().filter(message -> message.contains(text)).collect(Collectors.toList());
        } catch (ConditionTimeoutException ex) {
            return null;
        }
    }

    public Callable<Boolean> isTextMessageAvailable(String text) {
        return () -> textMessages.stream().filter(message -> message.contains(text)).count() > 0;
    }

    public ConcurrentMap<String, List<StatusEvent>> getStepStatusKinesisMap() {
        return stepStatusKinesisMap;
    }

    public ConcurrentMap<String, List<StatusEvent>> getJobStatusKinesisMap() {
        return jobStatusKinesisMap;
    }

    public List<StatusEvent> getUncategorizedStatusEventList() {
        return uncategorizedStatusEventList;
    }

    public List<StatusEvent> getJobStatusKinesisMapWithWaiting(String workOrderId) {
        try {
            await().atMost(Constants.LONG_TIMEOUT, TimeUnit.SECONDS).until(isjobStatusKinesisMapItemAvailable(workOrderId));
            return jobStatusKinesisMap.get(workOrderId);
        } catch (ConditionTimeoutException ex) {
            return null;
        }
    }

    public List<StatusEvent> getJobStatusKinesisMapWithWaiting(String workOrderId, int messagesAmount) {
        try {
            await().with().pollDelay(Duration.ofSeconds(5)).atMost(Constants.LONG_TIMEOUT * 2, TimeUnit.SECONDS).until(isjobStatusKinesisMapItemAvailable(workOrderId, messagesAmount));
            return jobStatusKinesisMap.get(workOrderId);
        } catch (Exception ex) {
            return null;
        }
    }

    public List<StatusEvent> getJobStatusKinesisMapByWorkOrderIdAndJobStatus(String key, String jobStatus) {
        try {
            await().with().pollDelay(Duration.ofSeconds(5)).atMost(Constants.LONG_TIMEOUT, TimeUnit.SECONDS).until(isJobItemAvailable(key, jobStatus));
            return jobStatusKinesisMap.get(key).stream()
                    .filter(statusEvent -> statusEvent.getJobStatus().equalsIgnoreCase(jobStatus)).collect(Collectors.toList());
        } catch (ConditionTimeoutException ex) {
            return Collections.emptyList();
        }
    }

    public List<StatusEvent> getJobStatusKinesisMapWithWaiting(String key, StatusMessageEnum statusMessage) {
        return getJobStatusKinesisMapWithStatusMessageContains(key, statusMessage.getValue());
    }

    private Callable<Boolean> isjobStatusKinesisMapItemAvailable(String key) {
        return () -> jobStatusKinesisMap.get(key) != null;
    }

    private Callable<Boolean> isjobStatusKinesisMapItemAvailable(String key, int messagesAmount) throws Exception {
        if (isjobStatusKinesisMapItemAvailable(key).call()) {
            return () -> jobStatusKinesisMap.get(key).size() >= messagesAmount;
        } else {
            return () -> false;
        }
    }

    public Callable<Boolean> isJobItemAvailable(String key, String jobStatus) {
        return () -> {
            if (jobStatusKinesisMap.get(key) == null) {
                return false;
            } else {
                return jobStatusKinesisMap.get(key).stream().filter(status -> status.getJobStatus().contains(jobStatus)).count() > 0;
            }
        };
    }

    public Callable<Boolean> isItemWithStatusMessageAvailable(String key, String statusMessage) {
        return () -> {
            if (jobStatusKinesisMap.get(key) == null) {
                return false;
            } else {
                return jobStatusKinesisMap.get(key).stream().filter(status -> status.getStatusMessage() != null)
                        .filter(statusEvent -> statusEvent.getStatusMessage().contains(statusMessage)).count() > 0;
            }
        };
    }

    public List<StatusEvent> getJobStatusKinesisMapWithStatusMessageContains(String key, String message) {
        try {
            await().with().pollDelay(Duration.ofSeconds(5)).atMost(Constants.LONG_TIMEOUT, TimeUnit.SECONDS).until(isItemWithStatusMessageAvailable(key, message));
            return jobStatusKinesisMap.get(key).stream()
                    .filter(statusEvent -> statusEvent.getStatusMessage() != null)
                    .filter(statusEvent -> statusEvent.getStatusMessage().contains(message)).collect(Collectors.toList());
        } catch (ConditionTimeoutException ex) {
            return null;
        }
    }

    public List<StatusEvent> getStatusMessagesByWorkOrderIdAndJobTypeAndJobStatus(String workOrderId, String jobType, String jobStatus) {
        try {
            await().with().pollDelay(Duration.ofSeconds(5)).atMost(Constants.LONG_TIMEOUT, TimeUnit.SECONDS).until(isMessageWithJobTypeAndJobStatusAvailable(workOrderId, jobType, jobStatus));
            return jobStatusKinesisMap.get(workOrderId).stream()
                    .filter(statusMessageContract -> statusMessageContract.getJobType() != null)
                    .filter(statusMessageContract -> statusMessageContract.getJobStatus() != null)
                    .filter(status -> status.getJobType().toLowerCase().contains(jobType.toLowerCase()))
                    .filter(status -> status.getJobStatus().toLowerCase().contains(jobStatus.toLowerCase()))
                    .collect(Collectors.toList());
        } catch (ConditionTimeoutException ex) {
            return Collections.emptyList();
        }
    }

    public Callable<Boolean> isMessageWithJobTypeAndJobStatusAvailable(String workOrderId, String jobType, String jobStatus) {
        return () -> {
            if (jobStatusKinesisMap.get(workOrderId) == null) {
                return false;
            } else {
                return jobStatusKinesisMap.get(workOrderId).stream()
//                        .filter(statusMessageContract -> statusMessageContract.getJobType() != null)
                        .filter(statusMessageContract -> statusMessageContract.getJobStatus() != null)
                        .filter(status -> status.getJobStatus().toLowerCase().contains(jobStatus.toLowerCase()))
//                        .filter(status -> status.getJobType().toLowerCase().contains(jobType.toLowerCase()))
                        .count() > 0;
            }
        };
    }
}
