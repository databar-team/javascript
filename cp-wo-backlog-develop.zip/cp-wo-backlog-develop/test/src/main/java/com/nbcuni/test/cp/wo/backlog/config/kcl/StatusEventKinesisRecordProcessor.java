package com.nbcuni.test.cp.wo.backlog.config.kcl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.amazon.kinesis.kcl.KinesisRecordProcessorBase;
import org.springframework.beans.factory.annotation.Autowired;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.kinesis.retrieval.KinesisClientRecord;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;

public class StatusEventKinesisRecordProcessor extends KinesisRecordProcessorBase {
    @Autowired
    protected ObjectMapper objectMapper;

    private final ConcurrentMap<String, List<StatusEvent>> stepStatusKinesisMap = StatusEventKinesisBuffer.getInstance().getStepStatusKinesisMap();
    private final ConcurrentMap<String, List<StatusEvent>> jobStatusKinesisMap = StatusEventKinesisBuffer.getInstance().getJobStatusKinesisMap();
    private final List<StatusEvent> uncategorizedStatusEventList = StatusEventKinesisBuffer.getInstance().getUncategorizedStatusEventList();

    private final List<String> textMessages = StatusEventKinesisBuffer.getInstance().getTextMessages();

    @Override
    protected void processRecord(KinesisClientRecord record) {

        byte[] data = SdkBytes.fromByteBuffer(record.data()).asByteArray();
        String message = new String(data);
        try {
            StatusEvent statusEvent = objectMapper.readValue(message, StatusEvent.class);
            if (statusEvent.getJobId() != null) {
                synchronized (stepStatusKinesisMap) {
                    if (stepStatusKinesisMap.get(statusEvent.getJobId()) != null) {
                        stepStatusKinesisMap.get(statusEvent.getJobId()).add(statusEvent);
                    } else {
                        stepStatusKinesisMap.put(statusEvent.getJobId(), new ArrayList<StatusEvent>() {{
                            add(statusEvent);
                        }});
                    }
                }
            }
            if (statusEvent.getWorkOrderId() != null) {
                synchronized (jobStatusKinesisMap) {
                    if (jobStatusKinesisMap.get(statusEvent.getWorkOrderId()) != null) {
                        jobStatusKinesisMap.get(statusEvent.getWorkOrderId()).add(statusEvent);
                    } else {
                        jobStatusKinesisMap.put(statusEvent.getWorkOrderId(), new ArrayList<StatusEvent>() {{
                            add(statusEvent);
                        }});
                    }
                }
            }
            if (statusEvent.getWorkOrderId() == null && statusEvent.getJobId() == null) {
                uncategorizedStatusEventList.add(statusEvent);
            }
        } catch (IOException e) {
            textMessages.add(message);
            System.out.println(e.getMessage());
        }
    }

    @Override
    protected ConcurrentLinkedQueue<String> getErrorQueue() {
        return null;
    }
}
