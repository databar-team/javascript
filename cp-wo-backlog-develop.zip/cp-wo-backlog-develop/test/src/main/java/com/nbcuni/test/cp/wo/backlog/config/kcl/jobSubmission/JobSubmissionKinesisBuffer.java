package com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission;

import com.nbcuni.test.cp.wo.backlog.constants.Constants;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import org.awaitility.core.ConditionTimeoutException;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.*;
import java.util.stream.Collectors;

import static com.nbcuni.test.cp.wo.backlog.constants.Constants.*;
import static org.awaitility.Awaitility.await;

public class JobSubmissionKinesisBuffer {

    private static JobSubmissionKinesisBuffer ourInstance = new JobSubmissionKinesisBuffer();

    public ConcurrentMap<String, List<JobSubmissionContract>> getJobSubmissionMessageKinesisMap() {
        return jobSubmissionMessageKinesisMap;
    }

    private ConcurrentMap<String, List<JobSubmissionContract>> jobSubmissionMessageKinesisMap;
    private ConcurrentLinkedQueue<String> kinesisErrors;
    private List<JobSubmissionContract> uncategorizedJobSubmissionMessageList;
    private final List<String> textMessages;

    public static JobSubmissionKinesisBuffer getInstance() {
        return ourInstance;
    }


    private JobSubmissionKinesisBuffer() {
        this.jobSubmissionMessageKinesisMap = new ConcurrentHashMap<>();
        this.kinesisErrors = new ConcurrentLinkedQueue<>();
        this.uncategorizedJobSubmissionMessageList = new Vector<>();
        this.textMessages = new Vector<>();
    }

    public ConcurrentLinkedQueue<String> errorQueue() {
        return kinesisErrors;
    }

    public List<JobSubmissionContract> getJobSubmissionMessageKinesisMapWithWaiting(String key) {
        try {
            await().with().pollDelay(Duration.ofSeconds(DELAY)).atMost(LONG_TIMEOUT, TimeUnit.SECONDS).until(isJobSubmissionAvailable(key));
            return jobSubmissionMessageKinesisMap.get(key);
        } catch (ConditionTimeoutException ex) {
            return Collections.emptyList();
        }

    }

    public List<JobSubmissionContract> getJobSubmissionMessageKinesisMapWithWaiting(String key, int expectedMessagesAmount) {
        try {
            await().with().pollDelay(Duration.ofSeconds(DELAY)).atMost(TIMEOUT, TimeUnit.SECONDS).until(isJobSubmissionAvailable(key, expectedMessagesAmount));
            return jobSubmissionMessageKinesisMap.get(key);
        } catch (ConditionTimeoutException ex) {
            return null;
        }

    }


    public Callable<Boolean> isJobSubmissionAvailable(String key) {
        return () -> jobSubmissionMessageKinesisMap.get(key) != null;
    }

    public Callable<Boolean> isJobSubmissionAvailable(String key, int expectedMessagesAmount) {
        return () -> {
            if (jobSubmissionMessageKinesisMap.get(key) != null) {
                return jobSubmissionMessageKinesisMap.get(key).size() >= expectedMessagesAmount;
            } else {
                return false;
            }
        };
    }


    public List<String> getTextMessages() {
        return textMessages;
    }

    public List<String> getTextMessagesWithWaiting(String text) {
        try {
            await().atMost(Constants.TIMEOUT, TimeUnit.SECONDS).until(isTextMessageAvailable(text));
            return textMessages.stream().filter(message -> message.contains(text)).collect(Collectors.toList());
        } catch (ConditionTimeoutException ex) {
            return null;
        }
    }

    public Callable<Boolean> isTextMessageAvailable(String text) {
        return () -> textMessages.stream().filter(message -> message.contains(text)).count() > 0;
    }

    public List<JobSubmissionContract> getUncategorizedJobSubmissionMessageList() {
        return uncategorizedJobSubmissionMessageList;
    }
}
