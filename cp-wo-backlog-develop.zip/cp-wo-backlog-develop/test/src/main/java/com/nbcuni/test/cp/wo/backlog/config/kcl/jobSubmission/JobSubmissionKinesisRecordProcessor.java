package com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nbcuni.test.amazon.kinesis.kcl.KinesisRecordProcessorBase;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import org.springframework.beans.factory.annotation.Autowired;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.kinesis.retrieval.KinesisClientRecord;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;

public class JobSubmissionKinesisRecordProcessor extends KinesisRecordProcessorBase {

    @Autowired
    protected ObjectMapper objectMapper;

    private final ConcurrentMap<String, List<JobSubmissionContract>> jobSubmissionRequestMessageKinesisMap = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMap();
    private final List<JobSubmissionContract> uncategorizedJobSubmissionRequestMessageList = JobSubmissionKinesisBuffer.getInstance().getUncategorizedJobSubmissionMessageList();

    private final List<String> textMessages = JobSubmissionKinesisBuffer.getInstance().getTextMessages();

    @Override
    protected void processRecord(KinesisClientRecord record) {

        byte[] data = SdkBytes.fromByteBuffer(record.data()).asByteArray();
        String message = new String(data);

        try {
            JobSubmissionContract jobSubmissionRequestMessage = objectMapper.readValue(message, JobSubmissionContract.class);
            if (jobSubmissionRequestMessage.getWorkOrder().getWorkOrderId() != null) {
                synchronized (jobSubmissionRequestMessageKinesisMap) {
                    if (jobSubmissionRequestMessageKinesisMap.get(jobSubmissionRequestMessage.getWorkOrder().getWorkOrderId()) != null) {
                        jobSubmissionRequestMessageKinesisMap.get(jobSubmissionRequestMessage.getWorkOrder().getWorkOrderId()).add(jobSubmissionRequestMessage);
                    } else {
                        jobSubmissionRequestMessageKinesisMap.put(jobSubmissionRequestMessage.getWorkOrder().getWorkOrderId(), new ArrayList<JobSubmissionContract>() {{
                            add(jobSubmissionRequestMessage);
                        }});
                    }
                }
            }  else {
                uncategorizedJobSubmissionRequestMessageList.add(jobSubmissionRequestMessage);
            }
        } catch (IOException e) {
            textMessages.add(message);
            System.out.println(e.getMessage());
        }
    }

    @Override
    protected ConcurrentLinkedQueue<String> getErrorQueue() {
        return null;
    }
}
