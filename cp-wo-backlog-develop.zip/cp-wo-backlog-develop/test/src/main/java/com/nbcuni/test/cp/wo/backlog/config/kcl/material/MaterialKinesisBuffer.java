package com.nbcuni.test.cp.wo.backlog.config.kcl.material;

import com.nbcuni.test.cp.wo.backlog.constants.Constants;
import com.nbcuni.test.cp.wo.backlog.model.MaterialRequestMessage;
import org.awaitility.core.ConditionTimeoutException;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.*;
import java.util.stream.Collectors;

import static com.nbcuni.test.cp.wo.backlog.constants.Constants.*;
import static org.awaitility.Awaitility.await;

public class MaterialKinesisBuffer {
    private static MaterialKinesisBuffer ourInstance = new MaterialKinesisBuffer();

    public ConcurrentMap<String, List<MaterialRequestMessage>> getMaterialRequestMessageKinesisMap() {
        return materialRequestMessageKinesisMap;
    }

    public static MaterialKinesisBuffer getOurInstance() {
        return ourInstance;
    }

    private ConcurrentMap<String, List<MaterialRequestMessage>> materialRequestMessageKinesisMap;
    private ConcurrentLinkedQueue<String> kinesisErrors;
    private List<MaterialRequestMessage> uncategorizedMaterialRequestMessageList;
    private final List<String> textMessages;

    public static MaterialKinesisBuffer getInstance() {
        return ourInstance;
    }


    private MaterialKinesisBuffer() {
        this.materialRequestMessageKinesisMap = new ConcurrentHashMap<>();
        this.kinesisErrors = new ConcurrentLinkedQueue<>();
        this.uncategorizedMaterialRequestMessageList = new Vector<>();
        this.textMessages = new Vector<>();
    }

    public ConcurrentLinkedQueue<String> errorQueue() {
        return kinesisErrors;
    }

    public List<MaterialRequestMessage> getMaterialRequestMessageKinesisMapWithWaiting(String key) {
        try {
            await().with().pollDelay(Duration.ofSeconds(DELAY)).atMost(TIMEOUT, TimeUnit.SECONDS).until(isMaterialMessageAvailable(key));
            return materialRequestMessageKinesisMap.get(key);
        } catch (ConditionTimeoutException ex) {
            return Collections.emptyList();
        }

    }


    public Callable<Boolean> isMaterialMessageAvailable(String key) {
        return () -> materialRequestMessageKinesisMap.get(key) != null;
    }


    public List<String> getTextMessages() {
        return textMessages;
    }

    public List<String> getTextMessagesWithWaiting(String text) {
        try {
            await().atMost(Constants.TIMEOUT, TimeUnit.SECONDS).until(isTextMessageAvailable(text));
            return textMessages.stream().filter(message -> message.contains(text)).collect(Collectors.toList());
        } catch (ConditionTimeoutException ex) {
            return null;
        }
    }

    public Callable<Boolean> isTextMessageAvailable(String text) {
        return () -> textMessages.stream().filter(message -> message.contains(text)).count() > 0;
    }

    public List<MaterialRequestMessage> getUncategorizedMaterialRequestMessageList() {
        return uncategorizedMaterialRequestMessageList;
    }
}
