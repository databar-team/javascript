package com.nbcuni.test.cp.wo.backlog.config.kcl.material;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nbcuni.test.amazon.kinesis.kcl.KinesisRecordProcessorBase;
import com.nbcuni.test.cp.wo.backlog.model.MaterialRequestMessage;
import org.springframework.beans.factory.annotation.Autowired;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.kinesis.retrieval.KinesisClientRecord;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;

public class MaterialKinesisRecordProcessor extends KinesisRecordProcessorBase {
    @Autowired
    protected ObjectMapper objectMapper;

    private final ConcurrentMap<String, List<MaterialRequestMessage>> materialRequestMessageKinesisMap = MaterialKinesisBuffer.getInstance().getMaterialRequestMessageKinesisMap();
    private final List<MaterialRequestMessage> uncategorizedMaterialRequestMessageList = MaterialKinesisBuffer.getInstance().getUncategorizedMaterialRequestMessageList();

    private final List<String> textMessages = MaterialKinesisBuffer.getInstance().getTextMessages();

    @Override
    protected void processRecord(KinesisClientRecord record) {

        byte[] data = SdkBytes.fromByteBuffer(record.data()).asByteArray();
        String message = new String(data);

        try {
            MaterialRequestMessage materialRequestMessage = objectMapper.readValue(message, MaterialRequestMessage.class);
            if (materialRequestMessage.getWorkOrderId() != null) {
                synchronized (materialRequestMessageKinesisMap) {
                    if (materialRequestMessageKinesisMap.get(materialRequestMessage.getWorkOrderId()) != null) {
                        materialRequestMessageKinesisMap.get(materialRequestMessage.getWorkOrderId()).add(materialRequestMessage);
                    } else {
                        materialRequestMessageKinesisMap.put(materialRequestMessage.getWorkOrderId(), new ArrayList<MaterialRequestMessage>() {{
                            add(materialRequestMessage);
                        }});
                    }
                }
            }  else {
                uncategorizedMaterialRequestMessageList.add(materialRequestMessage);
            }
        } catch (IOException e) {
            textMessages.add(message);
            System.out.println(e.getMessage());
        }
    }

    @Override
    protected ConcurrentLinkedQueue<String> getErrorQueue() {
        return null;
    }
}
