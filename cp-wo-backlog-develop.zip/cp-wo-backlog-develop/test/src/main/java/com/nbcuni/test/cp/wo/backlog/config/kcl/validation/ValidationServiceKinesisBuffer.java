package com.nbcuni.test.cp.wo.backlog.config.kcl.validation;

import com.nbcuni.test.cp.wo.backlog.constants.Constants;
import com.nbcuni.test.cp.wo.backlog.model.contract.ValidationContract;
import org.awaitility.core.ConditionTimeoutException;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.*;
import java.util.stream.Collectors;

import static com.nbcuni.test.cp.wo.backlog.constants.Constants.*;
import static org.awaitility.Awaitility.await;

public class ValidationServiceKinesisBuffer {

    private static ValidationServiceKinesisBuffer ourInstance = new ValidationServiceKinesisBuffer();

    public ConcurrentMap<String, List<ValidationContract>> getValidationServiceMessagesByWorkOrderId() {
        return validationServiceMessagesByWorkOrderId;
    }

    public static ValidationServiceKinesisBuffer getOurInstance() {
        return ourInstance;
    }

    private ConcurrentMap<String, List<ValidationContract>> validationServiceMessagesByWorkOrderId;
    private ConcurrentLinkedQueue<String> kinesisErrors;
    private List<ValidationContract> uncategorizedValidationServiceMessages;
    private final List<String> textMessages;

    public static ValidationServiceKinesisBuffer getInstance() {
        return ourInstance;
    }


    private ValidationServiceKinesisBuffer() {
        this.validationServiceMessagesByWorkOrderId = new ConcurrentHashMap<>();
        this.kinesisErrors = new ConcurrentLinkedQueue<>();
        this.uncategorizedValidationServiceMessages = new Vector<>();
        this.textMessages = new Vector<>();
    }

    public ConcurrentLinkedQueue<String> errorQueue() {
        return kinesisErrors;
    }

    public synchronized List<ValidationContract> getValidationServiceMessagesWithWaiting(String key) {
        try {
            await().with().pollDelay(Duration.ofSeconds(DELAY)).atMost(LONG_TIMEOUT, TimeUnit.SECONDS).until(isValidationServiceMessageByWorkOrderIdAvailable(key));
            return validationServiceMessagesByWorkOrderId.get(key);
        } catch (ConditionTimeoutException ex) {
            return Collections.emptyList();
        }

    }


    private Callable<Boolean> isValidationServiceMessageByWorkOrderIdAvailable(String key) {
        return () -> validationServiceMessagesByWorkOrderId.get(key) != null;
    }


    public List<String> getTextMessages() {
        return textMessages;
    }

    public List<String> getTextMessagesWithWaiting(String text) {
        try {
            await().atMost(Constants.TIMEOUT, TimeUnit.SECONDS).until(isTextMessageAvailable(text));
            return textMessages.stream().filter(message -> message.contains(text)).collect(Collectors.toList());
        } catch (ConditionTimeoutException ex) {
            return Collections.emptyList();
        }
    }

    private Callable<Boolean> isTextMessageAvailable(String text) {
        return () -> textMessages.stream().filter(message -> message.contains(text)).count() > 0;
    }

    public List<ValidationContract> getUncategorizedValidationServiceMessages() {
        return uncategorizedValidationServiceMessages;
    }
}
