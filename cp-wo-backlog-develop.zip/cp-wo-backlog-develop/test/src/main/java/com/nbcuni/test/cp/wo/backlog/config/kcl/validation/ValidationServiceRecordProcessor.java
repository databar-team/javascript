package com.nbcuni.test.cp.wo.backlog.config.kcl.validation;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nbcuni.test.amazon.kinesis.kcl.KinesisRecordProcessorBase;
import com.nbcuni.test.cp.wo.backlog.model.contract.ValidationContract;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.kinesis.retrieval.KinesisClientRecord;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;

public class ValidationServiceRecordProcessor extends KinesisRecordProcessorBase {
    @Autowired
    private ObjectMapper objectMapper;
    protected Logger logger = LogManager.getLogger();

    private final ConcurrentMap<String, List<ValidationContract>> validationServiceMessagesByWorkOrderId = ValidationServiceKinesisBuffer.getInstance().getValidationServiceMessagesByWorkOrderId();
    private final List<ValidationContract> uncategorizedValidationServiceMessages = ValidationServiceKinesisBuffer.getInstance().getUncategorizedValidationServiceMessages();

    private final List<String> textMessages = ValidationServiceKinesisBuffer.getInstance().getTextMessages();

    @Override
    protected void processRecord(KinesisClientRecord record) {

        byte[] data = SdkBytes.fromByteBuffer(record.data()).asByteArray();
        String message = new String(data);
        logger.info("Processing Validation message: {}", message);
        try {
            ValidationContract validationContract = objectMapper.readValue(message, ValidationContract.class);
            if (validationContract.getWorkOrder().getWorkOrderId() != null) {
                synchronized (validationServiceMessagesByWorkOrderId) {
                    if (validationServiceMessagesByWorkOrderId.get(validationContract.getWorkOrder().getWorkOrderId()) != null)
                        validationServiceMessagesByWorkOrderId.get(validationContract.getWorkOrder().getWorkOrderId()).add(validationContract);
                    else {
                        List<ValidationContract> validationContracts = new ArrayList<>();
                        validationContracts.add(validationContract);
                        validationServiceMessagesByWorkOrderId.put(validationContract.getWorkOrder().getWorkOrderId(), validationContracts);
                    }
                }
            } else
                uncategorizedValidationServiceMessages.add(validationContract);
        } catch (IOException e) {
            textMessages.add(message);
            logger.error(e.getMessage());
            logger.error("Couldn't parse a Validation message {}", message);
        }

    }

    @Override
    protected ConcurrentLinkedQueue<String> getErrorQueue() {
        return new ConcurrentLinkedQueue<>();
    }
}
