package com.nbcuni.test.cp.wo.backlog.config.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import lombok.Data;

@Component
@Data
public class ServiceProperties {

	@Value("${aws.dynamodb.workOrderTable}")
	private String workOrderTable;

}
