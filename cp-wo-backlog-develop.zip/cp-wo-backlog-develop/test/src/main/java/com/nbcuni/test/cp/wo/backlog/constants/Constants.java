package com.nbcuni.test.cp.wo.backlog.constants;

public class Constants {

    public static final String WORK_ORDER_BACKLOG_JOB_TYPE = "WorkOrderBacklog";

    private Constants() {}

    public static final String WORK_ORDER_ID = "workOrderId";
    public static final Integer DB_WAIT_TIMEOUT = 5000;
    public static final Long LONG_TIMEOUT = 120l;
    public static final Long TIMEOUT = 90l;
    public static final Long DELAY = 10l;
    public static final String STATUS_EVENT_REQUESTER = "requester";
    public static final String JOB_ID = "jobId";
    public static final String STATUS_EVENT_CP_ID = "cpId";
    public static final String STATUS_EVENT_JOB_TYPE = "jobType";
    public static final String STATUS_EVENT_JOB_STATUS = "jobStatus";
    public static final String STATUS_EVENT_STATUS_MESSAGE = "statusMessage";
    public static final String STATUS_EVENT_PERSENT_COMPLETE = "percentComplete";
    public static final String STATUS_EVENT_TIMESTAMP = "timestamp";
    public static final String STATUS_EVENT_ERRORS = "errors";
    public static final String APPLICATION_JSON = "application/json";
    public static final String TRANSLATOR_REQUESTER = "Translator";
    public static final String MATERIAL_SERVICE_JOB_TYPE = "Material";

}