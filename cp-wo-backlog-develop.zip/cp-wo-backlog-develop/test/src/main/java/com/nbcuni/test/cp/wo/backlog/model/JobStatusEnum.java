package com.nbcuni.test.cp.wo.backlog.model;

public enum JobStatusEnum {

    SUBMITTED("Submitted"),
    QUEUED("Queued"),
    RUNNING("Running"),
    ERROR("Error"),
    DONE("Done"),
    CANCEL_REQUESTED("CancelRequested"),
    CANCELLED("Cancelled");

    JobStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static JobStatusEnum fromValue(String value) {
        for (JobStatusEnum step : values()) {
            if (step.value.equalsIgnoreCase(value)) {
                return step;
            }
        }
        return null;
    }

    String value;
}
