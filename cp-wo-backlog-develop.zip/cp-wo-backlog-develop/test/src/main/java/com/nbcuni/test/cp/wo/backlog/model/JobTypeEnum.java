package com.nbcuni.test.cp.wo.backlog.model;

public enum JobTypeEnum {

    WORK_ORDER_BACKLOG("WorkOrderBacklog"),
    MATERIAL("Material"),
    WORKORDER_LISTENER("cp-WorkorderListener"),
    WORK_ORDER_INGEST("cp-WorkorderIngest"),
    WORK_ORDER_ACTION("cp-WorkorderAction"),
    CP_VALIDATION("cp-Validation");

    JobTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    String value;
}
