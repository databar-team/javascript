package com.nbcuni.test.cp.wo.backlog.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MaterialRequestMessage {
    @JsonProperty("workOrderId")
    private String workOrderId;
    @JsonProperty("materialId")
    private String materialId;
    @JsonProperty("materialMetadataOutputFile")
    private String materialMetadataOutputFile;
    @JsonProperty("jobId")
    private String jobId;
    @JsonProperty("requester")
    private String requester;
}
