package com.nbcuni.test.cp.wo.backlog.model;

public enum RequesterEnum {
    TRANSLATOR("Translator"),
    WORK_ORDER_EVENT("cp-WorkorderEvent"),
    VALIDATION("cp-Validation");

    RequesterEnum(String requester) {
        this.requester = requester;
    }

    private String requester;

    public String getValue() {
        return requester;
    }
}