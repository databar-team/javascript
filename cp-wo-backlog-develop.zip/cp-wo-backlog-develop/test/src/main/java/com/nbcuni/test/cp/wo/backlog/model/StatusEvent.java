package com.nbcuni.test.cp.wo.backlog.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nbcuni.test.cp.wo.backlog.constants.Constants;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

@Setter
@Getter
@ToString
public class StatusEvent {
    @JsonProperty("requester")
    private String requester;
    @JsonProperty("jobId")
    private String jobId;
    @JsonProperty("cpId")
    private String cpId;
    @JsonProperty("workOrderId")
    private String workOrderId;
    @JsonProperty("jobType")
    private String jobType;
    @JsonProperty("jobStatus")
    private String jobStatus;
    @JsonProperty("statusMessage")
    private String statusMessage;
    @JsonProperty("percentComplete")
    private Integer percentComplete;
    @JsonProperty("timestamp")
    private String timestamp;
    @JsonProperty("errors")
    private ArrayList<Map<String, Object>> errors;

    public JSONObject getJSONObject() {
        JSONObject statusEventMessage = new JSONObject();
        statusEventMessage.put(Constants.STATUS_EVENT_REQUESTER, this.requester);
        statusEventMessage.put(Constants.JOB_ID, this.jobId);
        statusEventMessage.put(Constants.STATUS_EVENT_CP_ID, this.cpId);
        statusEventMessage.put(Constants.WORK_ORDER_ID, this.workOrderId);
        statusEventMessage.put(Constants.STATUS_EVENT_JOB_TYPE, this.jobType);
        statusEventMessage.put(Constants.STATUS_EVENT_JOB_STATUS, this.jobStatus);
        statusEventMessage.put(Constants.STATUS_EVENT_PERSENT_COMPLETE, this.percentComplete);
        statusEventMessage.put(Constants.STATUS_EVENT_TIMESTAMP, this.timestamp);
        statusEventMessage.put(Constants.STATUS_EVENT_STATUS_MESSAGE, this.statusMessage);
        statusEventMessage.put(Constants.STATUS_EVENT_ERRORS, this.errors);
        return statusEventMessage;
    }
}
