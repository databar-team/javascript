package com.nbcuni.test.cp.wo.backlog.model;

public enum StatusMessageEnum {

    MATERIAL_REQUESTED("materialRequested"),
    MATERIALS_VALID("materialsValid"),
    ORDER_VALID("orderValid"),
    VALIDATING_WORKORDER_AND_MATERIALS("Validating Workorder and Materials."),
    VALIDATION_COMPLETE("Validations Complete. Requested Fulfillment under"),
    WORKORDER_CLEARED_FROM_BACKLOG("Workorder Cleared from Backlog."),
    RECEIVED_NEW_WORK_ORDER("Received New Work Order"),
    REJECTED_NEW_WORK_ORDER("Rejected New Work Order"),
    REQUESTING_VALIDATION("Requesting Validation"),
    WORKORDER_VALIDATION_FAILED("Workorder Validation Failed");


    StatusMessageEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    String value;
}
