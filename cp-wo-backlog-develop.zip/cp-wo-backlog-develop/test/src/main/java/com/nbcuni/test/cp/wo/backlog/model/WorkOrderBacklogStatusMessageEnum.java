package com.nbcuni.test.cp.wo.backlog.model;

public enum WorkOrderBacklogStatusMessageEnum {

    RECEIVED("Received", "Received New Work Order %s"),
    REJECTED("Error", "Rejected New Work Order"),
    REQUESTING_VALIDATION("Running", "Requesting Validation"),
    VALIDATIONS_COMPLETE( "Done", "Validations Complete. Requested Fulfillment under"),
    MATERIAL_REQUESTED("Queued", "materialRequested"),
    WO_VALIDATION_FAILED("Error", "Workorder Validation Failed");

    public String getRequester() {
        return requester;
    }

    public String getJobType() {
        return jobType;
    }

    public String getJobStatus() {
        return jobStatus;
    }

    public String getStatusMessagePattern() {
        return statusMessagePattern;
    }

    WorkOrderBacklogStatusMessageEnum(String jobStatus, String statusMessagePattern){
        this.requester = "Translator";
        this.jobType = "WorkOrderBacklog";
        this.jobStatus = jobStatus;
        this.statusMessagePattern = statusMessagePattern;
    }

    String requester;
    String jobType;
    String jobStatus;
    String statusMessagePattern;

}
