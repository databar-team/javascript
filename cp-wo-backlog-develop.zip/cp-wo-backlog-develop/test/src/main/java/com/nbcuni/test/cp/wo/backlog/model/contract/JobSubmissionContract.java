package com.nbcuni.test.cp.wo.backlog.model.contract;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
public class JobSubmissionContract {

    private String cpId;
    private WorkOrderContract workOrder;
    private String materialMetadata;

}
