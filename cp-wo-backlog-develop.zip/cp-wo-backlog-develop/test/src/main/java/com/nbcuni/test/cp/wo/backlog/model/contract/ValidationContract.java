package com.nbcuni.test.cp.wo.backlog.model.contract;

import com.nbcuni.test.utils.contract.annotations.SchemaElement;
import lombok.*;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@SchemaElement(path = "")
public class ValidationContract {
    private String requester;
    private String jobId;
    private Object jobContext;
    private WorkOrderContract workOrder;
    private String rawMaterialMetadataInputFile;
    private String materialMetadataOutputFile;
}
