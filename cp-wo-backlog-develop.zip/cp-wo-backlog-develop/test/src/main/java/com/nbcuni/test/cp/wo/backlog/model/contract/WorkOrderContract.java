package com.nbcuni.test.cp.wo.backlog.model.contract;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@EqualsAndHashCode
@ToString
public class WorkOrderContract {
    private String workOrderId;
    private String title;
    private String workOrderAction;
    private String originalCpId;
    private Long dueDate;
    private Object profile;
    private Boolean metadataApproved;
    private Integer priority;
    private Boolean deliveryRequired;
    private Object pxfInfo;
    private List<Object> requiredComponents;
    private List<Object> videoSource;
    private Object imageSource;
    private String audioAndCaptionPreference;
}
