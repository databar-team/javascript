package com.nbcuni.test.cp.wo.backlog.model.db;

import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.VideoSource;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.Accessors;

@DynamoDBTable(tableName = "    ")
@Accessors(chain = true)
@EqualsAndHashCode
@ToString
public class WorkOrderDb {

    @DynamoDBHashKey
    private String workOrderId;

    @DynamoDBTyped(DynamoDBMapperFieldModel.DynamoDBAttributeType.BOOL)
    @DynamoDBAttribute(attributeName = "validated")
    private Boolean validated;

    @DynamoDBAttribute(attributeName = "materialRequested")
    private String materialRequested;

    @DynamoDBAttribute(attributeName = "materialRetrieval")
    private String materialRetrieval;

    @DynamoDBAttribute(attributeName = "videoSource")
    private VideoSource videoSource;

    @DynamoDBAttribute(attributeName = "workOrderId")
    public String getWorkOrderId() {
        return workOrderId;
    }

    @DynamoDBAttribute(attributeName = "workOrderAction")
    public String workOrderAction;

    public void setWorkOrderId(String workOrderId) {
        this.workOrderId = workOrderId;
    }

    public Boolean isValidated() {
        return validated;
    }

    public void setValidated(Boolean validated) {
        this.validated = validated;
    }

    public String getMaterialRequested() {
        return materialRequested;
    }

    public void setMaterialRequested(String materialRequested) {
        this.materialRequested = materialRequested;
    }

    public String getMaterialRetrieval() {
        return materialRetrieval;
    }

    public void setMaterialRetrieval(String materialRetrieval) {
        this.materialRetrieval = materialRetrieval;
    }

    public String getWorkOrderAction() {
        return workOrderAction;
    }

    public void setWorkOrderAction(String workOrderAction) {
        this.workOrderAction = workOrderAction;
    }
}
