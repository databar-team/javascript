package com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@DynamoDBDocument
@ToString
public class Branding {
    private List<String> preRoll;

    public Branding() {
        setPreRoll(new ArrayList<>());
    }

    @DynamoDBIgnore
    public JSONObject getJSONObject() {
        return new JSONObject();
    }
}
