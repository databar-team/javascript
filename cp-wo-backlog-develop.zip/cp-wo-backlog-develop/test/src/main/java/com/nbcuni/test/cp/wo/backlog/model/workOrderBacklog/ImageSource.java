package com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import wiremock.net.minidev.json.JSONObject;

@Getter
@Setter
@ToString
public class ImageSource {
    public JSONObject getJSONObject() {
        return  new JSONObject();
    }
}
