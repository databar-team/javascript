package com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import wiremock.net.minidev.json.JSONObject;

@Getter
@Setter
@ToString
public class Package {
    private String id;
    private String name;
    public Package(){
        setId("fd9954fd-7460-4cf2-9596-9c0a27155b88");
        setName("PEACOCK-LTA");
    }

    public JSONObject getJSONObject() {
        return  new JSONObject();
    }
}
