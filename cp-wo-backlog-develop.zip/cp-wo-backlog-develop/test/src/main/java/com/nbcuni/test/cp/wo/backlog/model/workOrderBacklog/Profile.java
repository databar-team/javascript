package com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import wiremock.net.minidev.json.JSONArray;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
public class Profile {
    private String id;
    private String name;
    private List<Package> packages;

    public Profile() {
        this.name = "SQE_AT_PROFILE";
        this.id = "SQE_AT_PROFILE_ID";
        Package packageItem = new Package();
        List<Package> packageList = new ArrayList<>();
        packageList.add(packageItem);
        setPackages(packageList);
    }

    public JSONObject getJSONObject() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", this.getId());
        jsonObject.put("name", this.getName());
        JSONArray jsonArray = new JSONArray();
        packages.forEach(packageItem -> jsonArray.add(packageItem.getJSONObject()));
        jsonObject.put("packages", jsonArray);
        return jsonObject;
    }
}
