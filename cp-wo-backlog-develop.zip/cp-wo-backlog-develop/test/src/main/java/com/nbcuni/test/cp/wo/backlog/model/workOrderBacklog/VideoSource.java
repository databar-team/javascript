package com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import wiremock.net.minidev.json.JSONArray;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@DynamoDBDocument
@ToString
public class VideoSource {
    private String id;
    private Branding branding;
    private List<String> promoPool;
    private String tvdNumber;

    public VideoSource() {
        setId("SQE_AT_" + System.currentTimeMillis());
        setBranding(new Branding());
        setTvdNumber("A923");
        List<String> promoPoolList = new ArrayList<>();
        setPromoPool(promoPoolList);
    }

    @DynamoDBIgnore
    public JSONObject getJSONObject() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", this.getId());
        jsonObject.put("TVDNumber", this.getTvdNumber());
        jsonObject.put("branding", this.branding.getJSONObject());
        JSONArray jsonArray = new JSONArray();
        jsonArray.addAll(promoPool);
        jsonObject.put("promoPool", jsonArray);
        return jsonObject;
    }
}
