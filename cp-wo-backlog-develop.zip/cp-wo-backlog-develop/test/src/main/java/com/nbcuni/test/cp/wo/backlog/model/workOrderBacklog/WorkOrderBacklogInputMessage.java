package com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nbcuni.test.cp.wo.backlog.constants.Constants;
import com.nbcuni.test.cp.wo.backlog.model.contract.WorkOrderContract;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import wiremock.net.minidev.json.JSONArray;
import wiremock.net.minidev.json.JSONObject;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Getter
@Setter
@EqualsAndHashCode
@DynamoDBDocument
@ToString
public class WorkOrderBacklogInputMessage {

    protected ObjectMapper objectMapper;

    private String s3 = "s3://";
    private String materials = "materials";

    @DynamoDBIgnore
    static AtomicInteger messagesGenerated = new AtomicInteger(0);

    private String workOrderId;
    private String title;
    private Long dueDate;
    private Profile profile;
    boolean metadataApproved;
    int priority;
    List<String> requiredComponents;
    List<VideoSource> videoSource;
    ImageSource imageSource;
    private Boolean validated;
    private String materialRequested;
    private String materialRetrieval;
    private String workOrderAction;
    private String originalCpId;
    private String pxfInfo;
    private Boolean deliveryRequired;
    private String audioAndCaptionPreference;

    public void setWorkOrderContract(WorkOrderContract workOrderContract) {
        this.workOrderContract = workOrderContract;
        this.getWorkOrderContract().setWorkOrderId(generateWorkOrderId());
        this.workOrderId = this.getWorkOrderContract().getWorkOrderId();
    }

    private WorkOrderContract workOrderContract;

    public WorkOrderBacklogInputMessage(ObjectMapper objectMapper){
        this.objectMapper = objectMapper;
        workOrderContract = new WorkOrderContract();
    }

    public WorkOrderBacklogInputMessage() {
        this.workOrderId = generateWorkOrderId();
        this.title = getWorkOrderId() + "_TITLE";
        this.dueDate = System.currentTimeMillis();
        this.metadataApproved = true;
        this.priority = 1;
        this.profile = new Profile();
        this.workOrderAction = "CREATE";
        setVideoSource(createVideoSourcesList());
        setRequiredComponents(createRequiredComponentsList());
        setImageSource(new ImageSource());
        this.pxfInfo = "<?xmlversion=\"1.0\"?><PharosCs><CommandListsessionKey=\"127.0.0.1-8e0ae496-ad87-457a-a9bf-14fc68b98dd7\"><CommandexecutionTime=\"0.226453927\"generalType=\"Placing\"method=\"get\"subsystem=\"placing\"success=\"true\"type=\"response\"><Output><Placingid=\"389530\"><PlacingId>TL-T34724-AXP89-393894408</PlacingId><StateName>Ordered</StateName><StartDate>2020-01-21T04:59:59.000</StartDate><StateMachine>ContentDistribution</StateMachine><EndDate>9999-12-31T23:00:00.000</EndDate><UserName>system</UserName><CreatedDate>2020-01-20T15:41:20.000</CreatedDate><LastEdited>2020-01-20T15:41:20.000</LastEdited><DeleteMark>0</DeleteMark><AutoPlacing>false</AutoPlacing><PlacingParcelList/><TagList><Tagid=\"121862\"><TagType>DeliveryType</TagType><Value>Digital</Value><Ordinality>1</Ordinality><TimeAdded>2018-03-02T15:47:48.000</TimeAdded><Type>set</Type></Tag></TagList><ShortTextList><ShortTextid=\"14381934\"><Key>14381934</Key><ShortTextType>AssetShare</ShortTextType><Value>false</Value><Ordinality>1</Ordinality><Type>boolean</Type></ShortText></ShortTextList><FullTextList><FullTextid=\"1317317\"><Key>1317317</Key><FullTextType>LocationOverride</FullTextType><Ordinality>1</Ordinality><Type>text</Type></FullText></FullTextList><ProfileStatus><Name>TL-T34724-AXP89-393894408</Name><Result>ok</Result><Statuses/></ProfileStatus><ProfilePolicy>Destination</ProfilePolicy><StateNameI18nKey>state.ordered</StateNameI18nKey><StateMachineId>140</StateMachineId><StateId>56</StateId><Notes/></Placing></Output></Command></CommandList></PharosCs>";
        this.deliveryRequired = true;
        this.audioAndCaptionPreference = "NLD-Surround+Stereo+ClosedCaptionEnglish(US)";
    }

    @DynamoDBIgnore
    static synchronized String generateWorkOrderId() {
        return "SQE_AT_WO_BACKLOG_" + System.currentTimeMillis() + "_" + messagesGenerated.getAndIncrement();
    }

    @DynamoDBIgnore
    public JSONObject getJSONObject() {
        JSONObject workOrderBacklogMessage = new JSONObject();
        workOrderBacklogMessage.put(Constants.WORK_ORDER_ID, this.getWorkOrderId());
        workOrderBacklogMessage.put("title", this.getTitle());
        workOrderBacklogMessage.put("dueDate", this.getDueDate());
        workOrderBacklogMessage.put("profile", this.getProfile().getJSONObject());
        workOrderBacklogMessage.put("metadataApproved", this.isMetadataApproved());
        workOrderBacklogMessage.put("priority", this.priority);
        JSONArray requiredComponentsJSONArray = new JSONArray();
        requiredComponentsJSONArray.addAll(this.getRequiredComponents());
        workOrderBacklogMessage.put("requiredComponents", requiredComponentsJSONArray);
        JSONArray videoSourceJSONArray = new JSONArray();
        this.getVideoSource().forEach(videoSourceItem -> videoSourceJSONArray.add(videoSourceItem.getJSONObject()));
        workOrderBacklogMessage.put("videoSource", videoSourceJSONArray);
        workOrderBacklogMessage.put("imageSource", this.getImageSource().getJSONObject());
        workOrderBacklogMessage.put("workOrderAction", this.getWorkOrderAction());
        workOrderBacklogMessage.put("pxfInfo", this.pxfInfo);
        workOrderBacklogMessage.put("originalCpId", this.originalCpId);
        workOrderBacklogMessage.put("deliveryRequired", this.deliveryRequired);
        workOrderBacklogMessage.put("audioAndCaptionPreference", this.audioAndCaptionPreference);
        return workOrderBacklogMessage;
    }

    @DynamoDBIgnore
    public JSONObject getFullJSONObject() {
        JSONObject workOrderBacklogMessage = getJSONObject();
        workOrderBacklogMessage.put("materialRequested", this.materialRequested);
        workOrderBacklogMessage.put("materialRetrieval", this.materialRetrieval);
        workOrderBacklogMessage.put("validated", this.validated);
        workOrderBacklogMessage.put("originalCpId", this.originalCpId);
        return workOrderBacklogMessage;
    }

    public JSONObject getJSONObjectFromContract(){
        JSONObject workOrderBacklogMessage = new JSONObject();

        workOrderBacklogMessage.put("workOrderId", this.getWorkOrderContract().getWorkOrderId());
        workOrderBacklogMessage.put("title", this.getWorkOrderContract().getTitle());
        workOrderBacklogMessage.put("workOrderAction", this.getWorkOrderContract().getWorkOrderAction());
        workOrderBacklogMessage.put("originalCpId", this.getWorkOrderContract().getOriginalCpId());
        workOrderBacklogMessage.put("dueDate", this.getWorkOrderContract().getDueDate());
        workOrderBacklogMessage.put("profile", this.getWorkOrderContract().getProfile());
        workOrderBacklogMessage.put("metadataApproved", this.getWorkOrderContract().getMetadataApproved());
        workOrderBacklogMessage.put("priority", this.getWorkOrderContract().getPriority());
        workOrderBacklogMessage.put("deliveryRequired", this.getWorkOrderContract().getDeliveryRequired());
        workOrderBacklogMessage.put("pxfInfo", this.getWorkOrderContract().getPxfInfo());
        JSONArray requiredComponentsJSONArray = new JSONArray();
        requiredComponentsJSONArray.addAll(this.getWorkOrderContract().getRequiredComponents());
        workOrderBacklogMessage.put("requiredComponents", requiredComponentsJSONArray);
        JSONArray videoSourceJSONArray = new JSONArray();
        videoSourceJSONArray.addAll(this.getWorkOrderContract().getVideoSource());
        workOrderBacklogMessage.put("videoSource", videoSourceJSONArray);
        workOrderBacklogMessage.put("imageSource", this.getWorkOrderContract().getImageSource());
        workOrderBacklogMessage.put("audioAndCaptionPreference", this.getWorkOrderContract().getAudioAndCaptionPreference());
        workOrderBacklogMessage.put("materialRequested", this.materialRequested);
        workOrderBacklogMessage.put("materialRetrieval", this.materialRetrieval);
        return workOrderBacklogMessage;
    }

    @DynamoDBIgnore
    public String getMaterialSetPath() {
        return this.getWorkOrderId() +
                "/" +
                materials +
                "/" +
                "materialMetadataFile.json";
    }

    @DynamoDBIgnore
    public String getMaterialSetPath(String jobId) {
        return this.getWorkOrderId() +
                "/" +
                jobId +
                "/" +
                materials +
                "/" +
                "materialMetadataFile.json";
    }

    @DynamoDBIgnore
    public String getRawMaterialSetPath(String jobId) {
        return this.getWorkOrderId() +
                "/" +
                jobId +
                "/" +
                materials +
                "/" +
                "rawMaterialMetadataFile.json";
    }

    @DynamoDBIgnore
    public String getMaterialMetadataOutputFilePath(String environment) {
        return s3 +
                environment +
                "/" +
                getMaterialSetPath();
    }

    @DynamoDBIgnore
    public String getMaterialMetadataOutputFilePath(String environment, String jobId) {
        return s3 +
                environment +
                "/" +
                getMaterialSetPath(jobId);
    }

    @DynamoDBIgnore
    public String getRawMaterialMetadataOutputFilePath(String environment, String jobId) {
        return s3 +
                environment +
                "/" +
                getRawMaterialSetPath(jobId);
    }

    private List<VideoSource> createVideoSourcesList() {
        VideoSource videoSourceItem = new VideoSource();
        List<VideoSource> videoSourceList = new ArrayList<>();
        videoSourceList.add(videoSourceItem);
        return videoSourceList;
    }

    private List<String> createRequiredComponentsList() {
        List<String> requiredComponentsList = new ArrayList<>();
        requiredComponentsList.add("video");
        return requiredComponentsList;
    }

}
