package com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.packages;

import lombok.ToString;
import wiremock.net.minidev.json.JSONObject;
@ToString
public class Image {
    public JSONObject getJSONObject() {
        return  new JSONObject();
    }
}
