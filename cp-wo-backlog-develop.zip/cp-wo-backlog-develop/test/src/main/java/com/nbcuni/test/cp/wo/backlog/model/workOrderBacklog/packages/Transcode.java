package com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.packages;

import lombok.ToString;

@ToString
public class Transcode {
}
