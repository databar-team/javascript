package com.nbcuni.test.cp.wo.backlog.tests;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMappingException;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.kinesis.producer.UserRecord;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagement;
import com.amazonaws.services.simplesystemsmanagement.model.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.nbcuni.test.amazon.common.AmazonClientConfig;
import com.nbcuni.test.amazon.dynamodb.AmazonDynamoDBConfig;
import com.nbcuni.test.amazon.dynamodb.AmazonDynamoDBService;
import com.nbcuni.test.amazon.dynamodb.DynamoDbProperties;
import com.nbcuni.test.amazon.kinesis.kcl.StateListener;
import com.nbcuni.test.amazon.kinesis.kpl.KinesisProducerProperties;
import com.nbcuni.test.amazon.kinesis.kpl.KinesisProducerService;
import com.nbcuni.test.amazon.s3.S3Service;
import com.nbcuni.test.cp.wo.backlog.builders.WorkOrderBuilder;
import com.nbcuni.test.cp.wo.backlog.config.*;
import com.nbcuni.test.cp.wo.backlog.config.kcl.KinesisConsumers;
import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.material.MaterialKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.validation.ValidationServiceKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.properties.ServiceProperties;
import com.nbcuni.test.cp.wo.backlog.constants.Constants;
import com.nbcuni.test.cp.wo.backlog.model.MaterialRequestMessage;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.contract.ValidationContract;
import com.nbcuni.test.cp.wo.backlog.model.contract.WorkOrderContract;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.utils.JsonProcessor;
import org.awaitility.core.ConditionTimeoutException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;

import com.nbcuni.test.amazon.common.AwsCommonProperties;
import com.nbcuni.test.amazon.kinesis.AmazonKinesisConfig;
import com.nbcuni.test.utils.DataGenerator;
import com.nbcuni.test.utils.DataGeneratorConfig;
import com.nbcuni.test.utils.Logger;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Optional;
import software.amazon.kinesis.coordinator.Scheduler;
import wiremock.net.minidev.json.JSONObject;

import java.io.*;
import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

import static com.nbcuni.test.cp.wo.backlog.constants.Constants.*;
import static org.awaitility.Awaitility.await;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {ServiceConfiguration.class, AmazonKinesisConfig.class, DataGeneratorConfig.class,
        AmazonClientConfig.class, AmazonDynamoDBConfig.class, KclConfiguration.class,
        ValidationServiceKclConfiguration.class, MaterialServiceKclConfiguration.class})
public class BaseTest extends AbstractTestNGSpringContextTests {

    private static final String MATERIAL_SET_TEMPLATE_PATH = "src/main/resources/templates/materialMetadataFile.json";
    private static final String RAW_MATERIAL_SET_TEMPLATE_PATH = "src/main/resources/templates/material_valid.json";
    protected static final String VALIDATION_CONTRACT_LOCATION = "src/main/resources/templates/cloudpipelinevalidationcontract-swagger.yaml";
    protected static final Class VALIDATION_CONTRACT_CLASS = ValidationContract.class;
    protected static final String VALIDATION_MODEL = "sdfsd";
    public static String phaseBefore = "None";

    @Autowired
    protected AwsCommonProperties awsCommonProperties;

    @Autowired
    protected ServiceProperties serviceProperties;

    @Autowired
    protected KinesisProducerProperties woBacklogEventStreamKinesisProducerProperties;

    @Autowired
    @Qualifier("statusEventStreamKinesisProducerProperties")
    protected KinesisProducerProperties statusEventStreamKinesisProducerProperties;

    @Autowired
    protected KinesisProducerService kinesisProducerService;

    @Autowired
    protected KinesisConsumers kinesisConsumers;

    @Autowired
    protected DataGenerator dataGenerator;

    @Autowired
    private DynamoDBMapper dynamoDBMapper;

    @Autowired
    protected WorkOrderBuilder workOrderBuilder;

    @Autowired
    protected ObjectMapper objectMapper;

    @Value("${aws.s3.bucketName}")
    protected String s3MaterialStorage;

    @Value("${phase}")
    protected String currentPhase;

    @Autowired
    protected S3Service s3Service;

    @Autowired
    protected AmazonDynamoDBService dbService;

    @Autowired
    @Qualifier("schedulerJobSubmissionStream")
    Scheduler schedulerJobSubmissionStream;

    @Autowired
    @Qualifier("stateListenerJobSubmissionStream")
    StateListener stateListenerJobSubmissionStream;

    @Autowired
    @Qualifier("validationServiceScheduler")
    Scheduler validationServiceScheduler;

    @Autowired
    @Qualifier("validationServiceStateListener")
    StateListener validationServiceStateListener;

    @Autowired
    @Qualifier("materialServiceScheduler")
    Scheduler materialServiceScheduler;

    @Autowired
    @Qualifier("materialServiceStateListener")
    StateListener materialServiceStateListener;

    @Autowired
    DynamoDbProperties dynamoDbProperties;

    @Autowired
    protected DynamoDB dynamoDB;

    @Autowired
    protected AWSSimpleSystemsManagement awsSimpleSystemsManagement;

    @Autowired
    protected S3ServiceUtils s3ServiceUtils;

    protected Logger testLogger = new Logger();

    @BeforeSuite(alwaysRun = true)
    public void setup() throws Exception {
        this.springTestContextPrepareTestInstance();
        phaseBefore = getCurrentPhase();
        testLogger.step("Inside beforeSuite. Current phase: " + phaseBefore);
        kinesisConsumers.addKinesisConsumer(schedulerJobSubmissionStream, stateListenerJobSubmissionStream);
        kinesisConsumers.addKinesisConsumer(validationServiceScheduler, validationServiceStateListener);
        kinesisConsumers.addKinesisConsumer(materialServiceScheduler, materialServiceStateListener);
    }

    @Parameters({"phase"})
    @BeforeTest(alwaysRun = true)
    public void testInitialization(@Optional("None") String expectedPhase) throws Exception {
        this.springTestContextPrepareTestInstance();
        testLogger.info("Inside beforeTest");
        if (!expectedPhase.equalsIgnoreCase("None")) {
            boolean isSet = setPhase(expectedPhase);
            testLogger.info("Setting expected phase: " + expectedPhase + " RESULT: " + isSet);
        }
        cleanupS3WorkStorage(s3MaterialStorage, "SQE_AT_");
    }

    protected String getCurrentPhase() {
        GetParameterRequest getParameterRequest = new GetParameterRequest();
        getParameterRequest.setName(currentPhase);
        GetParameterResult getParameterResult = awsSimpleSystemsManagement.getParameter(getParameterRequest);
        return getParameterResult.getParameter().getValue();
    }

    protected boolean setPhase(String phase) {
        if (phaseBefore.equalsIgnoreCase(phase)) {
            testLogger.info("Phase " + phase + " is set for property " + currentPhase + ". No changes is required");
            return false;
        } else {
            testLogger.info("Current phase: " + phaseBefore + " Expected phase: "+ phase + " Setting expected phase...");
            PutParameterRequest putParameterRequest = new PutParameterRequest();
            putParameterRequest.setOverwrite(true);
            putParameterRequest.setValue(phase);
            putParameterRequest.setName(currentPhase);
            PutParameterResult putParameterResult = awsSimpleSystemsManagement.putParameter(putParameterRequest);
            return putParameterResult.getSdkHttpMetadata().getHttpStatusCode() == 200;
        }
    }

    public void cleanupS3WorkStorage(String bucketName, String pattern) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        ListObjectsV2Result listObjectsV2Result = s3Service.listObjects(bucketName);
        listObjectsV2Result.getObjectSummaries().forEach(s3ObjectSummary -> {
            if (s3ObjectSummary.getKey().contains(pattern)) {
                if (s3ObjectSummary.getLastModified().before(cal.getTime())) {
                    s3Service.deleteObject(s3ObjectSummary.getKey(), bucketName);
                }
            }
        });
    }

    protected synchronized void sendWorkOrderBacklogMessage(WorkOrderBacklogInputMessage message, KinesisProducerProperties kinesisProducerProperties) {
        List<UserRecord> userRecords = new ArrayList<>();

        userRecords.add(prepareWorkOrderBacklogUserRecord(message, kinesisProducerProperties));

        kinesisProducerService.putUserRecords(kinesisProducerService.initializeKinesisProducer(), userRecords);
    }

    public synchronized UserRecord prepareWorkOrderBacklogUserRecord(WorkOrderBacklogInputMessage message, KinesisProducerProperties kinesisProducerProperties) {

        String serializedMessage = null;
        try {
            serializedMessage = objectMapper.writeValueAsString(message.getJSONObject());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        UserRecord userRecord = new UserRecord();
        userRecord.setPartitionKey(UUID.randomUUID().toString());
        userRecord.setData(ByteBuffer.wrap(serializedMessage.getBytes()));
        userRecord.setStreamName(kinesisProducerProperties.getProperty("stream"));

        testLogger.info(System.lineSeparator() + "partitionKey=" + userRecord.getPartitionKey()
                + System.lineSeparator() + "stream=" + userRecord.getStreamName()
                + System.lineSeparator() + serializedMessage);

        return userRecord;
    }

    public synchronized WorkOrderDb getWorkOrderFromDbByWorkOrderId(String workOrderId) {
        try {
            Thread.sleep(Constants.DB_WAIT_TIMEOUT);
        } catch (InterruptedException ex) {
            testLogger.logExceptionThenFail(ex);
            Thread.currentThread().interrupt();
        }
        WorkOrderDb record = null;
        try {
            record = dbService.getItemByHashKey(WorkOrderDb.class, workOrderId, serviceProperties.getWorkOrderTable());
        } catch (DynamoDBMappingException ex) {
            testLogger.error("Error is occurred while getting record from DB for workOrderId: " + workOrderId +
                    "\nError message: " + ex.getMessage());
        }
        if (record != null)
            testLogger.info(System.lineSeparator() + "Record with uuid=" + workOrderId + " extracted from DB: " + record.toString());

        return record;
    }

    public synchronized WorkOrderDb getWorkOrderFromDbByWorkOrderIdWithWaiting(String workOrderId) {
        WorkOrderDb record = null;
        try {
            await().with().pollDelay(Duration.ofSeconds(DELAY)).atMost(TIMEOUT, TimeUnit.SECONDS).until(isWorkOrderExistsInDbByWorkOrderId(workOrderId));
            record = dbService.getItemByHashKey(WorkOrderDb.class, workOrderId, serviceProperties.getWorkOrderTable());
        } catch (DynamoDBMappingException ex) {
            testLogger.error("Error is occurred while getting record from DB for workOrderId: " + workOrderId +
                    "\nError message: " + ex.getMessage());
        } catch (ConditionTimeoutException ex) {
            return null;
        }
        if (record != null)
            testLogger.info(System.lineSeparator() + "Record with uuid=" + workOrderId + " extracted from DB: " + record.toString());

        return record;
    }

    public boolean waitForMaterialRequestedIsNotNull(String workOrderId) {
        try {
            await().with().pollDelay(Duration.ofSeconds(DELAY)).atMost(LONG_TIMEOUT, TimeUnit.SECONDS).until(isWorkOrderExistsAndMaterialIsRequested(workOrderId));
            return true;
        } catch (ConditionTimeoutException ex) {
            return false;
        }
    }

    public boolean waitForValidatedIsNotNull(String workOrderId) {
        try {
            await().with().pollDelay(Duration.ofSeconds(DELAY)).atMost(LONG_TIMEOUT, TimeUnit.SECONDS).until(isWorkOrderExistsAndValid(workOrderId));
            return true;
        } catch (ConditionTimeoutException ex) {
            return false;
        }
    }

    public boolean waitForMaterialRetrievalIsNotNull(String workOrderId) {
        try {
            await().with().pollDelay(Duration.ofSeconds(DELAY)).atMost(LONG_TIMEOUT, TimeUnit.SECONDS).until(isWorkOrderExistsAndMaterialIsRetrieved(workOrderId));
            return true;
        } catch (ConditionTimeoutException ex) {
            return false;
        }
    }

    private Callable<Boolean> isWorkOrderExistsInDbByWorkOrderId(String workOrderId) {
        return () -> dbService.getItemByHashKey(WorkOrderDb.class, workOrderId, serviceProperties.getWorkOrderTable()) != null;
    }

    private Callable<Boolean> isWorkOrderExistsAndMaterialIsRequested(String workOrderId) {
        return () -> {
            if (dbService.getItemByHashKey(WorkOrderDb.class, workOrderId, serviceProperties.getWorkOrderTable()) != null) {
                return dbService.getItemByHashKey(WorkOrderDb.class, workOrderId, serviceProperties.getWorkOrderTable()).getMaterialRequested() != null;
            } else {
                return false;
            }
        };
    }

    private Callable<Boolean> isWorkOrderExistsAndMaterialIsRetrieved(String workOrderId) {
        return () -> {
            if (dbService.getItemByHashKey(WorkOrderDb.class, workOrderId, serviceProperties.getWorkOrderTable()) != null) {
                return dbService.getItemByHashKey(WorkOrderDb.class, workOrderId, serviceProperties.getWorkOrderTable()).getMaterialRetrieval() != null;
            } else {
                return false;
            }
        };
    }

    private Callable<Boolean> isWorkOrderExistsAndValid(String workOrderId) {
        return () -> {
            if (dbService.getItemByHashKey(WorkOrderDb.class, workOrderId, serviceProperties.getWorkOrderTable()) != null) {
                return dbService.getItemByHashKey(WorkOrderDb.class, workOrderId, serviceProperties.getWorkOrderTable()).isValidated() != null;
            } else {
                return false;
            }
        };
    }

    public synchronized boolean waitTillTheStatusEventKinesisBufferSizeIsChanged(Long timeOut, int start) {
        try {
            await().atMost(timeOut, TimeUnit.SECONDS).until(isBufferSizeChanged(start));
            return true;
        } catch (ConditionTimeoutException ex) {
            return false;
        }
    }

    public Callable<Boolean> isBufferSizeChanged(int start) {
        return () -> StatusEventKinesisBuffer.getInstance().getTextMessages().size() > start;
    }

    public synchronized boolean waitTillTheJobSubmissionKinesisBufferSizeIsChanged(Long timeOut, int start) {
        try {
            await().atMost(timeOut, TimeUnit.SECONDS).until(isJobSubmissionBufferSizeChanged(start));
            return true;
        } catch (ConditionTimeoutException ex) {
            return false;
        }

    }

    public Callable<Boolean> isJobSubmissionBufferSizeChanged(int start) {
        return () -> JobSubmissionKinesisBuffer.getInstance().getTextMessages().size() > start;
    }


    @AfterSuite(alwaysRun = true)
    public void cleanup() {
        kinesisConsumers.destroy();
        kinesisProducerService.shutdownKinesisProducer(kinesisProducerService.initializeKinesisProducer());
//        if (!phaseBefore.equalsIgnoreCase("None")) {
//            testLogger.info("Setting phase before: " + phaseBefore);
//            setPhase(phaseBefore);
//        }
        ConcurrentMap<String, List<StatusEvent>> stepStatusMessages = StatusEventKinesisBuffer.getInstance().getStepStatusKinesisMap();
        ConcurrentMap<String, List<StatusEvent>> jobStatusMessages = StatusEventKinesisBuffer.getInstance().getJobStatusKinesisMap();
        List<StatusEvent> uncategorizedStatusEventList = StatusEventKinesisBuffer.getInstance().getUncategorizedStatusEventList();
        List<String> statusTextMessages = StatusEventKinesisBuffer.getInstance().getTextMessages();
        ConcurrentMap<String, List<MaterialRequestMessage>> materialKinesisMap = MaterialKinesisBuffer.getInstance().getMaterialRequestMessageKinesisMap();
        ConcurrentMap<String, List<ValidationContract>> validationRequests = ValidationServiceKinesisBuffer.getInstance().getValidationServiceMessagesByWorkOrderId();
        List<ValidationContract> uncategorizedValidationServiceMessages = ValidationServiceKinesisBuffer.getInstance().getUncategorizedValidationServiceMessages();
        ConcurrentMap<String, List<JobSubmissionContract>> jobSubmissions = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMap();
        List<String> textMessagesValidation = ValidationServiceKinesisBuffer.getInstance().getTextMessages();

        ConcurrentMap<String, List<MaterialRequestMessage>> materialRequestMessageKinesisMap = MaterialKinesisBuffer.getInstance().getMaterialRequestMessageKinesisMap();
        List<MaterialRequestMessage> uncategorizedMaterialRequestMessageList = MaterialKinesisBuffer.getInstance().getUncategorizedMaterialRequestMessageList();

        List<String> textMessages = MaterialKinesisBuffer.getInstance().getTextMessages();

        System.out.println("");
    }

    protected synchronized void sendMessage(JSONObject jsonObject, KinesisProducerProperties kinesisProducerProperties) {
        String serializedMessage = null;
        try {
            serializedMessage = objectMapper.writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        UserRecord userRecord = new UserRecord();
        userRecord.setPartitionKey(UUID.randomUUID().toString());
        userRecord.setData(ByteBuffer.wrap(serializedMessage.getBytes()));
        userRecord.setStreamName(kinesisProducerProperties.getProperty("stream"));

        testLogger.info(System.lineSeparator() + "partitionKey=" + userRecord.getPartitionKey()
                + System.lineSeparator() + "stream=" + userRecord.getStreamName()
                + System.lineSeparator() + serializedMessage);

        List<UserRecord> userRecords = new ArrayList<>();
        userRecords.add(userRecord);
        kinesisProducerService.putUserRecords(kinesisProducerService.initializeKinesisProducer(), userRecords);
    }

    protected synchronized JsonObject putDefaultMaterialSetForWorkOrder(WorkOrderBacklogInputMessage workOrderBacklogInputMessage, String validationStatus) {
        JsonObject jsonObject = getDefaultMaterialSetForWorkOrder(workOrderBacklogInputMessage);
        jsonObject.addProperty("validationStatus", validationStatus);
        putJsonObjectToS3(jsonObject, workOrderBacklogInputMessage.getMaterialSetPath());
        return jsonObject;
    }

    protected synchronized JsonObject getRawMaterialForWOrkOrder(){
        File materialSet = new File(RAW_MATERIAL_SET_TEMPLATE_PATH);
        JsonObject jsonObject = new JsonObject();
        try {
            jsonObject = JsonProcessor.parseJsonObject(new FileInputStream(materialSet));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        JsonObject rawMaterialJsonObject = jsonObject.getAsJsonObject("PharosCs").getAsJsonObject("CommandList")
                .getAsJsonArray("Command").get(0).getAsJsonObject();
        return rawMaterialJsonObject;
    }

    protected synchronized JsonObject getDefaultMaterialSetForWorkOrder(WorkOrderBacklogInputMessage workOrderBacklogInputMessage) {
        File materialSet = new File(MATERIAL_SET_TEMPLATE_PATH);
        JsonObject jsonObject = new JsonObject();
        try {
            jsonObject = JsonProcessor.parseJsonObject(new FileInputStream(materialSet));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        jsonObject.addProperty("workOrderId", workOrderBacklogInputMessage.getWorkOrderId());
        return jsonObject;
    }

    protected synchronized void putJsonObjectToS3(JsonObject jsonObject, String path) {
        String jsonString = jsonObject.toString();
        InputStream inputStream = new ByteArrayInputStream(jsonString.getBytes());
        ObjectMetadata objectMetadata = new ObjectMetadata();
        objectMetadata.setContentType(Constants.APPLICATION_JSON);
        PutObjectRequest putObjectRequest = new PutObjectRequest(s3MaterialStorage, path, inputStream, objectMetadata);
        s3Service.putObject(putObjectRequest);
    }

    protected synchronized void updateValidatedInDynamoDb(String workOrderId, Boolean value) {
        UpdateItemSpec updateItemSpec = new UpdateItemSpec()
                .withPrimaryKey("workOrderId", workOrderId)
                .withUpdateExpression("set validated = :r")
                .withValueMap(new ValueMap().withBoolean(":r", value));
        updateWorkOrderDynamoDbItem(updateItemSpec);
    }

    protected synchronized void updateMaterialRequestedInDynamoDb(String workOrderId, String value) {
        UpdateItemSpec updateItemSpec = new UpdateItemSpec()
                .withPrimaryKey("workOrderId", workOrderId)
                .withUpdateExpression("set materialRequested = :r")
                .withValueMap(new ValueMap().withString(":r", value));
        updateWorkOrderDynamoDbItem(updateItemSpec);
    }

    protected synchronized void updateMaterialRetrievalInDynamoDb(String workOrderId, String value) {
        UpdateItemSpec updateItemSpec = new UpdateItemSpec()
                .withPrimaryKey("workOrderId", workOrderId)
                .withUpdateExpression("set materialRetrieval = :r")
                .withValueMap(new ValueMap().withString(":r", value));
        updateWorkOrderDynamoDbItem(updateItemSpec);
    }


    protected synchronized void updateDueDateInDynamoDb(String workOrderId, Long value) {
        UpdateItemSpec updateItemSpec = new UpdateItemSpec()
                .withPrimaryKey("workOrderId", workOrderId)
                .withUpdateExpression("set dueDate = :r")
                .withValueMap(new ValueMap().withNumber(":r", value));
        updateWorkOrderDynamoDbItem(updateItemSpec);
    }

    protected void updateCpIdInDynamoDb(String workOrderId, String value) {
        UpdateItemSpec updateItemSpec = new UpdateItemSpec()
                .withPrimaryKey("workOrderId", workOrderId)
                .withUpdateExpression("set dueDate = :r")
                .withValueMap(new ValueMap().withString(":r", value));
        updateWorkOrderDynamoDbItem(updateItemSpec);
    }

    protected synchronized void updateWorkOrderDynamoDbItem(UpdateItemSpec updateItemSpec) {
        Table table = dynamoDB.getTable(serviceProperties.getWorkOrderTable());
        try {
            testLogger.info("Updating the item...");
            table.updateItem(updateItemSpec);
            testLogger.info("UpdateItem succeeded.\n");

        } catch (Exception e) {
            testLogger.error(e.getMessage());
        }
    }

    protected StatusEvent setStatusEventMessageData(String workOrderId, String requester, String jobId, String jobType, String jodStatus, String statusMessage) {
        StatusEvent statusEventMessage = new StatusEvent();
        statusEventMessage.setWorkOrderId(workOrderId);
        statusEventMessage.setRequester(requester);
        statusEventMessage.setCpId(UUID.randomUUID().toString());
        statusEventMessage.setJobId(jobId);
        statusEventMessage.setJobType(jobType);
        statusEventMessage.setJobStatus(jodStatus);
        statusEventMessage.setStatusMessage(statusMessage);
        return statusEventMessage;
    }

    protected synchronized void sendMessage(String jsonTextMessage, KinesisProducerProperties kinesisProducerProperties) {
        UserRecord userRecord = new UserRecord();
        userRecord.setPartitionKey(UUID.randomUUID().toString());
        userRecord.setData(ByteBuffer.wrap(jsonTextMessage.getBytes()));
        userRecord.setStreamName(kinesisProducerProperties.getProperty("stream"));

        testLogger.info(System.lineSeparator() + "partitionKey=" + userRecord.getPartitionKey()
                + System.lineSeparator() + "stream=" + userRecord.getStreamName()
                + System.lineSeparator() + jsonTextMessage);

        List<UserRecord> userRecords = new ArrayList<>();
        userRecords.add(userRecord);
        kinesisProducerService.putUserRecords(kinesisProducerService.initializeKinesisProducer(), userRecords);
    }

    protected WorkOrderContract getWorkOrderFromTemplate(String path) {
        File workOrderFile = new File(path);
        WorkOrderContract workOrderContract = null;
        try {
            workOrderContract = objectMapper.readValue(workOrderFile, WorkOrderContract.class);
        } catch (IOException ex) {
            logger.error(ex.getMessage());
        }
        return workOrderContract;
    }

    public String getWorkOrderMessageAsString(WorkOrderContract workOrderContract) {
        try {
            return objectMapper.writeValueAsString(workOrderContract);
        } catch (JsonProcessingException e) {
            logger.warn(e.getMessage());
            logger.warn(String.format("Error on getting a string from %s", workOrderContract));
        }
        return "";
    }
}