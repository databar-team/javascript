package com.nbcuni.test.cp.wo.backlog.tests;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.JobStatusEnum;
import com.nbcuni.test.cp.wo.backlog.model.JobTypeEnum;
import com.nbcuni.test.cp.wo.backlog.model.RequesterEnum;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.contract.ValidationContract;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.List;

public class CommonValidations extends BaseTest {

    public static final String PHASE1 = "1";

    protected void verifyStatusEvent(StatusEvent statusEvent, WorkOrderBacklogInputMessage workOrderBacklogInputMessage, String requester, String jobType, String jobStatus, String statusMessage) {
        Assert.assertEquals(statusEvent.getRequester(), requester, "Requester is wrong for workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNull(statusEvent.getJobId(), "jobId is wrong for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
        if (statusEvent.getJobStatus().equals(JobStatusEnum.DONE.getValue()))
            Assert.assertNotNull(statusEvent.getCpId(), "cpId is wrong for workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        else
            Assert.assertNull(statusEvent.getCpId(), "cpId is wrong for workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(statusEvent.getWorkOrderId(), workOrderBacklogInputMessage.getWorkOrderId(), "WorkOrderId is wrong");
        Assert.assertEquals(statusEvent.getJobType(), jobType, "job type is wrong for workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(statusEvent.getJobStatus(), jobStatus, "job status is wrong for workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNull(statusEvent.getPercentComplete(), "percentComplete is wrong for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertTrue(statusEvent.getErrors().isEmpty(), "Errors is NOT empty for status message for workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertTrue(statusEvent.getStatusMessage().contains(statusMessage), "statusMessage is wrong for workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        if (statusEvent.getJobStatus().equals(JobStatusEnum.SUBMITTED.getValue()))
            Assert.assertTrue(statusEvent.getStatusMessage().contains(workOrderBacklogInputMessage.getWorkOrderId()), "workOrderId is wrong in the statusMessage for workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        if (statusEvent.getJobStatus().equals(JobStatusEnum.DONE.getValue()))
            Assert.assertTrue(statusEvent.getStatusMessage().contains(statusEvent.getCpId()), "cpId is wrong in the statusMessage for workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
    }

    protected void verifyErrorStatusEventWithoutWorkOrderId(StatusEvent statusEvent, String requester, String jobType, String statusMessage, String errorMessage) {
        Assert.assertEquals(statusEvent.getRequester(), requester, "Requester is wrong for invalid workOrderId");
        Assert.assertNull(statusEvent.getJobId(), "jobId is wrong for invalid workOrderId");
        Assert.assertNull(statusEvent.getCpId(), "cpId is wrong for invalid workOrderId");
        Assert.assertNull(statusEvent.getWorkOrderId(), "WorkOrderId is wrong");
        Assert.assertEquals(statusEvent.getJobType(), jobType, "job type is wrong for invalid workOrderId");
        Assert.assertNull(statusEvent.getPercentComplete(), "percentComplete is wrong for invalid workOrderId");
        Assert.assertFalse(statusEvent.getErrors().isEmpty(), "Errors is empty for status message for invalid workOrderId");
        Assert.assertTrue(statusEvent.getStatusMessage().contains(statusMessage), "statusMessage is wrong for invalid workOrderId");
        statusEvent.getErrors().forEach(error -> {
            Assert.assertEquals(error.get("errorCode"), 501, "Error code is wrong for invalid workOrderId");
            Assert.assertTrue(error.get("errorMessage").toString().contains(errorMessage), "Error message doesn't contain " + errorMessage);
        });
    }

    public synchronized void verifyErrorStatusEvent(String workOrderId, String statusMessage, List<String> code, List<String> message) {
        List<StatusEvent> workOrderBacklogEvents = StatusEventKinesisBuffer.getInstance().getJobStatusKinesisMapByWorkOrderIdAndJobStatus(workOrderId, JobStatusEnum.ERROR.getValue());
        Assert.assertNotNull(workOrderBacklogEvents, "There is no status events for workorder " + workOrderId);
        Assert.assertEquals(workOrderBacklogEvents.get(0).getRequester(), RequesterEnum.TRANSLATOR.getValue(), "Requester is invalid for workOrder: " + workOrderId);
        Assert.assertEquals(workOrderBacklogEvents.get(0).getJobStatus(), JobStatusEnum.ERROR.getValue(), "Job Status is invalid for workOrder: " + workOrderId);
        Assert.assertTrue(workOrderBacklogEvents.get(0).getStatusMessage().contains(statusMessage), "Status message is invalid for workOrder: " + workOrderId);
        Assert.assertEquals(workOrderBacklogEvents.get(0).getJobType(), JobTypeEnum.WORK_ORDER_BACKLOG.getValue(), "Job Type is invalid for workOrder: " + workOrderId);
        Assert.assertNotNull(workOrderBacklogEvents.get(0).getTimestamp(), "Timestamp is invalid for workOrder: " + workOrderId);
        Assert.assertNull(workOrderBacklogEvents.get(0).getPercentComplete(), "Percent Complete is invalid for workOrder: " + workOrderId);
        Assert.assertNotEquals(workOrderBacklogEvents.get(0).getErrors().size(), 0, "List of errors is empty for workOrder: " + workOrderId);
        List<String> errorCodes = new ArrayList<>();
        workOrderBacklogEvents.get(0).getErrors().forEach(error -> errorCodes.add(error.get("errorCode").toString()));
        Assert.assertEquals(errorCodes, code, "Wrong error code in error message for workOrder " + workOrderId);
        List<String> errorMessages = new ArrayList<>();
        workOrderBacklogEvents.get(0).getErrors().forEach(error -> errorMessages.add(error.get("errorMessage").toString()));
        Assert.assertEquals(errorMessages, message, " wrong error message in errors for workOrder" + workOrderId);
    }

    public synchronized void verifyValidationRequest(ValidationContract validationContract, WorkOrderBacklogInputMessage workOrderBacklogInputMessageContract, String s3MaterialStorage){
        String jobId = workOrderBacklogInputMessageContract.getMaterialRequested();
        String workOrderId = workOrderBacklogInputMessageContract.getWorkOrderContract().getWorkOrderId();
        String rawMaterialMetadataOutputFilePathExpected = workOrderBacklogInputMessageContract.getRawMaterialMetadataOutputFilePath(s3MaterialStorage, jobId);
        String materialMetadataOutputFilePathExpected = workOrderBacklogInputMessageContract.getMaterialMetadataOutputFilePath(s3MaterialStorage, jobId);

        Assert.assertEquals(validationContract.getRequester(), "WorkOrderBacklog", "Invalid requester for workOrderId: " + workOrderId);
        Assert.assertNull(validationContract.getJobContext(), "Invalid jobContext for workOrderId: " + workOrderId);
        Assert.assertEquals(validationContract.getMaterialMetadataOutputFile(), materialMetadataOutputFilePathExpected,
                "Invalid materialMetadataOutputFile for workOrderId: " + workOrderId);
        Assert.assertEquals(validationContract.getRawMaterialMetadataInputFile(), rawMaterialMetadataOutputFilePathExpected,
                "Invalid rawMaterialMetadataInputFile for workOrderId: " + workOrderId);

    }
}
