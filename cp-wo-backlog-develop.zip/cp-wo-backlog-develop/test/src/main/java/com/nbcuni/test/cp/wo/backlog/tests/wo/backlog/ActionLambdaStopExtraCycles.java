package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.validation.ValidationServiceKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.contract.ValidationContract;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;

public class ActionLambdaStopExtraCycles extends BaseTest {

    @Story("MFAJ-1322")
    @TmsLink("MFAJ-1263")
    @Description("In Action lambda, IF materialRequested != materialRetrieval, end without further processing")
    @Test(groups = {"full"}, dataProvider = "getParamsWhenRequestedNotEqualsRetrieval")
    public void tC1322ActionLambdaStopsFurtherProcessingIfMaterialHasBeenRequestedButNotRetrieved(String requestedJobId, String retrievalJodId, Boolean validated) {
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();

        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        workOrderBacklogInputMessage.setWorkOrderId(workOrderId);
        workOrderBacklogInputMessage.setMaterialRequested(requestedJobId);
        workOrderBacklogInputMessage.setMaterialRetrieval(retrievalJodId);
        workOrderBacklogInputMessage.setValidated(validated);

        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderId);
        Assert.assertNotNull(workOrderDb, "Workorder " + workOrderId + " is not saved to Dynamo Db table");
        Assert.assertNotNull(workOrderDb.getMaterialRequested(), "MaterialRequested field has not been created or is empty");

        verifyEndWithoutFurtherProcessing(workOrderId);
    }

    @DataProvider(parallel = true)
    public static Object[][] getParamsWhenRequestedNotEqualsRetrieval() {
        return new Object[][]{
                //materialRequested; materialRetrieval; validated
                {
                        "jobId1", null, null
                },
                {
                        "jobId1", "jobId2", null
                },
                {
                        "jobId1", null, false
                },
                {
                        "jobId1", "jobId2", false
                },
                {
                        "jobId1", null, true
                },
                {
                        "jobId1", "jobId2", true
                }
        };
    }

    @Story("MFAJ-1325")
    @TmsLink("MFAJ-1263")
    @Description("In Action lambda, IF triggered by the DB stream AND materialRequested = materialRetrieval AND validated is false, end without further processing")
    @Test(groups = {"full"}, dataProvider = "getRequestedEqualsRetrievalAndValidatedIsFalseParams")
    public void tC1325ActionLambdaStopsFurtherProcessingIfTriggeredByDBStreamAndRequestedEqualsRetrievalAndValidatedIsFalse(String requestedJobId, String retrievalJodId, Boolean validated) {
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();

        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        workOrderBacklogInputMessage.setWorkOrderId(workOrderId);
        workOrderBacklogInputMessage.setMaterialRequested("jobId");

        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);
        verifyEndWithoutFurtherProcessing(workOrderId);

        workOrderBacklogInputMessage.setMaterialRequested(requestedJobId);
        workOrderBacklogInputMessage.setMaterialRetrieval(retrievalJodId);
        workOrderBacklogInputMessage.setValidated(validated);

        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);
        verifyEndWithoutFurtherProcessing(workOrderId);
    }

    @DataProvider(parallel = true)
    public static Object[][] getRequestedEqualsRetrievalAndValidatedIsFalseParams() {
        return new Object[][]{
                //materialRequested; materialRetrieval; validated
                {
                        "jobId", "jobId", false
                },
                {
                        null, null, false
                }
        };
    }

    private synchronized void verifyEndWithoutFurtherProcessing(String workOrderId) {
        List<ValidationContract> validationRequests = ValidationServiceKinesisBuffer.getInstance().getValidationServiceMessagesWithWaiting(workOrderId);

        Assert.assertTrue(validationRequests.isEmpty(), "There is validation requests to validation service for workOrder " + workOrderId);

        List<JobSubmissionContract> jobSubmissionMessageKinesisMap = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderId);
        Assert.assertTrue(jobSubmissionMessageKinesisMap.isEmpty(), "There is a status message that the work order is in Job Submission service");
    }

    @Story("MFAJ-1346")
    @TmsLink("MFAJ-1263")
    @Description("In Action lambda, IF materialRequested = materialRetrieval AND neither value is null AND validated is true, make a request to Job Submission")
    @Test(groups = {"full"})
    public void tC1346ActionLambdaMakesRequestToJobSubmissionIfRequestedEqualsRetrievalAndValidatedIsTrue() {
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();

        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        String requestedJobId = "jobId";
        workOrderBacklogInputMessage.setWorkOrderId(workOrderId);
        workOrderBacklogInputMessage.setMaterialRequested(requestedJobId);
        workOrderBacklogInputMessage.setMaterialRetrieval(requestedJobId);
        workOrderBacklogInputMessage.setValidated(true);

        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        List<ValidationContract> validationRequests = ValidationServiceKinesisBuffer.getInstance().getValidationServiceMessagesWithWaiting(workOrderId);

        Assert.assertTrue(validationRequests.isEmpty(), "There is validation requests to validation service for workOrder " + workOrderId);

        List<JobSubmissionContract> jobSubmissionMessageKinesisMap = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderId);
        Assert.assertFalse(jobSubmissionMessageKinesisMap.isEmpty(), "There is no messages in job Submission stream " + workOrderBacklogInputMessage);
    }

    @Story("MFAJ-1415")
    @TmsLink("MFAJ-1263")
    @Description("In Action lambda in all other cases call Validation")
    @Test(groups = {"full"}, dataProvider = "getOtherParams", enabled = false)
    public void actionLambdaStopsExtraCyclesOtherCases(String requestedJobId, String retrievalJodId, Boolean validated) {
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();

        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        workOrderBacklogInputMessage.setMaterialRequested(requestedJobId);
        workOrderBacklogInputMessage.setMaterialRetrieval(retrievalJodId);
        workOrderBacklogInputMessage.setValidated(validated);

        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);


        List<ValidationContract> validationRequests = ValidationServiceKinesisBuffer.getInstance().getValidationServiceMessagesWithWaiting(workOrderId);

        Assert.assertEquals(validationRequests.size(), 1, "There is no validation requests to validation service for workOrder " + workOrderId);

        List<String> jobSubmissionRequestMessageKinesisMap = JobSubmissionKinesisBuffer.getInstance().getTextMessagesWithWaiting(workOrderId);
        Assert.assertNull(jobSubmissionRequestMessageKinesisMap, "There is a status message that the work order is in Job Submission service");
    }

    @DataProvider(parallel = true)
    public static Object[][] getOtherParams() {
        return new Object[][]{
                //materialRequested; materialRetrieval; validated
                {
                        "jobId1", "jobId1", null
                }
        };
    }
}
