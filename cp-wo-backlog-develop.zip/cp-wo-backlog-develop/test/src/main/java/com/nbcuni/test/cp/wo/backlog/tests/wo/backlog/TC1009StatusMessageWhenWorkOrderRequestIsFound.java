package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.*;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class TC1009StatusMessageWhenWorkOrderRequestIsFound extends CommonValidations {

    @Story("MFAJ-1367") //MFAJ-775
    @TmsLink("MFAJ-1009") // MFAJ-1009
    @Description("Verify that status message is sent to the Global Status Stream when a workOrder request is successfully received")
    @Test(groups = {"full"})
    public void statusMessageIsSentToGlobalStatusEventStreamThatWorkOrderReceived() {

        String requesterTranslator = WorkOrderBacklogStatusMessageEnum.RECEIVED.getRequester();
        String jobStatusReceived = WorkOrderBacklogStatusMessageEnum.RECEIVED.getJobStatus();
        String jobStatusRunning = WorkOrderBacklogStatusMessageEnum.REQUESTING_VALIDATION.getJobStatus();
        String jobTypeWOBacklog = WorkOrderBacklogStatusMessageEnum.RECEIVED.getJobType();
        String statusMessageReceived = WorkOrderBacklogStatusMessageEnum.RECEIVED.getStatusMessagePattern();
        String statusMessageRequestingValidation = WorkOrderBacklogStatusMessageEnum.REQUESTING_VALIDATION.getStatusMessagePattern();

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setMaterialRequested(System.currentTimeMillis() + "1");
        workOrderBacklogInputMessage.setMaterialRetrieval(workOrderBacklogInputMessage.getMaterialRequested());
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.step("Given: A payload for workOrderId: " + workOrderId);
        testLogger.info(workOrderBacklogInputMessage.getFullJSONObject().toString());

        testLogger.step("When: Work order with predefined fields is sent to WorkOrder Backlog Service");
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: WO is stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertNotNull(workOrderDb, "WorkOrder with id " + workOrderId + " wasn't found in DynamoDb");
        testLogger.step("And: Status message when the service ingests a request is sent to Status Stream");
        List<StatusEvent> statusEventsForWorkOrderIdAndReceivedStatusMessage = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderId, String.format(statusMessageReceived, workOrderId));
        Assert.assertEquals(statusEventsForWorkOrderIdAndReceivedStatusMessage.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderId + " and status message: " + statusMessageReceived + ". Should be 1 status event");
        statusEventsForWorkOrderIdAndReceivedStatusMessage.forEach(statusEvent ->
                verifyStatusEvent(statusEvent, workOrderBacklogInputMessage, requesterTranslator, jobTypeWOBacklog, jobStatusReceived,
                        String.format(statusMessageReceived, workOrderId)));

        testLogger.step("And: Status message when Action calls Validation after being triggered by the WO DB stream is sent to Status Stream");
        List<StatusEvent> statusEventsForWorkOrderIdAndRunningJobStatus = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderId, statusMessageRequestingValidation);
        Assert.assertEquals(statusEventsForWorkOrderIdAndRunningJobStatus.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderId + " and status message: " + statusMessageRequestingValidation + ". Should be 1 status event");
        statusEventsForWorkOrderIdAndRunningJobStatus.forEach(statusEvent ->
                verifyStatusEvent(statusEvent, workOrderBacklogInputMessage, requesterTranslator, jobTypeWOBacklog, jobStatusRunning,
                        statusMessageRequestingValidation));
    }
}
