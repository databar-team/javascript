package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.*;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.stream.Collectors;

public class TC1010ErrorStatusMessageWhenWorkOrderRequestIsFound extends CommonValidations {

    @Story("MFAJ-1367") //MFAJ-775
    @TmsLink("MFAJ-1010") //1010
    @Description("Verify that error status message is sent to the Global Status Stream when a workOrder request with empty workOrderId is sent")
    @Test(groups = {"full"})
    public void errorStatusMessageIsSentToGlobalStatusEventStreamThatWorkOrderReceived() {
        String requesterTranslator = WorkOrderBacklogStatusMessageEnum.REJECTED.getRequester();
        String jobTypeWOBacklog = WorkOrderBacklogStatusMessageEnum.REJECTED.getJobType();
        String statusMessageRejected = WorkOrderBacklogStatusMessageEnum.REJECTED.getStatusMessagePattern();
        String statusMessageRequestingValidation = WorkOrderBacklogStatusMessageEnum.REQUESTING_VALIDATION.getStatusMessagePattern();
        String statusMessageReceived = WorkOrderBacklogStatusMessageEnum.RECEIVED.getStatusMessagePattern();
        String errorMessage = "WorkOrder is missing workOrderId";

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setWorkOrderId("");
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.step("Given: A payload for workOrderId: " + workOrderId);
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.step("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendWorkOrderBacklogMessage(workOrderBacklogInputMessage, woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: WO is NOT stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertNull(workOrderDb, "WorkOrder with id " + workOrderId + " wasn't found in DynamoDb");
        testLogger.step("And: Status message when the service ingests a request is NOT sent to Status Stream");
        List<StatusEvent> statusEventsForWorkOrderIdAndReceivedStatusMessage = StatusEventKinesisBuffer.getInstance().getJobStatusWithStatusMessage(workOrderId, String.format(statusMessageReceived, workOrderId));
        Assert.assertTrue(statusEventsForWorkOrderIdAndReceivedStatusMessage.isEmpty(), "There are status events messages for workOrderId: " + workOrderId + " and status message: " + statusMessageReceived);

        testLogger.step("And: Status message when Action calls Validation after being triggered by the WO DB stream is NOT sent to Status Stream");
        List<StatusEvent> statusEventsForWorkOrderIdAndRequestingValidationStatusMessage = StatusEventKinesisBuffer.getInstance().getJobStatusWithStatusMessage(workOrderId, statusMessageRequestingValidation);
        Assert.assertTrue(statusEventsForWorkOrderIdAndRequestingValidationStatusMessage.isEmpty(), "There are status events messages for workOrderId: " + workOrderId + " and status message: " + statusMessageRequestingValidation);

        testLogger.step("And: Error status message is sent to Status Stream");
        List<StatusEvent> errorStatusEvents = StatusEventKinesisBuffer.getInstance().getUncategorizedStatusEventList().stream().filter(errorStatusEvent ->
                errorStatusEvent.getErrors().get(0).get("errorMessage").toString().contains(errorMessage)).collect(Collectors.toList());
        Assert.assertFalse(errorStatusEvents.isEmpty(), "There are no error status event messages with errorMessage: " + errorMessage);
        errorStatusEvents.forEach(errorEvent -> verifyErrorStatusEventWithoutWorkOrderId(errorEvent, requesterTranslator, jobTypeWOBacklog, statusMessageRejected, errorMessage));
    }
}
