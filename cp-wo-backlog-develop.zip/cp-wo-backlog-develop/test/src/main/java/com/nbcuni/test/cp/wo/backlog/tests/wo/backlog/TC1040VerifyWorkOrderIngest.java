package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;


public class TC1040VerifyWorkOrderIngest extends BaseTest {

    private static final String MATERIAL_ID = "DBRO_0000000001234_01";

    @TmsLink("MFAJ-1040")
    @Description("Verify that order is saved to DynamoDb")
    @Test(groups = {"full"})
    public void workOrderAvailableInDynamoDbAfterSubmitting(){
        testLogger.step("Given: Work Order with valid payload");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.getVideoSource().get(0).setId(MATERIAL_ID);
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.step("When: Work Order is sent to wo backlog stream: " + woBacklogEventStreamKinesisProducerProperties.getProperty("stream"));
        sendMessage(workOrderBacklogInputMessage.getJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Work order record is inserted into DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no record in dynamoDb for work order " + workOrderBacklogInputMessage.getWorkOrderId());

    }


}
