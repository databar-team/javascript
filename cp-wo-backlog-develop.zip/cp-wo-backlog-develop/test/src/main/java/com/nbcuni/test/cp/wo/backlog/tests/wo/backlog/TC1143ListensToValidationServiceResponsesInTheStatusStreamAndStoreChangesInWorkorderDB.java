package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.model.*;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TC1143ListensToValidationServiceResponsesInTheStatusStreamAndStoreChangesInWorkorderDB extends BaseTest {
    private String requesterWOBacklog = WorkOrderBacklogStatusMessageEnum.MATERIAL_REQUESTED.getJobType();
    private String jobId = "jobId";
    private String jobTypeWOBacklog = WorkOrderBacklogStatusMessageEnum.MATERIAL_REQUESTED.getJobType();
    private String jobStatusQueued = WorkOrderBacklogStatusMessageEnum.MATERIAL_REQUESTED.getJobStatus();
    private String statusMessageMaterialRequested = WorkOrderBacklogStatusMessageEnum.MATERIAL_REQUESTED.getStatusMessagePattern();

    private String jobStatusError = WorkOrderBacklogStatusMessageEnum.REJECTED.getJobStatus();
    private String requiredComponent = "video";
    private String stream = "stream";
    private String audioAndCaptionPreference = "audioAndCaptionPreference";

    @Story("MFAJ-1265")
    @TmsLink("MFAJ-1143")
    @Description("Verify that status stream is listened and when material request message is sent changes are stored in Dynamo DB table")
    @Test(groups = {"full"})
    public void whenMaterialRequestMessageIsInTheStatusStreamWoBacklogMakesChangesToDynamoDb() {
        List<String> requiredComponents = new ArrayList<>();
        requiredComponents.add(requiredComponent);
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setRequiredComponents(requiredComponents);
        JSONObject jsonObject = workOrderBacklogInputMessage.getJSONObject();
        jsonObject.remove(audioAndCaptionPreference);
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.step("Given: A payload with missed 'audioAndCaptionPreference' with workOrderId:" + workOrderId);
        testLogger.info(jsonObject.toString());
        testLogger.step("When: WorkOrder is sent to Kinesis stream" + woBacklogEventStreamKinesisProducerProperties.getProperty(stream));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: WorkOrder is inserted in DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertNotNull(workOrderDb, "Work order with workOrderId: " + workOrderId + " is not found in Dynamo DB table");
        Assert.assertNull(workOrderDb.getMaterialRequested(), "MaterialRequested field is not null");

        StatusEvent statusEventMessage = setStatusEventMessageData(workOrderId, requesterWOBacklog, jobId, jobTypeWOBacklog, jobStatusQueued, statusMessageMaterialRequested);
        testLogger.step("When: status message for material request is sent to Kinesis status stream with jobId: " + statusEventMessage.getJobId());
        sendMessage(statusEventMessage.getJSONObject(), statusEventStreamKinesisProducerProperties);
        testLogger.step("Then: workOrder record from DynamoDb table contains materialRequested field with jobId " + statusEventMessage.getJobId());
        Assert.assertTrue(waitForMaterialRequestedIsNotNull(workOrderId), "MaterialRequested flag is not updated for workOrder " + workOrderId);
        workOrderDb = getWorkOrderFromDbByWorkOrderId(statusEventMessage.getWorkOrderId());
        Assert.assertTrue(workOrderDb.getMaterialRequested().contains(statusEventMessage.getJobId()), "MaterialRequested field does not contain required jobId for workOrderId: " + workOrderId);

        statusEventMessage.setJobId(System.currentTimeMillis() + "job2");
        testLogger.step("When: New status message for material request is sent to Kinesis status stream with jobId: " + statusEventMessage.getJobId());
        sendMessage(statusEventMessage.getJSONObject(), statusEventStreamKinesisProducerProperties);
        testLogger.step("Then: workOrder record from DynamoDb table contains materialRequested field with jobId " + statusEventMessage.getJobId());
        workOrderDb = getWorkOrderFromDbByWorkOrderId(statusEventMessage.getWorkOrderId());
        Assert.assertTrue(workOrderDb.getMaterialRequested().contains(statusEventMessage.getJobId()), "MaterialRequested field does not contain required jobId");
    }

    @Story("MFAJ-1265")
    @TmsLink("MFAJ-1143")
    @Description("Verify that status stream is listened and when validation message is sent changes are stored in Dynamo DB table")
    @Test(groups = {"full"})
    public void whenValidationMessageIsInTheStatusStreamWoBacklogMakesChangesToDynamoDb() {
        String statusMessageMaterialsValid = "materialsValid";
        String jobTypeCPValidation = "cp-Validation";

        List<String> requiredComponents = new ArrayList<>();
        requiredComponents.add(requiredComponent);
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setRequiredComponents(requiredComponents);
        JSONObject jsonObject = workOrderBacklogInputMessage.getJSONObject();
        jsonObject.remove(audioAndCaptionPreference);
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.step("Given: a payload with workOrderId = " + workOrderId);
        testLogger.info(jsonObject.toString());
        testLogger.step("When: workOrder is sent to Kenisis stream" + woBacklogEventStreamKinesisProducerProperties.getProperty(stream));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: workOrder record is inserted in DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderId);
        Assert.assertNotNull(workOrderDb, "There is no item for workOrder: " + workOrderId + " in Dynamo DB table");
        Assert.assertNull(workOrderDb.isValidated(), "Validated field is not null");

        StatusEvent statusEventMessage = setStatusEventMessageData(workOrderId, requesterWOBacklog, jobId, jobTypeCPValidation, jobStatusError, statusMessageMaterialsValid);
        testLogger.step("When: status message for validation is sent to Kinesis status stream with jobStatus: " + statusEventMessage.getJobStatus());
        sendMessage(statusEventMessage.getJSONObject(), statusEventStreamKinesisProducerProperties);
        testLogger.step("Then: workOrder record from DynamoDb table contains validated field with required value");
        Assert.assertTrue(waitForValidatedIsNotNull(workOrderId), "Validated flag is not updated for workOrder " + workOrderId);
        workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderId);
        Assert.assertFalse(workOrderDb.isValidated(), "Validated field does not contain false");

        statusEventMessage.setJobStatus(JobStatusEnum.DONE.getValue());
        testLogger.step("When: status message for validation is sent to Kinesis status stream with jobStatus: " + statusEventMessage.getJobStatus());
        sendMessage(statusEventMessage.getJSONObject(), statusEventStreamKinesisProducerProperties);
        workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        testLogger.step("Then: workOrder record from DynamoDb table contains validated field with required value");
        waitForValidatedIsNotNull(workOrderId);
        Assert.assertTrue(workOrderDb.isValidated(), "Validated field does not contain true");
    }

    @Story("MFAJ-1265")
    @TmsLink("MFAJ-1143")
    @Description("Verify that status stream is listened and when material retrieval message is sent changes are stored in Dynamo DB table")
    @Test(groups = {"full"}, dataProvider = "getParamsForRetrievalVerification")
    public void whenMaterialRetrievalMessageIsInTheStatusStreamWoBacklogMakesChangesToDynamoDb(String requestedJobId, String retrievalJobStatus, String retrievalJobId, String retrievalResult) {
        List<String> requiredComponents = new ArrayList<>();
        requiredComponents.add(requiredComponent);
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setRequiredComponents(requiredComponents);
        JSONObject jsonObject = workOrderBacklogInputMessage.getFullJSONObject();
        jsonObject.remove(audioAndCaptionPreference);
        workOrderBacklogInputMessage.setMaterialRequested(requestedJobId);
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.step("Given: a payload with workOrderId = " + workOrderId);
        testLogger.step("When: workOrder is sent to Kenisis stream" + woBacklogEventStreamKinesisProducerProperties.getProperty(stream));
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: workOrder record is inserted in DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderId);
        Assert.assertNotNull(workOrderDb, "There is no item for workOrder: " + workOrderId + " in Dynamo DB table");
        if (requestedJobId != null)
            Assert.assertEquals(workOrderDb.getMaterialRequested(), requestedJobId, "MaterialRequested field does not contain required jobId");
        Assert.assertNull(workOrderDb.getMaterialRetrieval(), "MaterialRetrieval field is not null");

        StatusEvent statusEventMessage = setStatusEventMessageData(workOrderId, requesterWOBacklog, retrievalJobId, "Material", retrievalJobStatus, "");
        testLogger.step("When: status message for material retrieval is sent to Kinesis status stream with jobId: " + statusEventMessage.getJobId());
        sendMessage(statusEventMessage.getJSONObject(), statusEventStreamKinesisProducerProperties);
        testLogger.step("Then: materialRetrieval field for workOrder record from DynamoDb table contains required data");
        workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertEquals(workOrderDb.getMaterialRetrieval(), retrievalResult, "MaterialRetrieval field does not contain required data");
    }

    @DataProvider(parallel = true)
    public static Object[][] getParamsForRetrievalVerification() {
        return new Object[][]{
                //requestedJobId, retrievalJobStatus,  retrievalJobId,  retrievalResult
                {
                        null, WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getJobStatus(), "retrievalJobId", null
                },
                {
                        "requestedJodId", WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getJobStatus(), "requestedJodId", "requestedJodId"
                },
                {
                        "requestedJodId", WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getJobStatus(), "retrievalJobId", null
                },
                {
                        "requestedJodId", WorkOrderBacklogStatusMessageEnum.REJECTED.getJobStatus(), "requestedJodId", null
                }
        };
    }
}