package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class TC1199VerifyValidOrderAndMaterialsInWorkOrder extends BaseTest {

    @Story("MFAJ-1104")
    @TmsLink("MFAJ-1199")
    @Description("Verify that order is sent to the job submission stream")
    @Test(groups = {"full"})
    public void woSubmitsRequestToJobSubmissionIfWorkOrderIsValid () {

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        sendWorkOrderBacklogMessage(workOrderBacklogInputMessage, woBacklogEventStreamKinesisProducerProperties);
        putDefaultMaterialSetForWorkOrder(workOrderBacklogInputMessage,"Done");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb,"There is no workOrder in dynamoDb with workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(workOrderBacklogInputMessage.getWorkOrderId(),workOrderDb.getWorkOrderId());
        updateMaterialRequestedInDynamoDb(workOrderBacklogInputMessage.getWorkOrderId(), "12345.6789");
        updateMaterialRetrievalInDynamoDb(workOrderBacklogInputMessage.getWorkOrderId(), "12345.6789");
        updateValidatedInDynamoDb(workOrderBacklogInputMessage.getWorkOrderId(), true);
        List <JobSubmissionContract> expectedJobSubmissionList = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(expectedJobSubmissionList.size(), 1, "There are no job submission messages in job submission stream associated with workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
    }

}
