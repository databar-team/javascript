package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class TC1200VerifyInvalidOrderAndMaterialsInWorkOrder extends BaseTest {

    @Story("MFAJ-1104")
    @TmsLink("MFAJ-1200")
    @Description("Verify that order is not sent to the job submission stream")
    @Test(groups = {"full"})
    public void woDoesNotSubmitsRequestToJobSubmissionIfWorkOrderIsNotValid()  {
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setDueDate(null);
        sendWorkOrderBacklogMessage(workOrderBacklogInputMessage, woBacklogEventStreamKinesisProducerProperties);
        List<JobSubmissionContract> expectedJobSubmissionList = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());

        Assert.assertTrue(expectedJobSubmissionList.isEmpty());
    }

}
