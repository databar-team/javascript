package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.*;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;


public class TC1406WOBacklogSendADoneStatusMessageWhenRequestInJobSubmissionIsMade extends CommonValidations {

    @Story("MFAJ-1367") //MFAJ-1257
    @TmsLink("MFAJ-1344") //MFAJ-1344
    @Description("As product I want the WO Backlog to send a notification when a request is made to Job Submission")
    @Test(groups = {"full"})
    public void wOBacklogSendsADoneMessageWhenValidationIsFinishedAndRequestToJobSubmissionIsMade() {
        String statusMessageValidationComplete = WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getStatusMessagePattern();
        String requesterTranslator = WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getRequester();
        String jobTypeWoBacklog = WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getJobType();
        String jobStatusDone = WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getJobStatus();

        testLogger.step("Given: workOrder  with valid work order");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.getVideoSource().get(0).setId("DBRO_0000000001234_01");
        workOrderBacklogInputMessage.setMaterialRequested(System.currentTimeMillis() + "1");
        workOrderBacklogInputMessage.setMaterialRetrieval(workOrderBacklogInputMessage.getMaterialRequested());
        workOrderBacklogInputMessage.setValidated(true);

        testLogger.step("When: Valid workOrder is send to workOrder registry stream");
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Validations Complete status message for Translator is available in the status stream");
        List<StatusEvent> statusEventsValidationsComplete = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(), statusMessageValidationComplete);
        Assert.assertEquals(statusEventsValidationsComplete.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage: " + statusMessageValidationComplete + ". Should be 1 status event");
        statusEventsValidationsComplete.forEach(statusEvent -> verifyStatusEvent(statusEvent, workOrderBacklogInputMessage, requesterTranslator, jobTypeWoBacklog, jobStatusDone, statusMessageValidationComplete));

        testLogger.step("And: Event is available in job submission stream");
        List<JobSubmissionContract> jobSubmissions = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(jobSubmissions.size(), 1, "There is no events in job submission stream , workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
    }

    @Story("MFAJ-1257")
    @TmsLink("MFAJ-1344")
    @Description("WO Backlog does not send a notification when validation is not completed")
    @Test(groups = {"full"})
    public void wOBacklogDoesntSendADoneMessageWhenMaterialsValidEvenWasntReceived() {
        String statusMessageValidationComplete = StatusMessageEnum.VALIDATION_COMPLETE.getValue();

        testLogger.step("Given: workOrder  with valid work order");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.getVideoSource().get(0).setId("DBRO_0000000001234_01");
        workOrderBacklogInputMessage.setMaterialRequested(System.currentTimeMillis() + "1");
        workOrderBacklogInputMessage.setMaterialRetrieval(workOrderBacklogInputMessage.getMaterialRequested());
        workOrderBacklogInputMessage.setValidated(false);

        testLogger.step("When: workOrder is send to workOrder registry stream");
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Validations Complete status message for Translator is not available in the status stream");
        List<StatusEvent> statusEvents = StatusEventKinesisBuffer.getInstance().getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(), statusMessageValidationComplete);
        Assert.assertTrue(statusEvents.isEmpty(), "There are events in status stream that work order is completed but shouldn't be available " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Event is not available in job submission stream");
        List<JobSubmissionContract> jobSubmissions = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertTrue(jobSubmissions.isEmpty(), "There are events in job submission stream but shouldn't be available " + workOrderBacklogInputMessage.getWorkOrderId());
    }
}
