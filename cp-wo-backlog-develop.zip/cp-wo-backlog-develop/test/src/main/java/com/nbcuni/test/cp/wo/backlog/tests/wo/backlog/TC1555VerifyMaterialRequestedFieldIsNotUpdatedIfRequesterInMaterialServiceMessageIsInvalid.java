package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.model.JobStatusEnum;
import com.nbcuni.test.cp.wo.backlog.model.JobTypeEnum;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TC1555VerifyMaterialRequestedFieldIsNotUpdatedIfRequesterInMaterialServiceMessageIsInvalid extends BaseTest {

    @Story("MFAJ-1357")
    @TmsLink("MFAJ-1555")
    @Description("Verify that materialRequested field in Dynamo Db table is not updated if requester in the message to Material Service is not correct")
    @Test(groups = {"full"}, dataProvider = "getRequester")
    public void materialRequestedFieldIsNotUpdatedWhenRequesterInMaterialServiceMessageIsInvalid(String requester) {

        WorkOrderBacklogInputMessage workOrderBacklogMessage = new WorkOrderBacklogInputMessage();
        String materialRequestedJobId = "jobId";
        String workOrderId = workOrderBacklogMessage.getWorkOrderId();
        workOrderBacklogMessage.setMaterialRequested(materialRequestedJobId);
        testLogger.step("Given: a payload with workOrderId=" + workOrderId);
        testLogger.step("When:workOrder is sent to Kenisis stream" + woBacklogEventStreamKinesisProducerProperties.getProperty("stream"));
        sendMessage(workOrderBacklogMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: workOrder record is inserted in Dynamo Db table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertNotNull(workOrderDb, "WorkOrder record is NOT inserted in Dynamo Db table");
        Assert.assertEquals(workOrderDb.getMaterialRequested(), materialRequestedJobId, "MaterialRequested field does not contain required data");
        Assert.assertNull(workOrderDb.getMaterialRetrieval(), "MaterialRetrieval field is not null");

        StatusEvent statusEventMessage = setStatusEventMessageData(workOrderId, requester, materialRequestedJobId, JobTypeEnum.MATERIAL.getValue(), JobStatusEnum.DONE.getValue(), "");
        testLogger.step("When: status message for material retrieval is sent to Kinesis status stream with jobId:" + statusEventMessage.getJobId());
        sendMessage(statusEventMessage.getJSONObject(), statusEventStreamKinesisProducerProperties);
        testLogger.step("Then: materialRetrieval field for workOrder record from Dynamo Db table contains required data");
        workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertFalse(waitForMaterialRetrievalIsNotNull(workOrderId), "Material Retrieval field is not null");
    }

    @DataProvider(parallel = true)
    public static Object[][] getRequester() {
        return new Object[][]{
                //requester from Validation Service
                {null},
                {""}
        };
    }
}
