package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.WorkOrderBacklogStatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;

public class TC1584WOBacklogServiceIngestsWOWithActionCreate extends BaseTest {

    @Story("SVCS9-1405 WO Backlog | Feature | 'Create' workorder action")
    @TmsLink("MFAJ-1584")
    @Description("WorkOrder Backlog Service ingests work Orders with workOrderAction:CREATE")
    @Test(groups = {"full"}, dataProvider = "getWorkOrderAction")
    public void woBacklogServiceIngestsWOWithActionCreate(String workOrderAction) {

        String statusMessageReceivedNewWO = WorkOrderBacklogStatusMessageEnum.RECEIVED.getStatusMessagePattern();

        testLogger.step("Given: workOrder with '" + workOrderAction + "' workOrderAction");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setWorkOrderAction(workOrderAction);
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.step("When: Work order is sent to WorkOrder Backlog Service");
        sendMessage(workOrderBacklogInputMessage.getJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Status event is sent to status kinesis stream that workOrder is ingested and saved to DynamoDb");
        List<StatusEvent> statusEventsReceived = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(), String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()));
        Assert.assertEquals(statusEventsReceived.size(), 1, "There are no status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage: " + String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()) + ". Should be 1 status event");

        testLogger.step("And: Work order record is inserted into DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no record in dynamoDb for work order " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: 'workOrderAction' field is filled with '" + workOrderAction + "' value");
        Assert.assertEquals(workOrderDb.getWorkOrderAction(), workOrderAction, "Invalid workOrderAction in DynamoDb for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId());
    }


    @DataProvider
    public static Object[][] getWorkOrderAction() {
        return new Object[][]{
                {"CREATE"}
        };
    }

}
