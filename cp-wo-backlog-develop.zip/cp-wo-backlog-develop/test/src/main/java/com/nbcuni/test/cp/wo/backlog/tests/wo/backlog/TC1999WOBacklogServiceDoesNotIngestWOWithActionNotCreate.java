package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.WorkOrderBacklogStatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import wiremock.net.minidev.json.JSONObject;

import java.util.List;

public class TC1999WOBacklogServiceDoesNotIngestWOWithActionNotCreate extends BaseTest {

    @Story("SVCS9-1405 WO Backlog | Feature | 'Create' workorder action")
    @TmsLink("MFAJ-1999")
    @Description("WorkOrder Backlog Service ingests work Orders with workOrderAction:CREATE")
    @Test(groups = {"full"}, dataProvider = "getWorkOrderAction")
    public void woBacklogServiceDoesNotIngestWOWithActionNotCreate(String workOrderAction) {

        String statusMessageWOActionIsUnknownError = "workOrderAction \"%s\" is unknown";
        String jobStatusError = WorkOrderBacklogStatusMessageEnum.REJECTED.getJobStatus();
        Integer errorCode = 503;

        testLogger.step("Given: workOrder with '" + workOrderAction + "' workOrderAction");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setWorkOrderAction(workOrderAction);
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.step("When: Work order is sent to WorkOrder Backlog Service");
        sendMessage(workOrderBacklogInputMessage.getJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Error Status event is sent to the status stream");
        List<StatusEvent> statusEventsError = StatusEventKinesisBuffer.getInstance()
                .getJobStatusKinesisMapByWorkOrderIdAndJobStatus(workOrderBacklogInputMessage.getWorkOrderId(), jobStatusError);
        Assert.assertEquals(statusEventsError.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + ". Should be 1 status event");
        statusEventsError.forEach(statusEvent -> statusEvent.getErrors().forEach(error -> {
            Assert.assertEquals(error.get("errorCode"), errorCode);
            Assert.assertTrue(error.get("errorMessage").toString().contains(String.format(statusMessageWOActionIsUnknownError, workOrderAction)));
        }));

        testLogger.step("And: Work order record is NOT inserted to DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNull(workOrderDb, "There is record in dynamoDb for work order " + workOrderBacklogInputMessage.getWorkOrderId());
}

    @Story("SVCS9-1405 WO Backlog | Feature | 'Create' workorder action")
    @TmsLink("MFAJ-1999")
    @Description("WorkOrder Backlog Service ingests work Orders with workOrderAction:CREATE")
    @Test(groups = {"full"})
    public void woBacklogServiceDoesNotIngestWOWithMissedWorkOrderActionObject() {

        String statusMessageWOActionIsUnknownError = "workOrderAction \"%s\" is unknown";
        String jobStatusError = WorkOrderBacklogStatusMessageEnum.REJECTED.getJobStatus();
        Integer errorCode = 503;
        String workOrderAction = "undefined";

        testLogger.step("Given: workOrder with missed workOrderAction");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        JSONObject jsonObject = workOrderBacklogInputMessage.getJSONObject();
        jsonObject.remove("workOrderAction");
        testLogger.info(jsonObject.toString());

        testLogger.step("When: Work order is sent to WorkOrder Backlog Service");
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Error Status event is sent to the status stream");
        List<StatusEvent> statusEventsError = StatusEventKinesisBuffer.getInstance()
                .getJobStatusKinesisMapByWorkOrderIdAndJobStatus(workOrderBacklogInputMessage.getWorkOrderId(), jobStatusError);
        Assert.assertEquals(statusEventsError.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + ". Should be 1 status event");
        statusEventsError.forEach(statusEvent -> statusEvent.getErrors().forEach(error -> {
            Assert.assertEquals(error.get("errorCode"), errorCode);
            Assert.assertTrue(error.get("errorMessage").toString().contains(String.format(statusMessageWOActionIsUnknownError, workOrderAction)));
        }));

        testLogger.step("And: Work order record is NOT inserted to DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNull(workOrderDb, "There is record in dynamoDb for work order " + workOrderBacklogInputMessage.getWorkOrderId());
    }

    @DataProvider(parallel = true)
    public static Object[][] getWorkOrderAction() {
        return new Object[][]{
                {null},
                {""},
                {"UPDATE"},
                {"CANCEL"}
        };
    }
}
