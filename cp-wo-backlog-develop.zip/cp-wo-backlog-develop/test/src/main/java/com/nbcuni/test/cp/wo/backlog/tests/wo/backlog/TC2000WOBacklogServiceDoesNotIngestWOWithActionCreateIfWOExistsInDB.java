package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.WorkOrderBacklogStatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;

public class TC2000WOBacklogServiceDoesNotIngestWOWithActionCreateIfWOExistsInDB extends BaseTest {

    @Story("SVCS9-1405 WO Backlog | Feature | 'Create' workorder action")
    @TmsLink("MFAJ-2000")
    @Description("WorkOrder Backlog Service does NOT ingest work Order with workOrderAction:CREATE if the workorder is already in the database and has already been submitted to Job Submission service for processing")
    @Test(groups = {"component"}, dataProvider = "getParamsRejected")
    public void woBacklogServiceDoesNotIngestWOWithActionCreateWithCertainConditions(String materialRequested, String materialRetrieval, Boolean isValidated, Boolean isWOUpdated) {

        String errorMessageCreateIsNotAllowedError = "workOrderAction CREATE is not allowed when the workorder is processing";
        Integer errorCode = 504;
        String jobStatusError = WorkOrderBacklogStatusMessageEnum.REJECTED.getJobStatus();

        testLogger.step("Given: workOrder with 'CREATE' workOrderAction");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setMaterialRequested(materialRequested);
        workOrderBacklogInputMessage.setMaterialRetrieval(materialRetrieval);
        workOrderBacklogInputMessage.setValidated(isValidated);
        testLogger.info(workOrderBacklogInputMessage.getFullJSONObject().toString());

        testLogger.step("When: Work order with predefined fields is sent to WorkOrder Backlog Service");
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Work order record is inserted into DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no record in dynamoDb for work order " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("When: Work order is sent to WorkOrder Backlog Service again");
        sendMessage(workOrderBacklogInputMessage.getJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Error Status event is sent to the status stream");
        List<StatusEvent> statusEventsError = StatusEventKinesisBuffer.getInstance()
                .getJobStatusKinesisMapByWorkOrderIdAndJobStatus(workOrderBacklogInputMessage.getWorkOrderId(), jobStatusError);
        Assert.assertEquals(statusEventsError.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with jobStatus: " + jobStatusError + ". Should be 1 status event");
        statusEventsError.forEach(statusEvent -> statusEvent.getErrors().forEach(error -> {
            Assert.assertEquals(error.get("errorCode"), errorCode);
            Assert.assertTrue(error.get("errorMessage").toString().contains(errorMessageCreateIsNotAllowedError));
        }));

        if (materialRequested != null) {
            testLogger.step("And: MaterialRequested field in DynamoDb table is not null(new work order was not ingested)");
            workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
            Assert.assertNotNull(workOrderDb.getMaterialRequested(), "MaterialRequested field was updated(work order was ingested) for workOrderId: "
                    + workOrderBacklogInputMessage.getWorkOrderId());
        }

    }

    @Story("SVCS9-1405 WO Backlog | Feature | 'Create' workorder action")
    @TmsLink("MFAJ-2000")
    @Description("WorkOrder Backlog Service does NOT ingest work Order with workOrderAction:CREATE if the workorder is already in the database and has already been submitted to Job Submission service for processing")
    @Test(groups = {"component"}, dataProvider = "getParamsAccepted")
    public void woBacklogServiceIngestsWOWithActionCreateWithCertainConditions(String materialRequested, String materialRetrieval, Boolean isValidated, Boolean isWOUpdated) {

        String jobStatusError = WorkOrderBacklogStatusMessageEnum.REJECTED.getJobStatus();
        String statusMessageReceivedNewWO = WorkOrderBacklogStatusMessageEnum.RECEIVED.getStatusMessagePattern();
        String jobTypeWOBacklog = WorkOrderBacklogStatusMessageEnum.MATERIAL_REQUESTED.getJobType();

        testLogger.step("Given: workOrder with 'CREATE' workOrderAction");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setMaterialRequested(materialRequested);
        workOrderBacklogInputMessage.setMaterialRetrieval(materialRetrieval);
        workOrderBacklogInputMessage.setValidated(isValidated);
        testLogger.info(workOrderBacklogInputMessage.getFullJSONObject().toString());

        testLogger.step("When: Work order is sent to WorkOrder Backlog Service");
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Work order record is inserted into DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no record in dynamoDb for work order " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: MaterialRequested field in DynamoDb table is set to value: " + materialRequested);
        workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(workOrderDb.getMaterialRequested(), materialRequested, "Invalid MaterialRequested field for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("When: Work order is sent to WorkOrder Backlog Service again");
        sendMessage(workOrderBacklogInputMessage.getJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: There are no Error Status events that are sent to the status stream");
        List<StatusEvent> statusEventsError = StatusEventKinesisBuffer.getInstance()
                .getStatusMessagesByWorkOrderIdAndJobTypeAndJobStatus(workOrderBacklogInputMessage.getWorkOrderId(),
                        jobTypeWOBacklog,
                        jobStatusError);
        Assert.assertTrue(statusEventsError.isEmpty(), "There are error status events for work order "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with jobStatus: " + jobStatusError);

        testLogger.step("And: There are 2 'Received' status events that are sent to the status stream");
        List<StatusEvent> statusEventsReceived = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(), String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()));
        Assert.assertTrue(statusEventsReceived.size() >= 2, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage: " + String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()));

        testLogger.step("And: MaterialRequested field in DynamoDb table is updated(work order was ingested and updated)");
        workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotEquals(workOrderDb.getMaterialRequested(), materialRequested, "MaterialRequested field wasn't updated(work order was not ingested) for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId());

    }

    @DataProvider(parallel = true)
    public static Object[][] getParamsAccepted() {
        return new Object[][]{
                //materialRequested; materialRetrieval; validated; isWOUpdated
                {
                        "jobId", null, null, true //+
                },
                {
                        "jobId", "jobId", null, true //+
                },
                {
                        "jobId", "jobId", false, true //+
                },
                {
                        "jobId1", "jobId2", null, true //+
                },
                {
                        "jobId1", "jobId2", false, true //+
                },
                {
                        "jobId", null, false, true //+
                },
                {
                        null, "jobId", false, true //+
                },
                {
                        null, null, false, true //+
                }
        };
    }

    @DataProvider(parallel = true)
    public static Object[][] getParamsRejected() {
        return new Object[][]{
                //materialRequested; materialRetrieval; validated, isWOUpdated
                {
                        "jobId", "jobId", true, false // work order is sent to job submission
                },
                {
                        "jobId1", "jobId2", true, false // its not possible for our system to being in a state where validated == true and materialRequest != materialRetrieval
                },
                {
                        "jobId1", null, true, false // its not possible for our system to being in a state where validated == true and materialRequest != materialRetrieval
                },
                {
                        null, "jobId", true, false // its not possible for our system to being in a state where validated == true and materialRequest != materialRetrieval
                },
        };
    }
}
