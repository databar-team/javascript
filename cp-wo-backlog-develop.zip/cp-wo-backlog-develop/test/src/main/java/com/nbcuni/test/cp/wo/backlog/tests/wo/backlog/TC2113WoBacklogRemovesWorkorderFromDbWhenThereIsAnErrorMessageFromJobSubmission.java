package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.WorkOrderBacklogStatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TC2113WoBacklogRemovesWorkorderFromDbWhenThereIsAnErrorMessageFromJobSubmission extends CommonValidations {

    @Story("MFAJ-1956")
    @TmsLink("MFAJ-2113")
    @Description("Verify that work order record is removed from DB when Job Submission sends a status of Error")
    @Test(groups = {"full", "phase1", "component"}, dataProvider = "getJobType")
    public void workOrderIsRemovedFromDbWhenErrorMessageIsSentFromJobSubmission(String jobType) {

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setMaterialRequested("jobId");
        workOrderBacklogInputMessage.setMaterialRetrieval("jobId");
        workOrderBacklogInputMessage.setValidated(true);
        testLogger.step("Given: A payload with workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());
        testLogger.step("When: Valid message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.getProperty("stream"));
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no workOrder in dynamoDb with workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Error status event was received");
        StatusEvent statusEvent = new StatusEvent();
        statusEvent.setRequester("cp-WorkorderAction");
        statusEvent.setCpId(workOrderBacklogInputMessage.getWorkOrderId() + "_cpId");
        statusEvent.setWorkOrderId(workOrderBacklogInputMessage.getWorkOrderId());
        statusEvent.setJobType(jobType);
        statusEvent.setJobStatus(WorkOrderBacklogStatusMessageEnum.REJECTED.getJobStatus());
        statusEvent.setTimestamp(String.valueOf(System.currentTimeMillis()));
        sendMessage(statusEvent.getJSONObject(), statusEventStreamKinesisProducerProperties);

        testLogger.step("And: work order record is removed from DB");
        workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNull(workOrderDb, "WorkOrder record is NOT removed from DB");
    }

    @DataProvider(parallel = true)
    public static Object[][] getJobType() {
        return new Object[][]{
                //jobType
                {"cp-JobSubmission"},
                {"JobSubmission"}
        };
    }
}
