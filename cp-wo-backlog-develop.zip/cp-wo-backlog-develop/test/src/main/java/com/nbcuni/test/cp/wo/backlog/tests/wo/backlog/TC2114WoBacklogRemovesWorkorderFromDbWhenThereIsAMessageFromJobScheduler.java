package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.*;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;

public class TC2114WoBacklogRemovesWorkorderFromDbWhenThereIsAMessageFromJobScheduler extends BaseTest {

    @Story("SVCS9-1956")//SVCS9-1356
    @TmsLink("SVCS9-2114")//SVCS9-1571
    @Description("Verify that work order record is removed from DB when Job Scheduler sends a status of Done")
    @Test(groups = {"full", "phase1", "component"})
    public void workOrderIsRemovedFromDbWhenSuccessfullyComplete() {

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setMaterialRequested("jobId");
        workOrderBacklogInputMessage.setMaterialRetrieval("jobId");
        workOrderBacklogInputMessage.setValidated(true);
        testLogger.step("Given: A payload with workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());
        testLogger.step("When: Valid message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.getProperty("stream"));
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no workOrder in dynamoDb with workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Work order successfully completes status event was received");
        StatusEvent statusEvent = new StatusEvent();
        statusEvent.setRequester("cp-JobSubmission");
        statusEvent.setCpId(workOrderBacklogInputMessage.getWorkOrderId() + "_cpId");
        statusEvent.setWorkOrderId(workOrderBacklogInputMessage.getWorkOrderId());
        statusEvent.setJobType("cp-jsRemove");
        statusEvent.setJobStatus(WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getJobStatus());
        statusEvent.setTimestamp(String.valueOf(System.currentTimeMillis()));
        statusEvent.setStatusMessage("Completed Fulfillment Request " + statusEvent.getCpId());
        sendMessage(statusEvent.getJSONObject(), statusEventStreamKinesisProducerProperties);

        testLogger.step("Then: Done Status Message is received");
        List<StatusEvent> statusEventMessages = StatusEventKinesisBuffer.getInstance()
                .getJobStatusKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId(), StatusMessageEnum.WORKORDER_CLEARED_FROM_BACKLOG);
        Assert.assertNotNull(statusEventMessages, "There is no status event with workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId() + " and required status message in the stream");
        Assert.assertEquals(statusEventMessages.get(0).getRequester(), WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getRequester(), "Requester is not correct in the message");
        Assert.assertEquals(statusEventMessages.get(0).getCpId(), statusEvent.getCpId(), "CpId is not correct in the message");
        Assert.assertEquals(statusEventMessages.get(0).getJobType(), WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getJobType(), "JobType is not correct in the message");
        Assert.assertEquals(statusEventMessages.get(0).getJobStatus(), WorkOrderBacklogStatusMessageEnum.VALIDATIONS_COMPLETE.getJobStatus(), "Job Status is not correct in the message");
        Assert.assertTrue(statusEventMessages.get(0).getErrors().isEmpty(), "There are errors in the status event message");
        testLogger.step("And: work order record is removed from DB");
        workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNull(workOrderDb, "WorkOrder record is not removed from DB");
    }

    @Story("SVCS9-1956")//SVCS9-1356
    @TmsLink("SVCS9-2114")//SVCS9-1571
    @Description("Verify that work order record is not removed from DB when Job Scheduler sends a status of Error")
    @Test(groups = {"full", "phase1", "component"}, dataProvider = "getJobType")
    public void workOrderIsNotRemovedFromDbWhenCompleteWithStatusError(String jobType) {

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setMaterialRequested("jobId");
        workOrderBacklogInputMessage.setMaterialRetrieval("jobId");
        workOrderBacklogInputMessage.setValidated(true);
        testLogger.step("Given: A payload with workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());
        testLogger.step("When: Valid message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.getProperty("stream"));
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no workOrder in dynamoDb with workOrderId " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Work order unsuccessfully completes error status event was received");
        StatusEvent statusEvent = new StatusEvent();
        statusEvent.setRequester("cp-JobSubmission");
        statusEvent.setCpId(workOrderBacklogInputMessage.getWorkOrderId() + "_cpId");
        statusEvent.setWorkOrderId(workOrderBacklogInputMessage.getWorkOrderId());
        statusEvent.setJobType(jobType);
        statusEvent.setJobStatus(WorkOrderBacklogStatusMessageEnum.REJECTED.getJobStatus());
        statusEvent.setTimestamp(String.valueOf(System.currentTimeMillis()));
        sendMessage(statusEvent.getJSONObject(), statusEventStreamKinesisProducerProperties);

        testLogger.step("Then: No Status Message is received");
        testLogger.step("And: work order record is not removed from DB");
        workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNull(workOrderDb, "WorkOrder record is removed from DB");
    }

    @DataProvider(parallel = true)
    public static Object[][] getJobType() {
        return new Object[][]{
                //jobType
                {"cp-jsCreate"},
                {"cp-jsRemove"},
                {"cp-jsTrigger"},
                {"JobScheduler"},
                {"DynamicStepFunction"}
        };
    }
}
