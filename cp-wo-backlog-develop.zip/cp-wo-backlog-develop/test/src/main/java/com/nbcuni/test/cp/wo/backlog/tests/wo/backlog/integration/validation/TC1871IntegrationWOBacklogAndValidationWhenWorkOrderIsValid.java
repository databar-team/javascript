package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.integration.validation;

import com.amazonaws.services.s3.model.S3Object;
import com.google.gson.JsonObject;
import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.StatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.contract.WorkOrderContract;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class TC1871IntegrationWOBacklogAndValidationWhenWorkOrderIsValid extends BaseTest {

    static final String WORK_ORDER_VIDEO_CC = "src/main/resources/templates/work_order_video_cc.json";

    @Story("MFAJ-1624")
    @TmsLink("MFAJ-1871")
    @Description("Verify that materialRequested field is created in Dynamo DB if workOrder is valid")
    @Test(groups = {"integration"}, enabled = false)
    public void integrationWOBacklogAndValidationMaterialRequestedFieldIsCreatedWhenMaterialRequestedMessageIsInStatusStream() {
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.info("Given: A payload for workOrderId: " + workOrderId);
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.info("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendWorkOrderBacklogMessage(workOrderBacklogInputMessage, woBacklogEventStreamKinesisProducerProperties);

        testLogger.info("Then: WO is stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertNotNull(workOrderDb, "WorkOrder with id " + workOrderId + " wasn't found in DynamoDb");

        testLogger.step("And: Validation status event message  is sent to the status stream");
        List<StatusEvent> statusEventsWithValidationWorkOrderAndMaterial = StatusEventKinesisBuffer.getInstance().getJobStatusKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId(), StatusMessageEnum.VALIDATING_WORKORDER_AND_MATERIALS);
        Assert.assertNotNull(statusEventsWithValidationWorkOrderAndMaterial, "There are no status events message with validation for work order " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Message 'materialRequested' is sent to the status stream");
        List<StatusEvent> statusEventsForWorkOrderBacklogWithMaterialRequested = StatusEventKinesisBuffer.getInstance().getJobStatusKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId(), StatusMessageEnum.MATERIAL_REQUESTED);
        Assert.assertNotNull(statusEventsForWorkOrderBacklogWithMaterialRequested, StatusMessageEnum.MATERIAL_REQUESTED.getValue() + " should be sent to the status stream for work order that require metadata approval. WorkOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());

        workOrderDb = getWorkOrderFromDbByWorkOrderId(statusEventsForWorkOrderBacklogWithMaterialRequested.get(0).getWorkOrderId());
        Assert.assertNotNull(workOrderDb.getMaterialRequested(), "MaterialRequested field has not been created");
        Assert.assertTrue(workOrderDb.getMaterialRequested().contains(statusEventsForWorkOrderBacklogWithMaterialRequested.get(0).getJobId()), "MaterialRequested field does not contain required jobId");
    }

    @Story("SVCS9-1971")
    @TmsLink("SVCS9-1871")
    @Description("Verify that request to WO Backlog service triggers Material validation in Validation service for valid WO")
    @Test(groups = {"integration"})
    public void temp() {

        String jobStatusRunning = "Running";
        String jobStatusDone = "Done";
        String jobTypeCPValidation = "cp-Validation";

        testLogger.step("Given: workOrder with jobId parity");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessageContract = new WorkOrderBacklogInputMessage(objectMapper);
        workOrderBacklogInputMessageContract.setWorkOrderContract(getWorkOrderFromTemplate(WORK_ORDER_VIDEO_CC));
        workOrderBacklogInputMessageContract.setMaterialRequested(System.currentTimeMillis() + "1");
        workOrderBacklogInputMessageContract.setMaterialRetrieval(workOrderBacklogInputMessageContract.getMaterialRequested());
        String workOrderId = workOrderBacklogInputMessageContract.getWorkOrderContract().getOriginalCpId();
        testLogger.info(workOrderBacklogInputMessageContract.getJSONObjectFromContract().toString());

        String jobId = workOrderBacklogInputMessageContract.getMaterialRequested();
        testLogger.step("And: rawMaterialMetadataFile.json is stored at S3");
        JsonObject jsonObject = getRawMaterialForWOrkOrder();
        putJsonObjectToS3(jsonObject, workOrderBacklogInputMessageContract.getRawMaterialSetPath(jobId));

        testLogger.step("When: Work order with predefined fields is sent to WorkOrder Backlog Service");
        sendMessage(workOrderBacklogInputMessageContract.getJSONObjectFromContract(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Work order record is inserted into DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderId);
        Assert.assertNotNull(workOrderDb, "There is no record in dynamoDb for work order " + workOrderId);
        testLogger.step("And: Status message that materials are validating is sent to the status stream");
        List<StatusEvent> statusEventsRunningForMaterialsValid = StatusEventKinesisBuffer.getInstance()
                .getStatusMessagesByWorkOrderIdAndJobTypeAndJobStatus(workOrderId, jobTypeCPValidation, jobStatusRunning);
        Assert.assertEquals(statusEventsRunningForMaterialsValid.size(), 1,
                "There is no Running messages in status stream associated with " + workOrderId);
        testLogger.step("And: Status message that materials are validated is sent to the status stream");
        List<StatusEvent> statusEventsDoneForMaterialsValid = StatusEventKinesisBuffer.getInstance()
                .getStatusMessagesByWorkOrderIdAndJobTypeAndJobStatus(workOrderId, jobTypeCPValidation, jobStatusDone);
        Assert.assertEquals(statusEventsDoneForMaterialsValid.size(), 1,
                "There is no Done messages in status stream associated with " + workOrderId);
        testLogger.step("And: Validated materialMetadataFile.json is stored at S3");
        S3Object s3Object = s3ServiceUtils.getItemFromS3BucketWithWaiting(workOrderBacklogInputMessageContract
                .getMaterialMetadataOutputFilePath(s3MaterialStorage, jobId));
        Assert.assertNotNull(s3Object, "materialMetadataFile.json in S3 bucket: " + s3Service.listObjects().getBucketName()
                + " wasn't found for workOrderId: " + workOrderId);
    }
}
