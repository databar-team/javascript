package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.integration.validation;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.StatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class TC1873IntegrationWOBacklogAndValidationWhenWorkOrderIsInvalid extends BaseTest {

    @Story("MFAJ-1624")
    @TmsLink("MFAJ-1873")
    @Description("Verify that materialRequested field is not created in Dynamo DB if workOrder is invalid")
    @Test(groups = {"integration"}, enabled = false)
    public void integrationWOBacklogAndValidationMaterialRequestedFieldIsNotCreatedWhenWorkOrderIsInvalid() {
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setDueDate(null);
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.info("Given: A payload for workOrderId: " + workOrderId);
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.info("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendWorkOrderBacklogMessage(workOrderBacklogInputMessage, woBacklogEventStreamKinesisProducerProperties);

        testLogger.info("Then: WO is stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertNotNull(workOrderDb, "WorkOrder with id " + workOrderId + " wasn't found in DynamoDb");

        testLogger.step("And: Validation status event message  is sent to the status stream");
        List<StatusEvent> statusEventsWithValidationWorkOrderAndMaterial = StatusEventKinesisBuffer.getInstance().getJobStatusKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId(), StatusMessageEnum.VALIDATING_WORKORDER_AND_MATERIALS);
        Assert.assertNotNull(statusEventsWithValidationWorkOrderAndMaterial, "There are no status events message with validation for work order " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Message 'materialRequested' is sent to the status stream");
        List<StatusEvent> statusEventsForWorkOrderBacklogWithMaterialRequested = StatusEventKinesisBuffer.getInstance().getJobStatusKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId(), StatusMessageEnum.MATERIAL_REQUESTED);
        Assert.assertNull(statusEventsForWorkOrderBacklogWithMaterialRequested, StatusMessageEnum.MATERIAL_REQUESTED.getValue() + " should NOT be sent to the status stream for work order that require metadata approval. WorkOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());

        workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertNull(workOrderDb.getMaterialRequested(), "MaterialRequested field is created for workOrder " + workOrderId);
    }

    @Story("MFAJ-1971")
    @TmsLink("MFAJ-1873")
    @Description("Verify that request to WO Backlog service doesn't trigger Material validation in Validation service for invalid WO")
    @Test(groups = {"integration"}, enabled = false)
    public void requestToWOBacklogDoesNotTriggerMaterialValidationInValidationServiceForInvalidWO() {
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setDueDate(null);
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.info("Given: A payload for workOrderId: " + workOrderId);
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.info("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendWorkOrderBacklogMessage(workOrderBacklogInputMessage, woBacklogEventStreamKinesisProducerProperties);

        testLogger.info("Then: WO is stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertNotNull(workOrderDb, "WorkOrder with id " + workOrderId + " wasn't found in DynamoDb");

        testLogger.step("And: Validation status event message  is sent to the status stream");
        List<StatusEvent> statusEventsWithValidationWorkOrderAndMaterial = StatusEventKinesisBuffer.getInstance().getJobStatusKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId(), StatusMessageEnum.VALIDATING_WORKORDER_AND_MATERIALS);
        Assert.assertNotNull(statusEventsWithValidationWorkOrderAndMaterial, "There are no status events message with validation for work order " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Message 'materialRequested' is sent to the status stream");
        List<StatusEvent> statusEventsForWorkOrderBacklogWithMaterialRequested = StatusEventKinesisBuffer.getInstance().getJobStatusKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId(), StatusMessageEnum.MATERIAL_REQUESTED);
        Assert.assertNull(statusEventsForWorkOrderBacklogWithMaterialRequested, StatusMessageEnum.MATERIAL_REQUESTED.getValue() + " should NOT be sent to the status stream for work order that require metadata approval. WorkOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());

        workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderId);
        Assert.assertNull(workOrderDb.getMaterialRequested(), "MaterialRequested field is created for workOrder " + workOrderId);
    }
}
