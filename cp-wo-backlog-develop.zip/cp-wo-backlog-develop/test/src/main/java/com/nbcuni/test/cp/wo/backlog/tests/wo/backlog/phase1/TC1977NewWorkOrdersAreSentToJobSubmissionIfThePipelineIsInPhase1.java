package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.phase1;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.*;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class TC1977NewWorkOrdersAreSentToJobSubmissionIfThePipelineIsInPhase1 extends CommonValidations {
    @Story("SVCS9-1729")
    @TmsLink("SVCS-1977")
    @Description("When the pipeline is in Phase 1, all new workOrders that are ingested to the DB are sent to Job Submission")
    @Test(groups = {"phase1"})

    public void newWorkOrdersAreSentToJobSubmissionIfThePipelineIsInPhase1() {
        String jobStatusReceived = WorkOrderBacklogStatusMessageEnum.RECEIVED.getJobStatus();
        String jobTypeWoBacklog = WorkOrderBacklogStatusMessageEnum.RECEIVED.getJobType();
        String statusMessageReceived = WorkOrderBacklogStatusMessageEnum.RECEIVED.getStatusMessagePattern();
        String requesterTranslator = WorkOrderBacklogStatusMessageEnum.REQUESTING_VALIDATION.getRequester();

        testLogger.step("Given: The pipeline is in Phase 1");
        Assert.assertEquals(PHASE1, getCurrentPhase(), "Different phase is set for pipeline");

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.step("And: A payload for workOrderId: " + workOrderId);
        testLogger.step(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.step("When: Message is sent to kinesis stream "
                + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendWorkOrderBacklogMessage(workOrderBacklogInputMessage, woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: WO is stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderId);
        Assert.assertNotNull(workOrderDb, "WorkOrder with id " + workOrderId + " wasn't found in DynamoDb");
        testLogger.step("And: Status message when the service ingests a request is sent to Status Stream");
        List<StatusEvent> statusEventsForWorkOrderIdAndReceivedStatusMessage = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderId, String.format(statusMessageReceived, workOrderId));
        Assert.assertEquals(statusEventsForWorkOrderIdAndReceivedStatusMessage.size(), 1,
                "Invalid number of status events for workOrderId: " + workOrderId +
                        " and status message: " + String.format(statusMessageReceived, workOrderId) + ". Should be 1 status event");
        statusEventsForWorkOrderIdAndReceivedStatusMessage.forEach(statusEvent ->
                verifyStatusEvent(statusEvent, workOrderBacklogInputMessage, requesterTranslator, jobTypeWoBacklog,
                        jobStatusReceived, String.format(statusMessageReceived, workOrderId)));

        testLogger.step("And: Event is available in job submission stream");
        List<JobSubmissionContract> jobSubmissions = JobSubmissionKinesisBuffer.getInstance()
                .getJobSubmissionMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(jobSubmissions.size(), 1,"There is no events in job submission stream , workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId());

    }
}
