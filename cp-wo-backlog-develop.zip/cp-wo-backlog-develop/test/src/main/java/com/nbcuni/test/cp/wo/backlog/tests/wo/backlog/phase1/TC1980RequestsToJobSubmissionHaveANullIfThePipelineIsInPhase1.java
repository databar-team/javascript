package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.phase1;

import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class TC1980RequestsToJobSubmissionHaveANullIfThePipelineIsInPhase1 extends CommonValidations {
    @Story("SVCS9-1729")
    @TmsLink("SVCS-1980")
    @Description("When the pipeline is in Phase 1, requests to Job Submission should have a null materialMetadata path")
    @Test(groups = {"phase1"})

    public void requestsToJobSubmissionHaveANullIfThePipelineIsInPhase1() {

        testLogger.step("Given: The pipeline is in Phase 1");
        Assert.assertEquals(PHASE1, getCurrentPhase(), "Different phase is set for pipeline");

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.step("And: A payload for workOrderId: " + workOrderId);
        testLogger.step(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.step("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendMessage(workOrderBacklogInputMessage.getJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("And: Event is available in job submission stream");
        List<JobSubmissionContract> jobSubmissions = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(jobSubmissions.size(), 1, "There is no events in job submission stream , workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: MaterialMetadata path is null");

        Assert.assertNull(jobSubmissions.get(0).getMaterialMetadata(), "MaterialMetadata path should be null" + workOrderBacklogInputMessage);

    }
}
