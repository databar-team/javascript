package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.phase1;

import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class TC1981WorkOrderIsNotIngestedIfTheSameWorkOrderIdExistsInTheDatabaseIfThePipelineIsInPhase1 extends CommonValidations {
    @Story("SVCS9-1729")
    @TmsLink("SVCS-1981")
    @Description("When the pipeline is in Phase 1, requests to Job Submission should have a null materialMetadata path")
    @Test(groups = {"phase1"})

    public void workOrderIsNotIngestedIfTheSameWorkOrderIdExistsInTheDatabaseIfThePipelineIsInPhase1() {

        testLogger.step("Given: The pipeline is in Phase 1");
        Assert.assertEquals(PHASE1, getCurrentPhase(), "Different phase is set for pipeline");

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        testLogger.step("And: A payload for workOrderId: " + workOrderId);
        testLogger.step(workOrderBacklogInputMessage.getJSONObject().toString());
        testLogger.step("And: workOrder with the same Id exists in dataBase");
        sendWorkOrderBacklogMessage(workOrderBacklogInputMessage, woBacklogEventStreamKinesisProducerProperties);
        Assert.assertNotNull(getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderId),"There is no workOrder in DynamoDb " + workOrderBacklogInputMessage);

        testLogger.step("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendWorkOrderBacklogMessage(workOrderBacklogInputMessage, woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("And: Event is available in job submission stream");
        List<JobSubmissionContract> jobSubmissions = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId(), 2);
        Assert.assertNull(jobSubmissions, "There two events in job submission stream , workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: MaterialMetadata path is null");
        jobSubmissions = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());

        Assert.assertEquals(jobSubmissions.size(),1,
                "There are more that 1 request to jobSubmission after sending a workOrder that already exists in DynamoDb" + workOrderBacklogInputMessage);

    }
}
