package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.phase1;

import com.nbcuni.test.cp.wo.backlog.model.StatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TC2073WoBacklogServiceDoesNotIngestWorkorderIfPxfInfoIsInvalidInPhase1or2 extends CommonValidations {

    @Story("SVCS9-1894")
    @TmsLink("SVCS9-2073")
    @Description("Verify that workorder is not ingested in phase 1 or 2 if there is no pxfInfo")
    @Test(groups = {"phase1", "phase2"}, dataProvider = "getPxfInfo")
    public void workOrderIsNotIngestedIfThereIsNoPxfInfo(String pxfInfo) {
        List<String> errorCodes = new ArrayList<>();
        List<String> errorMessages = new ArrayList<>();
        errorCodes.add("501");
        errorMessages.add("Missing or Invalid pxfInfo");
        String statusMessage = StatusMessageEnum.REJECTED_NEW_WORK_ORDER.getValue();

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = workOrderBuilder.createKinesisMessage();
        JSONObject jsonObject = workOrderBacklogInputMessage.getJSONObject();
        if (pxfInfo != null && pxfInfo.equals("withoutPxfInfo")) {
            jsonObject.remove("pxfInfo");
        } else {
            jsonObject.put("pxfInfo", pxfInfo);
        }
        testLogger.info("Given: A payload for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
        testLogger.info(jsonObject.toString());

        testLogger.info("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNull(workOrderDb, "There is an item in Dynamo DB table by workOrderId = " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.info("And: Error status message is sent to Status Stream");
        verifyErrorStatusEvent(workOrderBacklogInputMessage.getWorkOrderId(),  statusMessage, errorCodes, errorMessages);
    }

    @DataProvider(parallel = true)
    public static Object[][] getPxfInfo() {
        return new Object[][]{
                //pxfInfo
                {""},
                {null},
                {"withoutPxfInfo"}
        };
    }
}
