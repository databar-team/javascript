package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.requesttomaterialservice;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.material.MaterialKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.MaterialRequestMessage;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.WorkOrderBacklogStatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import wiremock.net.minidev.json.JSONArray;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class TC1139WOBacklogDoesNotMakeRequestToMaterialServiceForInvalidWO extends BaseTest {

    public static final String MATERIAL_ID = "DBRO_0000000001234_01";

    @Story("SVCS9-1971 WO Backlog | Feature | Make Material Service requests from backlog")
    @TmsLink("SVCS9-1139")
    @Description("WO Backlog doesn't make a request to the Material Service if new workOrder validation is failed")
    @Test(groups = {"full"}, dataProvider = "getInvalidField")
    public void validationServiceDoesNotPostRequestToMaterialServiceIfWOIsNotValid(String invalidField) {
        String statusMessageRejectedNewWO = WorkOrderBacklogStatusMessageEnum.REJECTED.getStatusMessagePattern();
        String statusMessageMaterialRequested = WorkOrderBacklogStatusMessageEnum.MATERIAL_REQUESTED.getStatusMessagePattern();

        testLogger.step("Given: workOrder with invalid payload with missed field: " + invalidField);
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.getVideoSource().get(0).setId(MATERIAL_ID);
        JSONObject jsonObject = workOrderBacklogInputMessage.getJSONObject();
        switch (invalidField) {
            case "dueDate":
                jsonObject.remove(invalidField);
                break;
            case "profileName":
                JSONObject profile = workOrderBacklogInputMessage.getProfile().getJSONObject();
                profile.remove("name");
                jsonObject.put("profile", profile);
                break;
            case "requiredComponents":
                jsonObject.remove(invalidField);
                break;
        }
        testLogger.info(jsonObject.toString());

        testLogger.step("When: Work Order is sent to wo backlog stream: " + woBacklogEventStreamKinesisProducerProperties.getProperty("stream"));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Status event is sent to status kinesis stream that workOrder is rejected");
        List<StatusEvent> statusEventsRejected = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(),
                        statusMessageRejectedNewWO);
        Assert.assertEquals(statusEventsRejected.size(), 1, "Invalid number of 'Rejected' status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + ". Should be 1 'Rejected' status event");

        testLogger.step("And: Status event is not sent to the status kinesis stream that request to Material Service is performed");
        List<StatusEvent> statusEventsMaterialRequested = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(), statusMessageMaterialRequested);
        Assert.assertTrue(statusEventsMaterialRequested.isEmpty(), "There are status events with request to Material Service for workOrderId:"
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage " + statusMessageMaterialRequested);

        testLogger.step("And: Message from WO Backlog Service that request to Material Service is performed is not sent to Material Service stream");
        List<MaterialRequestMessage> materialRequestMessageList = MaterialKinesisBuffer.getInstance().getMaterialRequestMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertTrue(materialRequestMessageList.isEmpty(), "There is a request to Material Service for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
    }

    @DataProvider(parallel = true)
    public static Object[][] getInvalidField() {
        return new Object[][]{
                {"dueDate"},
                {"profileName"},
                {"requiredComponents"}
        };
    }

    @Story("SVCS9-1971 WO Backlog | Feature | Make Material Service requests from backlog")
    @TmsLink("SVCS9-1139")
    @Description("WO Backlog doesn't make a request to the Material Service if new workOrder validation is failed when 'video' or 'cc' in requiredComponents")
    @Test(groups = {"full"}, dataProvider = "getInvalidFieldForIngestedWorkOrder")
    public void validationServiceDoesNotPostRequestToMaterialServiceIfWOIsNotValidWhenVideoOrCCInRequiredComponents(ArrayList<String> requiredComponent, String invalidField) {
        String statusMessageReceivedNewWO = WorkOrderBacklogStatusMessageEnum.RECEIVED.getStatusMessagePattern();
        String statusMessageValidationFailed = WorkOrderBacklogStatusMessageEnum.WO_VALIDATION_FAILED.getStatusMessagePattern();
        String statusMessageMaterialRequested = WorkOrderBacklogStatusMessageEnum.MATERIAL_REQUESTED.getStatusMessagePattern();

        testLogger.step("Given: workOrder with invalid payload");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.getVideoSource().get(0).setId(MATERIAL_ID);
        workOrderBacklogInputMessage.setRequiredComponents(requiredComponent);
        JSONObject jsonObject = workOrderBacklogInputMessage.getJSONObject();

        if (invalidField.contains("audioAndCaptionPreference")) {
            jsonObject.remove(invalidField);
        } else if (invalidField.contains("id") || invalidField.contains("TVDNumber")) {
            JSONArray videoSourceJSONArray = new JSONArray();
            workOrderBacklogInputMessage.getVideoSource().forEach(videoSource -> {
                JSONObject videoSourceJsonObject = videoSource.getJSONObject();
                videoSourceJsonObject.remove(invalidField);
                videoSourceJSONArray.add(videoSourceJsonObject);
            });
            jsonObject.put("videoSource", videoSourceJSONArray);
        } else
            Assert.fail("There is no case for given parameter: " + invalidField);

        testLogger.info(jsonObject.toString());

        testLogger.step("When: Work Order is sent to wo backlog stream: " + woBacklogEventStreamKinesisProducerProperties.getProperty("stream"));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Status event is sent to status kinesis stream that workOrder is received");
        List<StatusEvent> statusEventsReceived = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(),
                        String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()));
        Assert.assertEquals(statusEventsReceived.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage "
                + statusMessageReceivedNewWO + ". Should be 1 status event");

        testLogger.step("Then: Status event is sent to status kinesis stream that workOrder fails validation");
        List<StatusEvent> statusEventsValidationFailed = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(),
                        statusMessageValidationFailed);
        Assert.assertEquals(statusEventsValidationFailed.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage: "
                + statusMessageValidationFailed + ". Should be 1 status event");

        testLogger.step("And: Status event is not sent to the status kinesis stream that request to Material Service is performed");
        List<StatusEvent> statusEventsMaterialRequested = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(), statusMessageMaterialRequested);
        Assert.assertTrue(statusEventsMaterialRequested.isEmpty(), "There are status events with request to Material Service for workOrderId:"
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage: " + statusMessageMaterialRequested);

        testLogger.step("And: Message from WO Backlog Service that request to Material Service is performed is not sent to Material Service stream");
        List<MaterialRequestMessage> materialRequestMessageList = MaterialKinesisBuffer.getInstance().getMaterialRequestMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertTrue(materialRequestMessageList.isEmpty(), "There is a request to Material Service for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
    }


    @DataProvider(parallel = true)
    public static Object[][] getInvalidFieldForIngestedWorkOrder() {
        return new Object[][]{
                {new ArrayList<>(Collections.singletonList("video")), "id"},
                {new ArrayList<>(Collections.singletonList("video")), "TVDNumber"},
                {new ArrayList<>(Collections.singletonList("video")), "audioAndCaptionPreference"},
                {new ArrayList<>(Collections.singletonList("cc")), "id"},
                {new ArrayList<>(Collections.singletonList("cc")), "TVDNumber"}
        };
    }
}
