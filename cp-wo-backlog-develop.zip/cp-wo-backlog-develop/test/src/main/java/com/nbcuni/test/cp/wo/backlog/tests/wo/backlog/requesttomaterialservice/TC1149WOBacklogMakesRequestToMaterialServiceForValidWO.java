package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.requesttomaterialservice;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.material.MaterialKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.MaterialRequestMessage;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.WorkOrderBacklogStatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;
import wiremock.net.minidev.json.JSONObject;

import java.util.List;

public class TC1149WOBacklogMakesRequestToMaterialServiceForValidWO extends BaseTest {


    public static final String MATERIAL_ID = "DBRO_0000000001234_01";

    @Story("SVCS9-1971 WO Backlog | Feature | Make Material Service requests from backlog")
    @TmsLink("SVCS9-1149")
    @Description("WO Backlog makes a request to the Material Service if new workOrder validation is successful")
    @Test(groups = {"full"})
    public void woBacklogMakesRequestToMaterialServiceIfNewWOIsValid() {
        String statusMessageReceivedNewWO = WorkOrderBacklogStatusMessageEnum.RECEIVED.getStatusMessagePattern();
        String statusMessageMaterialRequested = WorkOrderBacklogStatusMessageEnum.MATERIAL_REQUESTED.getStatusMessagePattern();

        testLogger.step("Given: Work Order with valid payload");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.getVideoSource().get(0).setId(MATERIAL_ID);
        testLogger.info(workOrderBacklogInputMessage.getJSONObject().toString());

        testLogger.step("When: Work Order is sent to wo backlog stream: " + woBacklogEventStreamKinesisProducerProperties.getProperty("stream"));
        sendMessage(workOrderBacklogInputMessage.getJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Status event is sent to status kinesis stream that workOrder is ingested");
        List<StatusEvent> statusEventsReceived = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(),
                        String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()));
        Assert.assertEquals(statusEventsReceived.size(), 1, "Invalid number of status events for workOrderId "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage "
                + String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()));

        testLogger.step("And: Status event is sent to the status kinesis stream that request to Material Service is performed");
        List<StatusEvent> statusEventsMaterialRequested = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(), statusMessageMaterialRequested);
        Assert.assertEquals(statusEventsMaterialRequested.size(), 1, "Invalid number of Material Requested status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage " + statusMessageMaterialRequested);

        testLogger.step("And: There are no errors in status event with request to Material Service");
        statusEventsMaterialRequested.forEach(event ->
            Assert.assertTrue(event.getErrors().isEmpty(), "There are errors status event with request to Material Service for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId()));

        String jobIdStatusEvent = statusEventsMaterialRequested.get(0).getJobId();
        testLogger.step("And: JobId: " + jobIdStatusEvent + " for status message with workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Message from WO Backlog Service that request to Material Service is performed is sent to Material Service stream with the same jobId: " + jobIdStatusEvent);
        List<MaterialRequestMessage> materialRequestMessageList = MaterialKinesisBuffer.getInstance()
                .getMaterialRequestMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(materialRequestMessageList.size(), 1,
                "Invalid number of requests to Material Service for workOrderId: "
                        + workOrderBacklogInputMessage.getWorkOrderId());
        materialRequestMessageList.forEach(materialRequestMessage -> {
            Assert.assertEquals(materialRequestMessage.getWorkOrderId(), workOrderBacklogInputMessage.getWorkOrderId(),
                    "WorkOrderId is wrong in requested message for " + workOrderBacklogInputMessage.getWorkOrderId());
            Assert.assertEquals(materialRequestMessage.getMaterialMetadataOutputFile(),
                    workOrderBacklogInputMessage.getRawMaterialMetadataOutputFilePath(s3MaterialStorage, jobIdStatusEvent), "Wrong material metadata output file path in requested message with workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
            Assert.assertEquals(materialRequestMessage.getJobId(), jobIdStatusEvent, "Wrong jobId in requested message with workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
        });
    }

    @Story("SVCS9-1971 WO Backlog | Feature | Make Material Service requests from backlog")
    @TmsLink("SVCS9-1149")
    @Description("WO Backlog makes a request to the Material Service if new workOrder validation is successful, without pxfInfo")
    @Test(groups = {"full"})
    public void woBacklogMakesRequestToMaterialServiceIfNewWOIsValidWithoutPxfInfo() {
        String statusMessageReceivedNewWO = WorkOrderBacklogStatusMessageEnum.RECEIVED.getStatusMessagePattern();
        String statusMessageMaterialRequested = WorkOrderBacklogStatusMessageEnum.MATERIAL_REQUESTED.getStatusMessagePattern();

        testLogger.step("Given: Work Order with valid payload without pxfInfo");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.getVideoSource().get(0).setId(MATERIAL_ID);
        JSONObject jsonObject = workOrderBacklogInputMessage.getJSONObject();
        jsonObject.remove("pxfInfo");
        testLogger.info(jsonObject.toString());

        testLogger.step("When: Work Order is sent to wo backlog stream: " + woBacklogEventStreamKinesisProducerProperties.getProperty("stream"));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Status event is sent to status kinesis stream that workOrder is ingested");
        List<StatusEvent> statusEventsReceived = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(),
                        String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()));
        Assert.assertEquals(statusEventsReceived.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage: "
                + String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()) + ". Should be 1 status event");

        testLogger.step("And: Status event is sent to the status kinesis stream that request to Material Service is performed");
        List<StatusEvent> statusEventsMaterialRequested = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(), statusMessageMaterialRequested);
        Assert.assertEquals(statusEventsMaterialRequested.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage: " + statusMessageMaterialRequested + ". Should be 1 status event");

        testLogger.step("And: There are no errors in status event with request to Material Service");
        statusEventsMaterialRequested.forEach(event ->
                Assert.assertTrue(event.getErrors().isEmpty(), "There are errors status event with request to Material Service for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId()));

        String jobIdStatusEvent = statusEventsMaterialRequested.get(0).getJobId();
        testLogger.step("And: JobId: " + jobIdStatusEvent + " for status message with workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Message from WO Backlog Service that request to Material Service is performed is sent to Material Service stream with the same jobId: " + jobIdStatusEvent);
        List<MaterialRequestMessage> materialRequestMessageList = MaterialKinesisBuffer.getInstance().getMaterialRequestMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertEquals(materialRequestMessageList.size(), 1, "Invalid number of requests to Material Service for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
        materialRequestMessageList.forEach(materialRequestMessage -> {
            Assert.assertEquals(materialRequestMessage.getWorkOrderId(), workOrderBacklogInputMessage.getWorkOrderId(), "WorkOrderId is wrong in requested message for " + workOrderBacklogInputMessage.getWorkOrderId());
            Assert.assertEquals(materialRequestMessage.getMaterialMetadataOutputFile(), workOrderBacklogInputMessage.getRawMaterialMetadataOutputFilePath(s3MaterialStorage, jobIdStatusEvent), "Wrong material metadata output file path in requested message with workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
            Assert.assertEquals(materialRequestMessage.getJobId(), jobIdStatusEvent, "Wrong jobId in requested message with workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
        });
    }
}
