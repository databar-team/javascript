package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.requesttovalidationservice;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.WorkOrderBacklogStatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.List;

public class TC2105WOBacklogDoesNotMakeRequestToValidationServiceForValidWOWithoutJobIdParity extends BaseTest {

    @Story("SVCS9-1971 WO Backlog | Feature | Make Material Service requests from backlog")
    @TmsLink("SVCS9-2105")
    @Description("WO Backlog doesn't make request to Validation service for valid WO and without jobId parity")
    @Test(groups = {"full"}, dataProvider = "getParams")
    public void woBacklogServiceDoesNotMakeRequestToValidationServiceForValidWoWithoutJobIdParity(String materialRequested, String materialRetrieval) {

        String statusMessageReceivedNewWO = WorkOrderBacklogStatusMessageEnum.RECEIVED.getStatusMessagePattern();
        String statusMessageRequestToValidationService = WorkOrderBacklogStatusMessageEnum.REQUESTING_VALIDATION.getStatusMessagePattern();

        testLogger.step("Given: workOrder without jobId parity");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = new WorkOrderBacklogInputMessage();
        workOrderBacklogInputMessage.setMaterialRequested(materialRequested);
        workOrderBacklogInputMessage.setMaterialRetrieval(materialRetrieval);
        testLogger.info(workOrderBacklogInputMessage.getFullJSONObject().toString());

        testLogger.step("When: Work order with predefined fields is sent to WorkOrder Backlog Service");
        sendMessage(workOrderBacklogInputMessage.getFullJSONObject(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Work order record is inserted into DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no record in dynamoDb for work order " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.step("And: Status event is sent to status kinesis stream that workOrder is ingested");
        List<StatusEvent> statusEventsReceived = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(),
                        String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId()));
        Assert.assertEquals(statusEventsReceived.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessage.getWorkOrderId() + " with statusMessage: "
                + String.format(statusMessageReceivedNewWO, workOrderBacklogInputMessage.getWorkOrderId())
                + ". Should be 1 status event");

        testLogger.step("And: Status event is not sent to status kinesis stream that request is sent to Validation Service");
        List<StatusEvent> statusEventsRequestToValidationService = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessage.getWorkOrderId(), statusMessageRequestToValidationService);
        Assert.assertTrue(statusEventsRequestToValidationService.isEmpty(), "There are status events " +
                "that request to Validation Service is sent for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId()
                + " with statusMessage: " + statusMessageRequestToValidationService);
    }

    @DataProvider(parallel = true)
    public static Object[][] getParams() {
        return new Object[][]{
                //materialRequested; materialRetrieval;
                {
                        "jobId", null
                },
                {
                        "jobId1", "jobId2"
                },
                {
                        null, "jobId2"
                },
                {
                        null, null
                }
        };
    }
}
