package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.requesttovalidationservice;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.validation.ValidationServiceKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.WorkOrderBacklogStatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.contract.ValidationContract;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import com.nbcuni.test.utils.contract.ContractValidator;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class TC2251WOBacklogMakesRequestToValidationServiceInAccordanceWithValidationContract extends CommonValidations {

    private static final String WORK_ORDER_VIDEO_CC = "src/main/resources/templates/work_order_video_cc.json";

    @Story("SVCS9-2132 WO Backlog | Feature | Contract changes for requesting Validation")
    @TmsLink("SVCS9-2251")
    @Description("Test Case | WO Backlog | WO Backlog makes request to Validation Service in accordance with Validation contract for valid WO with jobId parity")
    @Test(groups = {"full"})
    public void woBacklogServiceMakesRequestToValidationServiceAccordingToContract() {
        String statusMessageRequestToValidationService = WorkOrderBacklogStatusMessageEnum.REQUESTING_VALIDATION.getStatusMessagePattern();

        testLogger.step("Given: workOrder with jobId parity");
        WorkOrderBacklogInputMessage workOrderBacklogInputMessageContract = new WorkOrderBacklogInputMessage(objectMapper);
        workOrderBacklogInputMessageContract.setWorkOrderContract(getWorkOrderFromTemplate(WORK_ORDER_VIDEO_CC));
        workOrderBacklogInputMessageContract.setMaterialRequested(System.currentTimeMillis() + "1");
        workOrderBacklogInputMessageContract.setMaterialRetrieval(workOrderBacklogInputMessageContract.getMaterialRequested());
        testLogger.info(workOrderBacklogInputMessageContract.getJSONObjectFromContract().toString());

        testLogger.step("When: Work order with predefined fields is sent to WorkOrder Backlog Service");
        sendMessage(workOrderBacklogInputMessageContract.getJSONObjectFromContract(), woBacklogEventStreamKinesisProducerProperties);

        testLogger.step("Then: Work order record is inserted into DynamoDb table");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessageContract.getWorkOrderContract().getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no record in dynamoDb for work order " + workOrderBacklogInputMessageContract.getWorkOrderContract().getWorkOrderId());

        testLogger.step("And: Status event is sent to status kinesis stream that request is sent to Validation Service");
        List<StatusEvent> statusEventsRequestToValidationService = StatusEventKinesisBuffer.getInstance()
                .getJobStatusWithStatusMessage(workOrderBacklogInputMessageContract.getWorkOrderContract().getWorkOrderId(), statusMessageRequestToValidationService);
        Assert.assertEquals(statusEventsRequestToValidationService.size(), 1, "Invalid number of status events for workOrderId: "
                + workOrderBacklogInputMessageContract.getWorkOrderContract().getWorkOrderId() + " with statusMessage: "
                + statusMessageRequestToValidationService + ". Should be 1 status event");

        testLogger.step("And: Request to Validation service is performed");
        List<ValidationContract> validationRequests = ValidationServiceKinesisBuffer.getInstance()
                .getValidationServiceMessagesWithWaiting(workOrderBacklogInputMessageContract.getWorkOrderContract().getWorkOrderId());
        Assert.assertEquals(validationRequests.size(), 1, "There is no validation requests to validation service for workOrder "
                + workOrderBacklogInputMessageContract.getWorkOrderContract().getWorkOrderId());
        testLogger.step("And: WO Backlog request to Validation Service is according to contract");
        ContractValidator.validateRequestObject(
                VALIDATION_CONTRACT_LOCATION,
                VALIDATION_MODEL,
                validationRequests.get(0),
                true
        );
        validationRequests.forEach(validationRequest ->
                verifyValidationRequest(validationRequest, workOrderBacklogInputMessageContract, s3MaterialStorage));
    }
}
