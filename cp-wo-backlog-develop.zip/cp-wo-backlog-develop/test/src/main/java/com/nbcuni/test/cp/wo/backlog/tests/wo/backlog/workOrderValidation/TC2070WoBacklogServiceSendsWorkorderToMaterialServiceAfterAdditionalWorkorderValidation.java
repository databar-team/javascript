package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.workOrderValidation;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.material.MaterialKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.JobStatusEnum;
import com.nbcuni.test.cp.wo.backlog.model.MaterialRequestMessage;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TC2070WoBacklogServiceSendsWorkorderToMaterialServiceAfterAdditionalWorkorderValidation extends CommonValidations {

    @Story("SVCS9-1894")
    @TmsLink("SVCS9-2070")
    @Description("Verify that workorder is sent to Material Services when when workOrderAction " +
            "is CREATE and requiredComponents contains video or cc if there are videoSource.id and videoSource.TVDNumber and audioAndCaptionPreference")
    @Test(groups = {"full"}, dataProvider = "getRequiredComponents")
    public void workorderIsSentToMaterialServicesIfThereAreAllRequiredFields(String requiredComponent) {

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = workOrderBuilder.createKinesisMessage();
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        JSONObject jsonObject = workOrderBacklogInputMessage.getJSONObject();
        List<String> requiredComponentsList = new ArrayList<>();
        requiredComponentsList.add(requiredComponent);
        jsonObject.put("requiredComponents", requiredComponentsList);
        testLogger.info("Given: A payload for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId()
                + " workOrderAction=CREATE and requiredComponents contain " + requiredComponent);
        testLogger.info(jsonObject.toString());

        testLogger.info("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);
        testLogger.info("Then: WO is stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no item in Dynamo DB table by workOrderId = " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.info("And: Error status message is sent to Status Stream");
        List<StatusEvent> workOrderBacklogEvents = StatusEventKinesisBuffer.getInstance().getJobStatusWithStatusMessage(workOrderId, JobStatusEnum.ERROR.getValue());
        Assert.assertTrue(workOrderBacklogEvents.isEmpty(), "There is an error message for workOrder " + workOrderId);

        testLogger.step("And: Event is available in material service stream");
        List<MaterialRequestMessage> materialRequestMessageList = MaterialKinesisBuffer.getInstance().getMaterialRequestMessageKinesisMapWithWaiting(workOrderId);
        Assert.assertNotNull(materialRequestMessageList, "There is no requests to material service for workOrder " + workOrderId);
    }


    @DataProvider(parallel = true)
    public static Object[][] getRequiredComponents() {
        return new Object[][]{
                //requiredComponents
                {"video"},
                {"cc"}
        };
    }
}
