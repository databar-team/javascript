package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.workOrderValidation;

import com.nbcuni.test.cp.wo.backlog.model.StatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.Profile;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TC2071WoBacklogServiceDoesNotIngestWorkorderIfThereIsNoProfileName extends CommonValidations {

    @Story("SVCS9-1894")
    @TmsLink("SVCS9-2071")
    @Description("Verify that workorder is not ingested if there is no profile name")
    @Test(groups = {"full", "phase1"}, dataProvider = "getProfileName")
    public void workorderIsNotIngestedIfThereIsNoProfileName(String profileName) {
        List<String> errorCodes = new ArrayList<>();
        List<String> errorMessages = new ArrayList<>();
        errorCodes.add("501");
        errorMessages.add("Missing or Invalid profile");
        String statusMessage = StatusMessageEnum.REJECTED_NEW_WORK_ORDER.getValue();

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = workOrderBuilder.createKinesisMessage();
        JSONObject jsonObject = workOrderBacklogInputMessage.getJSONObject();
        JSONObject jsonProfile = new Profile().getJSONObject();
        if (profileName != null && profileName.equals("withoutProfileName")) {
            jsonProfile.remove("name");
        } else {
            jsonProfile.put("name", profileName);
        }
        jsonObject.put("profile", jsonProfile);
        testLogger.info("Given: A payload for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
        testLogger.info(jsonObject.toString());

        testLogger.info("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);
        testLogger.info("Then: WO is NOT stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNull(workOrderDb, "There is an item in Dynamo DB table by workOrderId = " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.info("And: Error status message is sent to Status Stream");
        verifyErrorStatusEvent(workOrderBacklogInputMessage.getWorkOrderId(), statusMessage, errorCodes, errorMessages);
    }

    @DataProvider(parallel = true)
    public static Object[][] getProfileName() {
        return new Object[][]{
                //profile.name
                {"withoutProfileName"},
                {null}
        };
    }
}
