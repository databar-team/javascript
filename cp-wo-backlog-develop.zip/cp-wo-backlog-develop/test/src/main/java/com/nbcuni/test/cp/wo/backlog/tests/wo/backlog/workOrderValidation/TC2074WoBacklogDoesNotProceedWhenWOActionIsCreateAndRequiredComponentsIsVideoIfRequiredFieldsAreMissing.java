package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.workOrderValidation;

import com.google.gson.JsonObject;
import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.validation.ValidationServiceKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.StatusMessageEnum;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.contract.ValidationContract;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.VideoSource;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import wiremock.net.minidev.json.JSONArray;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TC2074WoBacklogDoesNotProceedWhenWOActionIsCreateAndRequiredComponentsIsVideoIfRequiredFieldsAreMissing extends CommonValidations {

    @Story("SVCS9-1894")
    @TmsLink("SVCS9-2074")
    @Description("Verify that workorder is not sent to other services when when workOrderAction " +
            "is CREATE and requiredComponents contains video if there is no videoSource.id or videoSource.TVDNumber or audioAndCaptionPreference")
    @Test(groups = {"full"}, dataProvider = "getParams")
    public void workorderIsNotSentToOtherServicesWhenRequiredComponentsContainVideoIfThereAreNoRequiredFields(String videoSourceId, String videoSourceTvdNumber, String audioAndCaptionPreference) {

        List<String> errorCodes = getErrorCodes(videoSourceId, videoSourceTvdNumber, audioAndCaptionPreference);
        List<String> errorMessages = getErrorMessages(videoSourceId, videoSourceTvdNumber, audioAndCaptionPreference);
        String statusMessage = StatusMessageEnum.WORKORDER_VALIDATION_FAILED.getValue();

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = workOrderBuilder.createKinesisMessage();
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        JSONObject jsonObject = getPayload(workOrderBacklogInputMessage.getJSONObject(), videoSourceId, videoSourceTvdNumber, audioAndCaptionPreference);
        testLogger.info("Given: A payload for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId() + " workOrderAction=CREATE and requiredComponents contain video");
        testLogger.info(jsonObject.toString());

        testLogger.info("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);
        testLogger.info("Then: WO is stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderIdWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no item in Dynamo DB table by workOrderId = " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.info("And: Error status message is sent to Status Stream");
        verifyErrorStatusEvent(workOrderBacklogInputMessage.getWorkOrderId(), statusMessage, errorCodes, errorMessages);

        List<ValidationContract> validationRequests = ValidationServiceKinesisBuffer.getInstance().getValidationServiceMessagesWithWaiting(workOrderId);
        Assert.assertTrue(validationRequests.isEmpty(), "There is validation requests to validation service for workOrder " + workOrderId);

        List<JobSubmissionContract> jobSubmissionMessageKinesisMap = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderId);
        Assert.assertTrue(jobSubmissionMessageKinesisMap.isEmpty(), "There is a status message that the work order is in Job Submission service");
    }

    @DataProvider(parallel = true)
    public static Object[][] getParams() {
        return new Object[][]{
                //videoSource.id  videoSource.TVDNumber  audioAndCaptionPreference  errorCode   errorMessage
                {null, "default", "default"},
                {"default", null, "default"},
                {"default", "default", null},
                {null, null, "default"},
                {"default", null, null},
                {null, "default", null},
                {null, null, null}
        };
    }

    private JSONObject getPayload(JSONObject jsonObject, String id, String tvdNumber, String audioAndCaptionPreference) {
        JSONObject videoSourceJson = new VideoSource().getJSONObject();
        if (id == null) {
            videoSourceJson.put("id", id);
        } else if (id.equals("")) {
            videoSourceJson.remove("id");
        }
        if (tvdNumber == null) {
            videoSourceJson.put("TVDNumber", tvdNumber);
        } else if (tvdNumber.equals("")) {
            videoSourceJson.remove("TVDNumber");
        }
        JSONArray videoSourceJSONArray = new JSONArray();
        videoSourceJSONArray.add(videoSourceJson);
        jsonObject.put("videoSource", videoSourceJSONArray);
        if (audioAndCaptionPreference == null) {
            jsonObject.put("audioAndCaptionPreference", audioAndCaptionPreference);
        } else if (audioAndCaptionPreference.equals("")) {
            jsonObject.remove("audioAndCaptionPreference");
        }
        return jsonObject;
    }

    private List<String> getErrorCodes(String id, String tvdNumber, String audioAndCaptionPreference) {
        List<String> errorCodes = new ArrayList<>();
        if (id == null || id.equals("")) {
            errorCodes.add("505");
        }
        if (tvdNumber == null || tvdNumber.equals("")) {
            errorCodes.add("506");
        }
        if (audioAndCaptionPreference == null || audioAndCaptionPreference.equals("")) {
            errorCodes.add("507");
        }
        return errorCodes;
    }

    private List<String> getErrorMessages(String id, String tvdNumber, String audioAndCaptionPreference) {
        List<String> errorMessages = new ArrayList<>();
        if (id == null || id.equals("")) {
            errorMessages.add("Could not find videoSource.id");
        }
        if (tvdNumber == null || tvdNumber.equals("")) {
            errorMessages.add("Could not find videoSource.TVDNumber");
        }
        if (audioAndCaptionPreference == null || audioAndCaptionPreference.equals("")) {
            errorMessages.add("Could not find audioAndCaptionPreference");
        }
        return errorMessages;
    }
}
