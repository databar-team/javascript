package com.nbcuni.test.cp.wo.backlog.tests.wo.backlog.workOrderValidation;

import com.nbcuni.test.cp.wo.backlog.config.kcl.StatusEventKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.config.kcl.jobSubmission.JobSubmissionKinesisBuffer;
import com.nbcuni.test.cp.wo.backlog.model.JobStatusEnum;
import com.nbcuni.test.cp.wo.backlog.model.StatusEvent;
import com.nbcuni.test.cp.wo.backlog.model.contract.JobSubmissionContract;
import com.nbcuni.test.cp.wo.backlog.model.db.WorkOrderDb;
import com.nbcuni.test.cp.wo.backlog.model.workOrderBacklog.WorkOrderBacklogInputMessage;
import com.nbcuni.test.cp.wo.backlog.tests.CommonValidations;
import io.qameta.allure.Description;
import io.qameta.allure.Story;
import io.qameta.allure.TmsLink;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import wiremock.net.minidev.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TC2080WoBacklogServiceSendsWorkorderToJobSubmissionServiceAfterAdditionalWorkorderValidation extends CommonValidations {

    @Story("SVCS9-1894")
    @TmsLink("SVCS9-2070")
    @Description("Verify that workorder is sent to JobSubmission Services when when workOrderAction " +
            "is CREATE and requiredComponents contains video or cc if there are videoSource.id and videoSource.TVDNumber and audioAndCaptionPreference")
    @Test(groups = {"full"}, dataProvider = "getRequiredComponents")
    public void workorderIsSentToJobSubmissionServicesIfThereAreAllRequiredFields(String requiredComponent) {

        WorkOrderBacklogInputMessage workOrderBacklogInputMessage = workOrderBuilder.createKinesisMessage();
        String workOrderId = workOrderBacklogInputMessage.getWorkOrderId();
        workOrderBacklogInputMessage.setMaterialRequested(System.currentTimeMillis() + "1");
        workOrderBacklogInputMessage.setMaterialRetrieval(workOrderBacklogInputMessage.getMaterialRequested());
        workOrderBacklogInputMessage.setValidated(true);
        JSONObject jsonObject = workOrderBacklogInputMessage.getFullJSONObject();
        List<String> requiredComponentsList = new ArrayList<>();
        requiredComponentsList.add(requiredComponent);
        jsonObject.put("requiredComponents", requiredComponentsList);
        testLogger.info("Given: A payload for workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId()
                + " workOrderAction=CREATE and requiredComponents contain " + requiredComponent);
        testLogger.info(jsonObject.toString());

        testLogger.info("When: Message is sent to kinesis stream " + woBacklogEventStreamKinesisProducerProperties.get("stream"));
        sendMessage(jsonObject, woBacklogEventStreamKinesisProducerProperties);
        testLogger.info("Then: WO is stored in DynamoDb");
        WorkOrderDb workOrderDb = getWorkOrderFromDbByWorkOrderId(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertNotNull(workOrderDb, "There is no item in Dynamo DB table by workOrderId = " + workOrderBacklogInputMessage.getWorkOrderId());

        testLogger.info("And: Error status message is sent to Status Stream");
        List<StatusEvent> workOrderBacklogEvents = StatusEventKinesisBuffer.getInstance().getJobStatusWithStatusMessage(workOrderId, JobStatusEnum.ERROR.getValue());
        Assert.assertTrue(workOrderBacklogEvents.isEmpty(), "There is an error message for workOrder " + workOrderId);

        testLogger.step("And: Event is available in job submission stream");
        List<JobSubmissionContract> jobSubmissions = JobSubmissionKinesisBuffer.getInstance().getJobSubmissionMessageKinesisMapWithWaiting(workOrderBacklogInputMessage.getWorkOrderId());
        Assert.assertFalse(jobSubmissions.isEmpty(), "There is no events in job submission stream , workOrderId: " + workOrderBacklogInputMessage.getWorkOrderId());
    }


    @DataProvider(parallel = true)
    public static Object[][] getRequiredComponents() {
        return new Object[][]{
                //requiredComponents
                {"video"},
                {"cc"}
        };
    }
}
