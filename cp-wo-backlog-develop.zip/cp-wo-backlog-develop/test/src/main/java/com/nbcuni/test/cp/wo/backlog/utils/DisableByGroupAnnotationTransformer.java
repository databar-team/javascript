package com.nbcuni.test.cp.wo.backlog.utils;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class DisableByGroupAnnotationTransformer implements IAnnotationTransformer {
    @Override
    public void transform(ITestAnnotation iTestAnnotation, Class aClass, Constructor constructor, Method method) {
        String groups =iTestAnnotation.getGroups().toString();
        if(iTestAnnotation.getGroups().toString().contains("phase1")){
            iTestAnnotation.setEnabled(false);
        }
        else {
            iTestAnnotation.setEnabled(false);
        }
    }
}
