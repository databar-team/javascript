package com.nbcuni.test.cp.wo.backlog.utils;

import com.nbcuni.test.cp.wo.backlog.tests.BaseTest;
import org.testng.*;

import java.util.Arrays;

public class PhaseOneTestListener implements ITestListener {

    @Override
    public void onTestStart(ITestResult iTestResult) {
        if (BaseTest.phaseBefore.equals("1")
                && !Arrays.toString(iTestResult.getMethod().getGroups()).contains("phase1")
                && iTestResult.getMethod().getGroups().length == 1) {
            throw new SkipException("Skipping a test because of a Phase 1");
        }
        if (!(BaseTest.phaseBefore.equals("1") || BaseTest.phaseBefore.equals("2"))
                && (Arrays.toString(iTestResult.getMethod().getGroups()).contains("phase1")
                || Arrays.toString(iTestResult.getMethod().getGroups()).contains("phase2"))) {
            throw new SkipException("Skipping a test because of NOT a Phase 1 or 2");
        }

    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailure(ITestResult iTestResult) {

    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    @Override
    public void onStart(ITestContext iTestContext) {

    }

    @Override
    public void onFinish(ITestContext iTestContext) {

    }
}

