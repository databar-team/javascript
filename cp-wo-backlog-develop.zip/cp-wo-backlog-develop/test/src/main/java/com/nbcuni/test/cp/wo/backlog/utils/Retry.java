package com.nbcuni.test.cp.wo.backlog.utils;

import com.nbcuni.test.cp.wo.backlog.config.annotations.MaxRetryCount;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;
import com.nbcuni.test.utils.Logger;

public class Retry implements IRetryAnalyzer {

    private static final Logger logger = new Logger();
    private int currentRetry = 0;

    @Override
    public boolean retry(ITestResult iTestResult) {
        MaxRetryCount annotation = iTestResult.getMethod().getConstructorOrMethod().getMethod()
                .getAnnotation(MaxRetryCount.class);
        int maxRetryCount = null != annotation ? annotation.value() : 1;

        if (++currentRetry > maxRetryCount) {
            currentRetry = 0;
            return false;
        } else {
            String methodName = iTestResult.getMethod().getMethodName();
            logger.info("Executing retry #" + currentRetry + " of '" + methodName + "' !!!");
            return true;
        }
    }
}