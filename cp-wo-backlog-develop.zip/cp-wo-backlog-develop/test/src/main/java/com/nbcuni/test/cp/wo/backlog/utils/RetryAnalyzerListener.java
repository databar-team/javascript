package com.nbcuni.test.cp.wo.backlog.utils;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class RetryAnalyzerListener implements IAnnotationTransformer {
    @Override
    public void transform(ITestAnnotation testAnnotation, Class clazz, Constructor testConstructor, Method method) {
        testAnnotation.setRetryAnalyzer(RetryAnalyzer.class);
    }
}
