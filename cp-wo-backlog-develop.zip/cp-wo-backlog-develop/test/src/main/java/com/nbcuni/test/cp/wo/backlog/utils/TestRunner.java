package com.nbcuni.test.cp.wo.backlog.utils;

import org.testng.IClassListener;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ITestRunnerFactory;
import org.testng.xml.XmlTest;

import java.util.Collection;
import java.util.List;

public class TestRunner implements ITestRunnerFactory {
    @Override
    public org.testng.TestRunner newTestRunner(ISuite iSuite, XmlTest xmlTest, Collection<IInvokedMethodListener> collection, List<IClassListener> list) {
        return newTestRunner(iSuite, xmlTest, collection, list);
    }
}
